"""Post-outcome descriptive attribution; no changed experiment configuration."""
import csv,json,hashlib
from pathlib import Path
import numpy as np
from replay import ROOT,load_data,run,majority,MODELS

out={}
for ds in ['gpqa','arc']:
    data=load_data(ds); initial=data['p'][:,:,:,0].argmax(axis=2)
    z1,z1pred,_=run(data['p'],data['choice'],'zero_reward',steps=1)
    z10,z10pred,_=run(data['p'],data['choice'],'zero_reward',steps=10)
    ii=np.arange(data['n'])[:,None];dd=np.arange(3)[None,:];cc=data['choice'][:,None]
    pair=data['p'][ii,dd,cc,:];before_sum=pair.sum(axis=-1)
    native_trace=json.loads((ROOT/'results'/f'{ds}_native_zscore_trace.json').read_text())
    step_stats=[]
    for t in native_trace:
        raw=np.asarray(t['raw']); applied=np.asarray(t['applied'])
        step_stats.append({'step':t['step'],'batches':len(raw),'all_zero_raw_batches':int(np.all(raw==0,axis=1).sum()),
          'all_zero_applied_batches':int(np.all(applied==0,axis=1).sum()),
          'positive_raw_to_negative_applied':int(((raw>0)&(applied<0)).sum()),
          'zero_raw_to_nonzero_applied':int(((raw==0)&(applied!=0)).sum()),
          'nonzero_raw_to_zero_applied':int(((raw!=0)&(applied==0)).sum())})
    predictions=list(csv.DictReader((ROOT/'results'/f'{ds}_predictions.csv').open()))
    rows=[r for r in predictions if r['seed']=='original']
    match={cond:{m:sum(r[m]==r['generator'] for r in rows if r['condition']==cond) for m in MODELS+['majority']}
           for cond in ['native_zscore','zero_reward','raw','scale_only']}
    r={'n':data['n'],'generator_matches_original_order':match,
       'zero_one_vs_ten_max_policy_difference':float(np.max(np.abs(z1-z10))),
       'zero_one_vs_ten_answer_disagreements':int((z1pred!=z10pred).sum()),
       'initial_selected_binary_pair_sum_min':float(before_sum.min()),'initial_selected_binary_pair_sum_max':float(before_sum.max()),
       'zero_firststep_changed_answers':{m:int((z1pred[:,d]!=initial[:,d]).sum()) for d,m in enumerate(MODELS)},
       'reward_diagnostics':step_stats}
    out[ds]=r
(ROOT/'results'/'mechanism_attribution.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
