import copy,csv,json,random,time
import numpy as np
from replay import ROOT,MODELS,SEEDS,CONDITIONS,load_data,run,majority,metric,MiniFrame,ORIGINAL,digest

def normalize_every_pair(p):
    total=p.sum(axis=-1,keepdims=True)
    return np.divide(p,total,out=np.zeros_like(p),where=total!=0)

def evaluate(ds):
    data=load_data(ds); n=data['n'];gold=data['gold'];p=normalize_every_pair(data['p'])
    initial=p[:,:,:,0].argmax(axis=2);initmaj=majority(initial)
    zero,zpred,_=run(p,data['choice'],'zero_reward')
    null_error=float(np.max(np.abs(zero-p))); assert null_error<1e-12
    null_mismatches=int((zpred!=initial).sum())
    # Literal log/exp arithmetic can break exact initial ties at machine precision.
    for i,d in zip(*np.where(zpred!=initial)):
        assert abs(p[i,d,zpred[i,d],0]-p[i,d,initial[i,d],0])<1e-12
    # Original batch function on every normalized-input row, with unused trailing batch.
    frames=[]
    for d in range(3):
        pol=[{k:{'correct':p[i,d,a,0],'incorrect':p[i,d,a,1]} for a,k in enumerate(data['keys'][i])} for i in range(n)]
        frames.append(MiniFrame({'disc_init_policy_refine':pol+copy.deepcopy(pol[:8]),
             'gen_init_policy':copy.deepcopy(data['generator'])+copy.deepcopy(data['generator'][:8])}))
    ORIGINAL['batch_update_discriminators_flexible'](*frames,choice_df=frames[0])
    pure,pp,_=run(p,data['choice'],'native_zscore');errs=[];mismatches=0
    for i in range(n):
        for d in range(3):
            orig=frames[d]['updated_disc_policy'][i]
            for a,key in enumerate(data['keys'][i]):
                errs.extend(abs(pure[i,d,a,v]-orig[key][k]) for v,k in enumerate(['correct','incorrect']))
            mismatches+=int(frames[d]['updated_answer_letter'][i]!=data['keys'][i][pp[i,d]])
    assert max(errs)<1e-10 and mismatches==0
    result={'dataset':ds,'n':n,'zero_identity_max_policy_error':null_error,'zero_identity_answer_mismatches':null_mismatches,
       'zero_answer_mismatches_all_initial_ties':True,
       'equivalence_max_policy_error':max(errs),'equivalence_answer_mismatches':mismatches,
       'initial_answer_changes_due_to_full_pair_normalization':int((initial!=data['p'][:,:,:,0].argmax(axis=2)).sum()),
       'baselines':{m:metric(initial[:,d],gold,initial[:,d]) for d,m in enumerate(MODELS)},'runs':[]}
    result['baselines']['majority']=metric(initmaj,gold,initmaj)
    all_outputs={c:[] for c in CONDITIONS}
    with (ROOT/'results'/f'{ds}_normalized_predictions.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['dataset','condition','seed','row','gold','generator']+MODELS+['majority'])
        for seed in SEEDS:
            perm=list(range(n))
            if seed is not None:random.Random(seed).shuffle(perm)
            perm=np.asarray(perm);inv=np.argsort(perm)
            for cond in CONDITIONS:
                _,pred,trace=run(p[perm],data['choice'][perm],cond,trace=seed is None)
                pred=pred[inv];maj=majority(pred);combined=np.column_stack([pred,maj]);all_outputs[cond].append(combined)
                met={m:metric(pred[:,d],gold,initial[:,d]) for d,m in enumerate(MODELS)}
                met['majority']=metric(maj,gold,initmaj)
                result['runs'].append({'seed':seed,'condition':cond,'metrics':met,
                    'generator_matches':{m:int((combined[:,d]==data['choice']).sum()) for d,m in enumerate(MODELS+['majority'])}})
                if seed is None:(ROOT/'results'/f'{ds}_normalized_{cond}_trace.json').write_text(json.dumps(trace))
                for i in range(n):
                    def letter(x):return None if x<0 else data['keys'][i][x]
                    w.writerow([ds,cond,'original' if seed is None else seed,i,letter(gold[i]),letter(data['choice'][i])]+[letter(x) for x in combined[i]])
    result['regrouping']={}
    for cond,outputs in all_outputs.items():
        a=np.stack(outputs);result['regrouping'][cond]={}
        for d,m in enumerate(MODELS+['majority']):
            acc=(a[1:,:,d]==gold).mean(axis=1);dis=(a[1:,:,d]!=a[0,:,d]).mean(axis=1)
            result['regrouping'][cond][m]={'accuracy_mean':float(acc.mean()),'accuracy_min':float(acc.min()),'accuracy_max':float(acc.max()),
               'noninvariant_rows':int(np.any(a[1:,:,d]!=a[0,:,d],axis=0).sum()),'disagreement_mean':float(dis.mean())}
    (ROOT/'results'/f'{ds}_normalized_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'dataset':ds,'zero_identity_max_error':null_error,'equivalence_max_error':max(errs),
       'baseline':result['baselines']['majority'],'original':[{'condition':r['condition'],'majority':r['metrics']['majority'],
       'generator_matches':r['generator_matches']['majority']} for r in result['runs'] if r['seed'] is None]}),flush=True)

if __name__=='__main__':
    for ds in ['gpqa','arc']:evaluate(ds)
    (ROOT/'results'/'normalized_manifest.json').write_text(json.dumps({'protocol_sha256':digest(ROOT/'NORMALIZATION_DIAGNOSTIC_PROTOCOL.md'),
        'script_sha256':digest(ROOT/'normalized_diagnostic.py'),'api_calls':0},indent=2)+'\n')
