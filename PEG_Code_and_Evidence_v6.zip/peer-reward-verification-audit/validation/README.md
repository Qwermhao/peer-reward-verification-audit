# Independent numerical validation

These scripts and result records perform scientific checks. Internal editorial or judging reviews are not part of this public repository.

## Saved-prediction audit

Uses only the standard library and the included prediction CSVs:

```sh
python validation/audit_predictions.py
```

It recalculates all saved majority fields and checks the original-order native/zero/generator equality on GPQA and ARC-Challenge. Run in a disposable clone or copy if you want to preserve recorded JSON bytes.

## Native zero-reward certificate

Requires NumPy and the upstream files retrieved by `python native/fetch_public_inputs.py`:

```sh
python revision/validation/verify_native_certificate.py
```

The verifier calls the original AST-extracted `Discriminator` on every included model-question for ten zero-reward steps, and compares the first update to the closed-form certificate.

## Official label audit

First retrieve PEG inputs:

```sh
python native/fetch_public_inputs.py
```

Download the official public GPQA archive to `validation/gpqa_official_dataset.zip` from:

<https://raw.githubusercontent.com/idavidrein/gpqa/56686c06f5e19865c153de0fdb11be3890014df7/dataset.zip>

Then run:

```sh
python validation/verify_labels.py
```

The script records the archive SHA-256 and verifies Git blob SHA-1 `80788cb325c4d63bbccad56c2e393b33389348fe`. The archive-access string comes from the dataset authors' public README. The audit matches the reconstructed correct-answer text for all 448 released GPQA rows and checks position-based ARC numeric labels. No model accuracy is used to choose the mapping.

`revision/validation/EXTERNAL_CERTIFICATE_AUDIT.json` and `stochastic_independent_checks.json` retain separately computed check records. Their editorial review prose is omitted.
