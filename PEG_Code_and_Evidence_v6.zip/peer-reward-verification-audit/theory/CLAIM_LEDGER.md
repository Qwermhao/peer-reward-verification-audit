# Theory claim ledger

| ID | Claim | Evidence | Required conditions | Diagnostic or falsifier |
|---|---|---|---|---|
| T1 | Native expected payment equals A d_i² Σ_j w_ij d_j² | Lemma 1 proof; 8 exact enumeration cases | I.i.d. task vectors, two independent blocks, count matrices, consistent independent reporting channels | A disagreement with exhaustive expectation under these conditions would falsify the formula; shared cross-task randomness changes the object |
| T2 | Same-row-step Bernoulli entropy ascent preserves orientation and increases determinant magnitude | Theorem 1, logit recursion (2)–(5) | Full-support initialization, fixed signal law/graph, exact gradient, finite nonnegative steps, specified geometry | An exact-real arithmetic sign change under all conditions would falsify the theorem |
| T3 | Active agents with active informative neighbors converge to their sign's permutation | Theorem 1 | T2 plus divergent own step-size sum on those vertices | A noncorner limit under every condition would falsify the conclusion; finite total steps do not satisfy it |
| T4 | All-identity basin is exactly the all-positive sign region | Corollary 1 | T3, graph has no isolated vertices | A zero or negative initial orientation converging to identity under the stated update would contradict invariance |
| T5 | Limit is Nash iff active/inactive cut contains no informative edge | Corollary 1 | Full channel square as unilateral action set; T3 | Crossing-edge inactive agent has exact positive deviation gain; a restricted action domain changes the Nash question |
| T6 | Expected payment can increase while factual accuracy decreases | Eq. (6) and negative-orientation dynamics | Explicit synthetic latent bit, independent private error 1/4, active negative initialization, exact update | The probability law analytically gives accuracy 1/2+d_i/4; no empirical LLM inference is included |
| T7 | No truth-centered relative neighborhood supplies concavity along all channel directions | Proposition 2; exact positive midpoint gap | Nonzero informative peer coefficient, natural consistent-channel coordinates | Restricting to directions with fixed determinant removes the displayed direction but changes the policy domain |
| T8 | Curvature witness is not a counterexample satisfying the conditional regret theorem's hypotheses | Direct logical check | Concavity is a premise of the conditional result | Treating a failed hypothesis as an internal contradiction would be an invalid claim |
| T9 | General-game own concavity, strong monotonicity and unique-equilibrium selection are distinct conditions | Explicit quadratic game and cubic map | Standard payoff-ascent sign convention | Separate verified game stability could justify convergence, but is not implied by the counterexample premises |
| T10 | Published policy, consistent-channel model and released code require an explicit map | Source §2.2, A.1; parameterization examples | Identify sampled object, parameter, metric and expectation before applying a theorem | A different parameterization or stochastic update cannot be counted as replication of T2 |

## Attribution and what is new

- **Established DMI results:** determinant-channel factorization, static truthful best responses, label-permutation ambiguity. Cite Kong.
- **Established learning perspective:** peer-prediction attraction basins and the distinction between no regret and truthful convergence. Cite the related-work review's verified Shnayder et al. and Feng et al. sources.
- **Contribution to state:** the complete coupled binary row-channel trajectory classification, the full-support local-curvature witness, and their explicit connection to PEG's claimed assumptions and analyzed update.
- **Do not state:** first discovery of permutation invariance, general impossibility of peer prediction, a refutation of conditional OMD, or measured deterioration in real language-model factual accuracy.

## Exact parameter ledger

Theorem parameters: finite n; joint binary private-signal law fixed over time; fixed integers m1,m2≥2; w_ii=0; initial 0<a_i,b_i<1; finite η_i,t≥0; same step size for both row entropies; simultaneous full-profile updates; divergent Σ_t η_i,t for each initially nonzero agent with an initially nonzero informative neighbor. No vanishing-step condition is needed for this exact theorem.

Main witness: n=2, G~Bernoulli(1/2), independent private flips with error 1/4, m1=m2=2, U=[[5/16,3/16],[3/16,5/16]], A=4, w=1/256, payoff d1²d2²/64. For the decreasing-accuracy trajectory initialize both (a,b)=(3/4,1/4) and choose any finite nonnegative learning-rate schedule with divergent sum.

Illustrative schedule, not a required theorem restriction: η_i,t=1/(t+1)^0.75. Curvature check: ε=1/100, gap 1/640000. Stationary non-Nash check: d1=0,d2=1/2, gain 1/256.
