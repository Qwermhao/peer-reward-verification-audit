# External validation of the native PEG replay

Read `SUMMARY.md` for findings. This extension freezes two additional released datasets and one additional model trio before scoring. It evaluates 13,864 MMLU questions, 2,368 ARC-Easy questions, and the same 1,168 ARC-Challenge questions with Yi/Mistral/Gemma files. Source populations contain 13,869, 2,371 and 1,170 rows; only the predetermined incomplete final batches are omitted. Thus this adds 16,232 distinct new questions and one alternative-trio test, not 17,400 distinct new questions.

## Reproduce in a clean directory

The existing outputs are retained. To avoid replacing them, copy the scripts/manifests to a new child directory:

```sh
mkdir reproduction
cp *.py *MANIFEST.json *PROTOCOL.md *AMENDMENT.md requirements.txt reproduction/
cd reproduction
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python fetch_public_inputs.py
python external_replay.py
python verify_added_source.py
python build_tables.py
```

Observed environment: Python 3.14.5, NumPy 2.5.4. No pandas, model library, weights or API key is used. `fetch_public_inputs.py` is the only network step: it retrieves nine public CSVs and four public notebooks at the pinned commit, checks every byte count and Git blob hash, then extracts three audited cells. It uses the system trusted certificate bundle where available. All remaining steps run offline. The downloader rejects conflicting existing files; the analysis retains completed cohort summaries rather than silently overwriting them.

## Package contents

Include our code, manifests, protocol/audit records, derived tables and `results/`. Exclude `raw/`, `sources/`, `__pycache__/` and environments because the upstream repository contains no license file. The downloader reconstructs excluded upstream content. Relative paths are resolved against each script's directory.

- `INPUT_MANIFEST.json`, `SOURCE_MANIFEST.json`: pinned repository paths, Git SHA-1 and byte counts.
- `VERIFIED_ALL_INPUTS.json`: all thirteen source SHA-256 values.
- `FROZEN_EXTERNAL_PROTOCOL.md`, `CERTIFICATE_AMENDMENT.md`: pre-outcome selections, seeds, controls and zero-reward certification rule.
- `PARSER_AUDIT.md`: source-defined np.float32-string parsing for the alternative trio; the parser definition is documented; working logs are omitted from this public distribution.
- `SOURCE_DEFINITION_EQUIVALENCE.json`: shared main/added notebook numerical definitions and alternative-trio equivalence to the added notebook's generalized batch function.
- `replay_core.py`: unchanged earlier audited numerical engine; only named pure functions/classes are AST-extracted from upstream source. Notebook top-level code is never executed.
- `external_replay.py`: alignment, full-cohort native equivalence, certificate, native/zero controls, twenty regroupings and full-denominator metrics.
- `results/*_summary.json`: all aggregate metrics and exact-equivalence records.
- `results/*_predictions.npz`: arrays `native_zscore` and `zero_reward` of shape `(21, n, 4)`. The first dimension is original order then seeds2026111600 through2026111619; the last dimension is the three fixed model files then strict majority. Predictions are zero-based option positions; −1 is majority abstention. Arrays also contain gold, generator, initial predictions and certificate margins.
- `results/*_rows.csv`: row identifier/hash, option labels and canonical gold, without question text.
- `majority_coverage_table.csv`: correct/all, answered/all, coverage and correct/answered for each cohort/method.
- `agreement_certificate_table.csv`: original and regrouped native-zero agreement plus strict certificate counts.
- `RESIDUAL_EFFECTS.json`: native-vs-zero correctness transitions and zero-payment batch counts across steps.
- `ARC_OVERLAP_AUDIT.json`: confirms alternative-trio ARC questions exactly equal the previous core-trio ARC cohort in order.

The strict certificate guarantees zero-reward copying only under its explicit positive-margin condition. Native-zscore copying remains an empirical quantity. Cohort and model aliases were frozen from public availability, not observed accuracy. No >=14B probability file was released in the pinned repository; this is broader public-output validation, not frontier-model inference.
