## native_ablation.pdf / png / svg

**Peer-reward ablation reproduces the released majority output.** Replay of the pinned public probabilities on 448 GPQA and 1,168 ARC-Challenge questions, with the original order and native hyperparameters. The fixed Qwen generator, native PEG majority and all-zero-reward majority agree on every question, not merely in accuracy. Initial voting requires at least two matching answers; three-way disagreement counts as an abstention and contributes zero correct answers. Labels were independently validated against official GPQA answer texts and ARC option mappings. Raw and scale-only controls use the same learning rate and are diagnostic ablations. No new model inference was performed.

## native_directional_changes.pdf / png / svg

**Correctness transitions relative to the initial strict majority.** Counts of initial wrong/abstaining answers that become correct, and initial correct answers that become wrong/abstaining, on the same original-order cohorts. Native and zero-reward majorities have identical paired transitions because their predictions are identical. This separates greater coverage from genuine question-level losses and gains.

## normalized_diagnostic.pdf / png / svg

**Sequential diagnostic after normalizing every binary answer pair.** This extension was frozen after the primary result. All model probabilities, generator choices, rows, hyperparameters and twenty regrouping seeds remain fixed. Each dot is one deterministic regrouping; diamonds are original-order outcomes and dashed lines the exact no-update baseline. These dots are sensitivity analyses, not independent dataset replicates or confidence intervals. On ARC, native centered rewards reduce majority accuracy below the initial baseline in all twenty regroupings. Literal zero updates preserve policies to 1.11e-15, with six individual exact-tie flips across both cohorts; majority correct counts remain unchanged. Source-normalization and normalized-input claims are kept separate.
