from pathlib import Path
from fractions import Fraction as F
import ast,csv,itertools,json,math,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
if (ROOT/'results.csv').exists():raise SystemExit('Preserving existing control outputs')
STATES=np.array(list(itertools.product(range(2),repeat=4)),dtype=np.int8)
tree=ast.parse((BASE/'run_stochastic.py').read_text())
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'pay','inputs','wilson'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),'audited_own_functions','exec'))
rows=list(csv.DictReader((BASE/'raw/monte_carlo_cells.csv').open()))
out=[]
for row in rows:
    q,d,e=map(F,[row['q'],row['d'],row['peer']]);k=int(row['K']);A=int(row['A']);n=int(row['draws'])
    a,b,di,off,pr,de,pn,sd,san,sbn=inputs(q,d,e)
    rng=np.random.default_rng(int(row['seed']))
    codes=rng.choice(16,size=(n,k),p=np.array([float(x) for x in pr]))
    p=pay(codes);sa=np.sum(san[codes],axis=1)/sd;sb=np.sum(sbn[codes],axis=1)/sd
    mu=float(d*d*e*e*(di*di-off*off)**2)
    raw_a=p/A*sa;raw_b=p/A*sb
    ca=(p/A-mu)*sa;cb=(p/A-mu)*sb
    raw_sep=raw_b-raw_a;sep=cb-ca
    r={k:row[k] for k in ['case','q','d','peer','K','A','seed','draws']}
    r['oracle_mu']=mu
    for coord,g in [('a',ca),('b',cb),('sep',sep)]:
        r['mean_'+coord]=float(g.mean());r['se_'+coord]=float(g.std(ddof=1)/math.sqrt(n))
    r['uncentered_sep_variance']=float(np.var(raw_sep,ddof=1));r['centered_sep_variance']=float(np.var(sep,ddof=1))
    r['variance_ratio']=r['centered_sep_variance']/r['uncentered_sep_variance'] if r['uncentered_sep_variance'] else 1.
    events={}
    if d:
        events['opposed_separation_increment']=float(d)*sep<0
        old=2*math.log((1+float(d))/(1-float(d)))
        for alpha in [.1,1.,10.]:events[f'crossing_alpha_{alpha:g}']=float(d)*(old+alpha*sep)<0
    else:
        events['zero_channel_activation']=sep!=0
        for alpha in [.1,1.,10.]:events[f'activation_alpha_{alpha:g}']=sep!=0
    for name,mask in events.items():
        count=int(mask.sum());lo,hi=wilson(count,n)
        r[name+'_count']=count;r[name+'_rate']=count/n;r[name+'_lo95']=lo;r[name+'_hi95']=hi
    # The new centering must not alter the original simulation draw.
    assert abs(float(raw_a.mean())-float(row['mean_ga']))<1e-14
    assert abs(float(raw_b.mean())-float(row['mean_gb']))<1e-14
    out.append(r)
keys=sorted(set().union(*(r.keys() for r in out)))
with (ROOT/'results.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(out)
checks={'same_draws_reconstructed':len(out),'maximum_variance_ratio':max(r['variance_ratio'] for r in out),'minimum_variance_ratio':min(r['variance_ratio'] for r in out),'variance_reduced_cells':sum(r['variance_ratio']<1 for r in out),'zero_orientation_cells':sum(F(r['d'])==0 for r in out),'plan_sha256':hashlib.sha256((ROOT/'PLAN.json').read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks))
