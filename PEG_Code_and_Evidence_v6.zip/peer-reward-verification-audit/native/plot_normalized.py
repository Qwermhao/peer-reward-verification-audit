import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(8.5,3.7))
conds=['native_zscore','raw','scale_only','zero_reward'];labels=['Native\nz-score','Raw\nreward','Scale\nonly','Zero\nreward']
colors=['#D47B2D','#7E8B9D','#8375A5','#278875']
for ax,ds,title in zip(axes,['gpqa','arc'],['GPQA','ARC-Challenge']):
 s=json.loads((ROOT/'results'/f'{ds}_normalized_summary.json').read_text())
 for x,c,color in zip(range(4),conds,colors):
  vals=[r['metrics']['majority']['accuracy']*100 for r in s['runs'] if r['condition']==c and r['seed'] is not None]
  orig=next(r['metrics']['majority']['accuracy']*100 for r in s['runs'] if r['condition']==c and r['seed'] is None)
  ax.scatter(x+np.linspace(-.13,.13,20),vals,s=19,color=color,alpha=.62,zorder=3)
  ax.scatter([x],[orig],s=55,marker='D',edgecolors='white',linewidths=.5,color=color,zorder=4)
 base=s['baselines']['majority']['accuracy']*100
 ax.axhline(base,color='#233042',linestyle='--',linewidth=1,label=f'No update: {base:.2f}%')
 ax.set_xticks(range(4),labels,fontsize=9);ax.set_title(title,fontweight='bold');ax.set_xlim(-.45,3.45)
 ax.set_ylim((18,28) if ds=='gpqa' else (62,77))
 ax.set_axisbelow(True);ax.yaxis.grid(True,color='#E7EBEF',linewidth=.7);ax.legend(frameon=False,loc='upper right',fontsize=9)
axes[0].set_ylabel('Correct fraction (%)')
fig.suptitle('Normalize every answer pair before updating',fontsize=12,fontweight='bold',y=.99)
fig.text(.5,.015,'Dots: 20 fixed regroupings. Diamonds: original order. Dashed: exact no-update baseline.',ha='center',fontsize=9)
fig.subplots_adjust(left=.08,right=.99,top=.79,bottom=.17,wspace=.22)
for ext in ['png','pdf','svg']:fig.savefig(ROOT/'figures'/f'normalized_diagnostic.{ext}',dpi=220)
