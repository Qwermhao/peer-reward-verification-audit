# Exact mechanism audit — executed 16 November 2026

All 20 predeclared checks passed. The independent finite-batch enumeration confirms the binary DMI factorization; the deterministic trajectories preserve initial orientation and expose stationary profiles with profitable unilateral deviations.

## What was executed

These are analytically specified mechanism simulations and exact calculations, not real LLM outputs or human-participant observations. `PLAN.json` was saved before execution, with seed 20261116, fixed grids and all cases. No API calls, model downloads, prompt selection or post-result case replacement were used. The entire numerical audit used the already-installed Python environment and completed in approximately 1.16 seconds, excluding plotting.

The native pair payment is the product of two 2-by-2 co-report count-matrix determinants, on four i.i.d. tasks split 2+2. The expectation implementation first marginalizes private signals with explicit probability loops, then enumerates all 256 ordered report-pair sequences and evaluates the count payment directly. Zero-payment paths contribute exactly zero. A separate implementation evaluates `A d_1² d_2² det(U)²`, with `A=4`. Six selected cases also enumerate every latent-signal/report path directly, without first marginalizing signals.

## Results suitable for the report

| Check | Predeclared coverage | Observed result |
|---|---:|---|
| Exact expected payment | 1,875 channel profiles: 625 each under perfect, correlated noisy, and independent signals | 1,875 exact rational equalities; zero discrepancies |
| Full latent cross-check | 6 cases; 270,336 latent-signal/report paths | All six exactly equal the analytic expectation |
| Local curvature | 2 channel paths × 5 scales, down to ε=1/1024 | Every midpoint convexity gap equals ε²/4 > 0 |
| Static best responses | 1,775 determinant profiles across 7 graphs | 296 stationary, non-Nash profiles in this specified grid |
| Limit Nash classification | All 68 graph/active-set combinations | All 68 agree with exact unilateral best-response gaps; 24 Nash limits |
| Deterministic trajectories | 25 pair initializations + 8 graph cases, 4,000 steps each | No sign violations; every predicted stationary coordinate unchanged |
| Seeded property suite | 256 cases, 2–5 agents, 100 steps each, random nonnegative learning rates | Sign, monotonicity, stationarity and row-logit-sum checks passed |
| Independent update calculation | Initial step of all 256 property cases | Normalized exponentiated row weights agree with logit implementation to 3.34×10⁻¹⁶ |

The noisy signal law is `U=[[13/40,7/40],[7/40,13/40]]`: a fair latent truth and conditionally independent private signals of accuracies 3/4 and 4/5. The independent control has all entries 1/4 and zero expected DMI for every channel. The perfect-signal law is `diag(1/2,1/2)`.

The largest row-logit-sum drift was 1.37×10⁻¹³ over the deterministic suite. The largest apparent decrease in `|d|` was 1.12×10⁻¹⁶, within the predeclared floating-point tolerance. Every graph-predicted growing coordinate reached machine-saturated `|d|=1` by step 4,000. This is a numerical endpoint observation; convergence as the number of steps tends to infinity is supplied by the separate proof.

The graph experiments apply an explicit symmetric peer-scoring mask to perfect shared fair signals; each retained edge has weight `w=1/16`. Thus path and star graphs are a stated mechanism variant, while the unmasked two-agent and complete-triangle cases are direct native instances. Counts of grid configurations are diagnostic coverage, not estimates of how frequently real systems encounter these cases.

## Three concrete contrasts

1. **Opposite starting orientations are amplified equally.** In the two-agent native game, `d=(0.2,0.2)` approaches `(+1,+1)`, while `d=(0.2,−0.2)` approaches `(+1,−1)`. The signal distribution, payment, learning rate and determinant magnitudes are identical. Both limiting payments are 1/4. The payment and exact gradient do not supply an orientation correction.
2. **Stationarity does not imply Nash.** The recorded paired-grid trajectory starting at `d=(0,1/5)` leaves both channels unchanged, whereas `(1/5,1/5)` activates both agents and they approach their positive permutation limits. The exact static grid also verifies that the stationary profile `(0,1/2)` admits an agent-1 gain of exactly 1/16 by changing to either permutation. These non-Nash fixed points have perfectly informative private signals; they are not caused by weak model accuracy.
3. **Global connectivity does not activate a zero bridge.** A three-agent path initialized at `d=(1/2,0,−1/2)` stays completely stationary. The connected path initialized at `(1/2,−1/2,0)` moves the adjacent active pair toward opposite permutations, leaving the zero endpoint unchanged. The relevant graph is the initially active induced graph.

## Finite-batch estimator check, separate from the theorem

One prespecified score-function estimator was audited by exhaustive enumeration of 65,536 latent paths, using the noisy law and channels `(a_1,b_1)=(9/20,11/20)`, `(a_2,b_2)=(1/10,9/10)`. Native payment times the sum of conditional report likelihood derivatives is exactly unbiased: its mean own-channel gradient is `(−9/3125,+9/3125)`.

Nevertheless, 3.0040320368% of batches produce an estimated logit-separation increment opposed to the current orientation; 3.794355081% produce a nonzero row-logit-sum increment. These are exact event probabilities for this single estimator/configuration, not a stochastic convergence result, a measured orientation-flip rate, or a test of the released PEG update. A concrete positive-probability outcome and its score are retained in `raw/finite_batch_score_audit.json`. This check supports keeping deterministic invariants separate from estimated-gradient behavior; it need not occupy the main report.

## Reproduction and audit trail

From this directory:

```sh
python3 run_audit.py
python3 make_figures.py
```

The computation uses Python's standard library; plotting uses the existing Matplotlib installation. Reproduction overwrites the generated raw files in this directory, so copy the directory to a new run destination if preserving the current byte-for-byte run is required. `RAW_SHA256.json` records all original raw-output digests. `raw/checks.json` records the executable and frozen-plan digests, Python version, elapsed time, tolerances and every check result.

Frozen plan SHA-256: `ed4bc8eaa2aa1fd8a0fbf9e88aef6a489f4be1a76ed33d16485e16f064d7f406`.

The three figure pairs (PDF and PNG) are `figures/orientation_phase_portrait`, `figures/graph_stationarity_cases`, and `figures/curvature_audit`. Full captions, including sample counts and units, are in `figures/CAPTIONS.json`.

## Separately frozen manuscript-witness cross-check

After the original audit, the independent theory reviewer supplied the paper's preferred symmetric noisy witness: both private signals have accuracy 3/4, giving `U=[[5/16,3/16],[3/16,5/16]]`, `w=1/256`, and expected payment `d_1²d_2²/64`. Its verification was specified in `ADDENDUM_PLAN.json` before running, with outputs isolated in `raw_addendum/`. No original plan or raw result changed.

All 625 channel-grid cases exactly agree with the factorized expression. Two additional full latent enumerations, totaling 131,072 paths, also agree. Direct native-payment enumeration verifies that the stationary `(d_1,d_2)=(0,1/2)` profile pays zero, while agent 1's deviation to identity earns exactly `1/256`. These numbers are appropriate for the manuscript's symmetric noisy witness; the `1/16` gain and the figures above use the explicitly labeled perfect-shared-signal law.

Across the original run and this separately declared cross-check, there are 2,500 exact channel-grid equalities and eight full-latent comparisons totaling 401,408 paths. The finite-batch score-estimator check is a separate ninth latent enumeration and is not included in those eight comparisons. Reproduce the addendum with `verify_manuscript_witness.py` using the same interpreter.
