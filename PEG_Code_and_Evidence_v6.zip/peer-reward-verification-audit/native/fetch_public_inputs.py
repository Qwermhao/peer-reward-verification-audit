"""Fetch pinned public upstream files, checking both Git object and SHA256 hashes.

This downloader performs no model inference and needs no credentials. Do not run
untrusted upstream notebooks. The analysis scripts extract audited definitions only.
"""
import hashlib,json,urllib.request
from pathlib import Path

ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'PROVENANCE.json').read_text())
extra=json.loads((ROOT/'EXTRA_SOURCE_MANIFEST.json').read_text())
for item in manifest['files']+extra:
    dest=ROOT/item['path']
    url=f"https://raw.githubusercontent.com/{manifest['repo']}/{manifest['commit']}/{item['upstream_path']}"
    if dest.exists():
        content=dest.read_bytes()
        assert hashlib.sha256(content).hexdigest()==item['sha256'],f'Existing file mismatch: {dest}'
    else:
        with urllib.request.urlopen(url,timeout=60) as response:content=response.read()
        assert hashlib.sha256(content).hexdigest()==item['sha256'],url
        git_hash=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
        assert git_hash==item['git_blob_sha1'],url
        dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content)
    print(item['path'],item['sha256'])
# Reconstruct the exact audited source cells required by replay.py.
notebook=json.loads((ROOT/'sources'/'PEG_mechanism.ipynb').read_text())
for cell_id in ['fc917f7c','41b3904a','70c92c5e']:
    cell=next(c for c in notebook['cells'] if c.get('id')==cell_id)
    text=''.join(cell['source'])
    target=ROOT/'sources'/f'cell_{cell_id}.py'
    if target.exists():
        assert target.read_text().rstrip('\n')==text.rstrip('\n'),f'Existing extracted cell mismatch: {target}'
    else:target.write_text(text)
