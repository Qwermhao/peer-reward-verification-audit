import copy,json,time
import numpy as np
from replay import ROOT,load_data,MiniFrame,ORIGINAL,run

results=[]
for ds in ['gpqa','arc']:
    data=load_data(ds); n=data['n']; frames=[]
    for d in range(3):
        policies=[copy.deepcopy(x[d]) for x in data['refined']]
        policies += copy.deepcopy(policies[:8])
        gens=copy.deepcopy(data['generator'])+copy.deepcopy(data['generator'][:8])
        frames.append(MiniFrame({'disc_init_policy_refine':policies,'gen_init_policy':gens}))
    ORIGINAL['batch_update_discriminators_flexible'](*frames,choice_df=frames[0],batch_size=8,T_steps=10,learning_rate=.1)
    pure,pred,_=run(data['p'],data['choice'],'native_zscore')
    errors=[]; disagree=0
    for i in range(n):
        for d in range(3):
            original=frames[d]['updated_disc_policy'][i]
            for a,key in enumerate(data['keys'][i]):
                errors.extend([abs(pure[i,d,a,v]-original[key][k]) for v,k in enumerate(['correct','incorrect'])])
            orig_letter=frames[d]['updated_answer_letter'][i]
            disagree+=int(orig_letter!=data['keys'][i][pred[i,d]])
    r={'dataset':ds,'rows':n,'models':3,'max_absolute_policy_error':max(errors),
       'answer_disagreements':disagree,'policies_compared':n*3,'unused_tail_rows':8,
       'original_cell_unmodified':True,'adapter':'MiniFrame indexing only; original numerical functions unchanged'}
    assert max(errors)<1e-10 and disagree==0,r
    results.append(r);print(json.dumps(r),flush=True)
(ROOT/'results'/'full_equivalence.json').write_text(json.dumps(results,indent=2)+'\n')
