"""Verify all files listed in the current public package manifest."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "MANIFEST.json").read_text())
for record in manifest["files"]:
    path = ROOT / record["path"]
    if path.is_symlink() or ROOT not in path.resolve().parents:
        raise SystemExit("Invalid package path: " + record["path"])
    data = path.read_bytes()
    if len(data) != record["bytes"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
        raise SystemExit("Checksum mismatch: " + record["path"])
print("Verified " + str(len(manifest["files"])) + " published files.")
