# Derived magnitude diagnostics

After inspecting the frozen-grid outputs, add a descriptive magnitude summary using exactly the same saved seeds and draws. This is a reanalysis of the same simulated batches, not a new condition grid or an additional selected run.

Report RMS and mean absolute normalized separation-gradient magnitude, especially for the zero-orientation controls, to distinguish any nonzero activation from a substantial move. Reconstruct each existing cell and verify its previously saved event counts before reporting derived magnitudes. Keep the original script, plan and raw outputs unchanged.

Also record the analytically derived batch-score proposition separately. It is not used to change the frozen grid or select cells.
