from pathlib import Path
from fractions import Fraction as F
import ast,csv,hashlib,itertools,json,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'PLAN.json').read_text())
STATES=np.array(list(itertools.product(range(2),repeat=4)),dtype=np.int8)
tree=ast.parse((ROOT/'run_stochastic.py').read_text())
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'pay','inputs','masks','wilson'}]
exec(compile(ast.Module(body=nodes,type_ignores=[]),'audited_own_functions','exec'))
rows=list(csv.DictReader((ROOT/'raw/monte_carlo_cells.csv').open()))
exact=json.loads((ROOT/'raw/exact_K4.json').read_text())
ex={r['case']:r for r in exact}
derived=[]
for row in rows:
    q,d,e=map(F,[row['q'],row['d'],row['peer']]); k=int(row['K']);A=int(row['A'])
    a,b,di,off,pr,de,pn,sd,san,sbn=inputs(q,d,e)
    rng=np.random.default_rng(int(row['seed']))
    codes=rng.choice(16,size=(int(row['draws']),k),p=np.array([float(x) for x in pr]))
    p=pay(codes);ga=p*np.sum(san[codes],axis=1);gb=p*np.sum(sbn[codes],axis=1)
    events,margin=masks(p,ga,gb,sd,A,d,PLAN['normalized_step_sizes'])
    for name,mask in events.items():assert int(mask.sum())==int(row[name+'_count'])
    sep=(gb-ga).astype(float)/(A*sd)
    derived.append({'case':row['case'],'q':row['q'],'d':row['d'],'peer':row['peer'],'K':k,
                    'mean_abs_separation_gradient':float(np.mean(np.abs(sep))),
                    'rms_separation_gradient':float(np.sqrt(np.mean(sep**2))),
                    'std_separation_gradient':float(np.std(sep,ddof=1))})
with (ROOT/'raw/derived_magnitudes.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(derived[0]));w.writeheader();w.writerows(derived)

FIG=ROOT/'figures';FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.size':9,'axes.labelsize':9,'axes.titlesize':10,'legend.fontsize':9,'font.family':'DejaVu Sans'})
qualities=['3/5','3/4','9/10']; qualities_labels=['Signal accuracy 0.60','Signal accuracy 0.75','Signal accuracy 0.90']
fig,axes=plt.subplots(2,3,figsize=(6.5,4.7),sharex=True,sharey='row',layout='constrained')
colors={'1/5':'#0072B2','4/5':'#D55E00'}
styles={'1/5':'--','4/5':'-'}
for col,(q,lab) in enumerate(zip(qualities,qualities_labels)):
    for d in ['1/5','4/5']:
        for peer in ['1/5','4/5']:
            rr=[r for r in rows if r['q']==q and r['d']==d and r['peer']==peer]
            rr.sort(key=lambda r:int(r['K']))
            for ax,event in [(axes[0,col],'opposed_separation_increment'),(axes[1,col],'crossing_alpha_1')]:
                ys=[];lo=[];hi=[]
                for r in rr:
                    key=event+'_exact';p=float(r[key]) if r.get(key) else float(r[event+'_rate'])
                    ys.append(100*p)
                    lo.append(0 if r.get(key) else 100*(p-float(r[event+'_lo95'])))
                    hi.append(0 if r.get(key) else 100*(float(r[event+'_hi95'])-p))
                ax.errorbar([int(r['K']) for r in rr],ys,yerr=[lo,hi],color=colors[d],linestyle=styles[peer],marker='o',markersize=3,capsize=2,linewidth=1.3,label=f'own {float(F(d)):.1f}, peer {float(F(peer)):.1f}')
                ax.set_xscale('log',base=2);ax.set_xticks([4,8,16,32],['4','8','16','32']);ax.grid(axis='y',alpha=.2)
    axes[0,col].set_title(lab)
    axes[1,col].set_xlabel('Tasks per batch K')
axes[0,0].set_ylabel('Opposed increments (%)')
axes[1,0].set_ylabel('Sign crossings (%)')
axes[0,0].set_ylim(-1,50);axes[1,0].set_ylim(-.03,1.6)
handles,labels=axes[0,0].get_legend_handles_labels()
fig.legend(handles,labels,loc='outside lower center',ncol=2,frameon=False)
fig.suptitle('Finite-batch increments and one-step crossings (α = 1)',fontsize=10)
fig.savefig(FIG/'finite_batch_boundary.png',dpi=300)
fig.savefig(FIG/'finite_batch_boundary.pdf')
plt.close(fig)

# Complementary heatmap retains both initial signs and the stable small-step control.
q='3/4';peer='4/5'
fig,axes=plt.subplots(1,3,figsize=(6.5,3.2),layout='constrained')
ds=['-4/5','-1/5','1/5','4/5'];ks=[4,8,16,32]
for ax,al in zip(axes,[.1,1.,10.]):
    event=f'crossing_alpha_{al:g}'
    mat=[]
    for d in ds:
        line=[]
        for k in ks:
            r=next(r for r in rows if r['q']==q and r['d']==d and r['peer']==peer and int(r['K'])==k)
            line.append(100*(float(r[event+'_exact']) if r.get(event+'_exact') else float(r[event+'_rate'])))
        mat.append(line)
    im=ax.imshow(mat,cmap='YlOrRd',vmin=0,vmax=15,aspect='auto')
    for i,line in enumerate(mat):
        for j,val in enumerate(line):ax.text(j,i,f'{val:.2f}',ha='center',va='center',fontsize=9,color='black')
    ax.set_xticks(range(4),ks);ax.set_yticks(range(4),[-.8,-.2,.2,.8]);ax.set_xlabel('Tasks per batch K');ax.set_title(f'Normalized step α = {al:g}')
axes[0].set_ylabel('Initial own orientation')
fig.colorbar(im,ax=axes,label='Crossing probability (%)',shrink=.85)
fig.suptitle('Step size changes actual orientation crossings',fontsize=10)
fig.savefig(FIG/'step_size_crossings.png',dpi=300);fig.savefig(FIG/'step_size_crossings.pdf');plt.close(fig)

checks={'same_seed_event_counts_reproduced':len(derived),'all_matched':True,'new_draws_or_conditions':False}
(ROOT/'raw/derived_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks))
