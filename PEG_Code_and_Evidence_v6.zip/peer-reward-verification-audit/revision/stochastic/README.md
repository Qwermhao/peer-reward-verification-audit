# Reproduce the stochastic boundary analysis

The primary experiment was frozen in `PLAN.json` before outcomes. Its raw results are immutable. The later `DIAGNOSTIC_ADDENDUM.md` records derived magnitude/plot work on the same samples; `oracle_centering/PLAN.json` separately freezes a same-draw control before that control's output. No external API or model inference is used.

Requirements: Python 3, NumPy, Matplotlib. This run used the existing environment at `python3`. No packages or weights were downloaded.

To reproduce, make a **new working copy** containing `PLAN.json`, `run_stochastic.py`, `derive_and_plot.py`, and the two oracle-centering source files (`PLAN.json`, `run_control.py`) in their current relative locations. Do not copy result directories into that new working copy. Run, from the copy:

```sh
python run_stochastic.py
python derive_and_plot.py
python oracle_centering/run_control.py
```

`run_stochastic.py` refuses to run over an existing `raw/` directory. The oracle control likewise refuses to replace `results.csv`. Plotting reconstructs the same draws, asserts all stored event counts, and writes derived summaries and figures. NumPy's seeded random generator is deterministic within the recorded environment; use exact K4 checks to verify an environment port.

Read `SUMMARY.md` first for manuscript-ready prose, audited maxima, and interpretation. `PROPOSITION.md` gives the estimator-specific asymptotic result. `FIGURE_CAPTIONS.md` records conditions and figure meanings. `raw/monte_carlo_cells.csv` retains counts, intervals, seeds, gradient means and standard errors for every cell. `raw/exact_K4.json` retains exact rational event masses and coordinate expectations. `raw/checks.json` records primary frozen hashes and verification; the oracle folder has a separate check record. `MANIFEST.json` hashes the complete local payload, including retained earlier figure layouts.

Terminology correction: “native” in the original frozen plan refers to raw count-DMI payment, not the released PEG implementation. The final report uses “raw-count” throughout this estimator analysis. The frozen original is retained for auditability.
