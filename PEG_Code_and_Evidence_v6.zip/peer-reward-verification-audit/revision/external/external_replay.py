import ast,copy,csv,hashlib,json,random,time,re
from pathlib import Path
import numpy as np
from replay_core import ROOT,ORIGINAL,MiniFrame,run,majority,SEEDS

CORE=['oqwen_7B','deepseek_qwen_7B','deepseek_llm_7b']
CONFIGS=[('mmlu','mmlu_policy_df_',CORE),('arc_easy','arc_policy_df_easy_',CORE),
         ('arc_alternative','arc_policy_df_',['ai_Yi_9B','Mistral-7B-Instruct','gemma-7b-it'])]

def parse_policy(text):
    # Source-defined parser from PEG_mechanism_added.ipynb cell e7ceb640.
    return ast.literal_eval(re.sub(r'np\.float32\((.*?)\)',r'\1',text))

def load(config):
    name,prefix,models=config
    rows=[list(csv.DictReader((ROOT/'raw'/f'{prefix}{m}.csv').open())) for m in models]
    released=[len(x) for x in rows];assert len(set(released))==1,(name,released)
    n=released[0]//8*8;labels=[];refined=[];gens=[];gold=[];ids=[];numeric_count=0
    for i in range(released[0]):
        for d in [1,2]:
            for field in ['question','choices','answer' if name=='mmlu' else 'answerKey']:
                assert rows[0][i][field]==rows[d][i][field],(name,i,d,field)
    for i in range(n):
        pol=[parse_policy(rows[d][i]['disc_init_policy']) for d in range(3)]
        keys=list(pol[0]);assert all(list(p)==keys for p in pol),(name,i,'policy_options')
        labels.append(keys);refined.append([ORIGINAL['apply_softmax'](p) for p in pol])
        gens.append(parse_policy(rows[0][i]['gen_init_policy']))
        if name=='mmlu':g=int(rows[0][i]['answer'])
        else:
            raw=rows[0][i]['answerKey']
            if raw.isdigit():
                g=int(raw)-1;numeric_count+=1
                # Audit explicit original choice labels in the numpy-array repr.
                import re
                match=re.search(r"'label': array\(\[([^]]+)\]",rows[0][i].get('choices_dic',''))
                if match:
                    original=ast.literal_eval('['+match.group(1)+']');assert original[g]==raw
            else:g=keys.index(raw)
        assert 0<=g<len(keys),(name,i,g,keys)
        gold.append(g);ids.append(rows[0][i].get('id') or hashlib.sha256(rows[0][i]['question'].encode()).hexdigest())
    width=max(map(len,labels));p=np.zeros((n,3,width,2));choice=np.empty(n,dtype=int)
    for i in range(n):
        for d in range(3):
            for a,k in enumerate(labels[i]):p[i,d,a]=[refined[i][d][k]['correct'],refined[i][d][k]['incorrect']]
        gen=max(gens[i]['correct'],key=gens[i]['correct'].get);choice[i]=labels[i].index(gen)
    return dict(name=name,models=models,n=n,released=released[0],labels=labels,refined=refined,gens=gens,p=p,choice=choice,gold=np.asarray(gold),ids=ids,numeric_labels=numeric_count)

def metrics(pred,gold,initial):
    valid=pred>=0;right=pred==gold;before=initial==gold
    return {'n':len(gold),'correct':int(right.sum()),'all_row_accuracy':float(right.mean()),
       'answered':int(valid.sum()),'coverage':float(valid.mean()),'conditional_accuracy':float(right.sum()/valid.sum()) if valid.any() else None,
       'changed':int((pred!=initial).sum()),'wrong_to_right':int((~before&right).sum()),'right_to_wrong':int((before&~right).sum())}

def verify(data,pred,pure):
    frames=[];n=data['n']
    for d in range(3):
        pol=[copy.deepcopy(x[d]) for x in data['refined']]
        frames.append(MiniFrame({'disc_init_policy_refine':pol+copy.deepcopy(pol[:8]),
                                'gen_init_policy':copy.deepcopy(data['gens'])+copy.deepcopy(data['gens'][:8])}))
    ORIGINAL['batch_update_discriminators_flexible'](*frames,choice_df=frames[0])
    maxerr=0.;mismatches=0
    for i in range(n):
        for d in range(3):
            original=frames[d]['updated_disc_policy'][i]
            for a,k in enumerate(data['labels'][i]):
                maxerr=max(maxerr,max(abs(pure[i,d,a,v]-original[k][key]) for v,key in enumerate(['correct','incorrect'])))
            mismatches+=int(frames[d]['updated_answer_letter'][i]!=data['labels'][i][pred[i,d]])
    assert maxerr<1e-10 and mismatches==0,(data['name'],maxerr,mismatches)
    return dict(rows=n,model_question_policies=n*3,max_absolute_policy_error=maxerr,answer_mismatches=mismatches,unused_trailing_rows=8)

def certificate(data):
    p=data['p'];n=data['n'];ii=np.arange(n)[:,None];dd=np.arange(3)[None,:];cc=data['choice'][:,None]
    pair=p[ii,dd,cc,:];r=np.clip(pair[:,:,0]/pair.sum(axis=-1),1e-6,1-1e-6)
    other=p[:,:,:,0].copy();other[ii,dd,cc]=-np.inf
    margins=r-other.max(axis=2);second=np.sort(margins,axis=1)[:,-2]
    return margins,{'certified_rows':int((second>0).sum()),'certified_fraction':float((second>0).mean()),
       'minimum_second_largest_margin':float(second.min()),
       'per_model_minimum_margin':{m:float(margins[:,d].min()) for d,m in enumerate(data['models'])},
       'per_model_strictly_positive_rows':{m:int((margins[:,d]>0).sum()) for d,m in enumerate(data['models'])}}

def evaluate(config):
    start=time.time();data=load(config);n=data['n'];gold=data['gold'];init=data['p'][:,:,:,0].argmax(axis=2)
    initial=np.column_stack([init,majority(init)]);names=data['models']+['majority']
    margins,cert=certificate(data)
    result={'dataset':data['name'],'models':data['models'],'generator':data['models'][0],
      'released_rows':data['released'],'cohort_rows':n,'alignment':'exact across all released rows',
      'canonical_numeric_arc_labels':data['numeric_labels'],'certificate':cert,
      'baselines':{m:metrics(initial[:,d],gold,initial[:,d]) for d,m in enumerate(names)},'runs':[]}
    result['baselines']['generator']=metrics(data['choice'],gold,data['choice'])
    arrays={c:[] for c in ['native_zscore','zero_reward']}
    for seed in SEEDS:
        perm=list(range(n))
        if seed is not None:random.Random(seed).shuffle(perm)
        perm=np.asarray(perm);inv=np.argsort(perm);pair_outputs={}
        for cond in arrays:
            pure,pred,trace=run(data['p'][perm],data['choice'][perm],cond,trace=seed is None)
            if seed is None and cond=='native_zscore':result['equivalence']=verify(data,pred,pure)
            pred=pred[inv];out=np.column_stack([pred,majority(pred)]);arrays[cond].append(out);pair_outputs[cond]=out
            entry={'seed':seed,'condition':cond,'metrics':{m:metrics(out[:,d],gold,initial[:,d]) for d,m in enumerate(names)},
                   'generator_matches':{m:int((out[:,d]==data['choice']).sum()) for d,m in enumerate(names)}}
            if seed is None:
                entry['batch_zero_raw_rewards']=[int(np.all(np.asarray(t['raw'])==0,axis=1).sum()) for t in trace]
                entry['batches']=n//8
            result['runs'].append(entry)
        agree={m:int((pair_outputs['native_zscore'][:,d]==pair_outputs['zero_reward'][:,d]).sum()) for d,m in enumerate(names)}
        result.setdefault('native_zero_agreement',[]).append({'seed':seed,'counts':agree,'n':n,
             'majority_fraction':agree['majority']/n})
    result['regrouping_summary']={}
    for c,aa in arrays.items():
        a=np.stack(aa);acc=(a[1:,:,-1]==gold).mean(axis=1);gen=(a[1:,:,-1]==data['choice']).mean(axis=1)
        result['regrouping_summary'][c]={'majority_accuracy_min':float(acc.min()),'majority_accuracy_mean':float(acc.mean()),
         'majority_accuracy_max':float(acc.max()),'majority_generator_agreement_min':float(gen.min()),
         'majority_generator_agreement_mean':float(gen.mean()),'majority_generator_agreement_max':float(gen.max()),
         'noninvariant_majority_rows':int(np.any(a[1:,:,-1]!=a[0,:,-1],axis=0).sum())}
    ng=[r['majority_fraction'] for r in result['native_zero_agreement'][1:]]
    result['regrouping_native_zero_agreement']={'min':min(ng),'mean':float(np.mean(ng)),'max':max(ng)}
    result['certificate']['observed_zero_certificate_violations']=int(((np.sort(margins,axis=1)[:,-2]>0)&(arrays['zero_reward'][0][:,-1]!=data['choice'])).sum())
    np.savez_compressed(ROOT/'results'/f'{data["name"]}_predictions.npz',native_zscore=np.stack(arrays['native_zscore']),
       zero_reward=np.stack(arrays['zero_reward']),gold=gold,generator=data['choice'],initial=initial,margins=margins)
    with (ROOT/'results'/f'{data["name"]}_rows.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['row','source_id_or_question_sha256','choice_labels','canonical_gold'])
        for i in range(n):w.writerow([i,data['ids'][i],json.dumps(data['labels'][i]),data['labels'][i][gold[i]]])
    result['seconds']=time.time()-start
    (ROOT/'results'/f'{data["name"]}_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'dataset':data['name'],'n':n,'equivalence':result['equivalence'],'certificate':cert,
      'initial':result['baselines']['majority'],'generator':result['baselines']['generator'],
      'original':[{'condition':r['condition'],'majority':r['metrics']['majority'],'generator_matches':r['generator_matches']['majority']} for r in result['runs'] if r['seed'] is None],
      'native_zero':result['native_zero_agreement'][0],'regrouping':result['regrouping_native_zero_agreement']}),flush=True)

if __name__=='__main__':
    (ROOT/'results').mkdir(exist_ok=True)
    for config in CONFIGS:
        if (ROOT/'results'/f'{config[0]}_summary.json').exists():
            print('Retaining completed results for '+config[0],flush=True)
        else:evaluate(config)
