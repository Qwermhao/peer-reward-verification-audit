# What Peer Rewards Amplify

**Theory and a Zero-Reward Audit of AI Verification**  
Jiahao Chen, independent researcher. Revised 16 November 2026.

Code and reproducibility evidence for *What Peer Rewards Amplify: Orientation Basins and a Zero-Reward PEG Control*. This repository accompanies the Apart Research AI × Epistemics Research Sprint project. The report PDF is submitted separately.

## Results

- **Exact theory.** A complete classification of orientation basins and Nash limits for a specified binary, task-consistent determinant mutual information (DMI) entropy learner. Verification covers 2,500 exact expected-payment cases and eight latent enumerations spanning 401,408 paths.
- **A directly executable control.** The released Peer Elicitation Games (PEG) update can copy a fixed generator through selected-answer normalization even when every reward is zero. The certificate is derived from the update and checked against the original numerical functions.
- **Matched replay.** Native rewards, zero rewards, and the fixed generator give identical original-order majority answers on all 448 GPQA and 1,168 ARC-Challenge questions. Across twenty regroupings, native and zero rewards differ on only 13 of 32,320 question-order comparisons.
- **Additional cohorts.** Validation adds 13,864 MMLU and 2,368 ARC-Easy questions, plus another model trio on the same ARC-Challenge questions. Original-order native–zero majority agreement is 99.23–99.92% in these additional configurations. The full study has 17,848 distinct questions and 19,016 cohort evaluations.
- **Finite-batch checks.** A separately specified 120-configuration study covers 2.4 million sampled batches, exact size-four enumeration, and a same-draw oracle-centering control.

The exact learner and the public per-question program are separate objects. The matched controls identify reward, normalization, and coverage effects in the fixed released model outputs. No new model inference is performed.

## Evidence map

| Component | Start here | Saved results |
|---|---|---|
| Exact dynamics and payment | [Theory and proof](theory/THEOREM_AND_PROOF.md), [exact audit instructions](exact/REPRODUCE.md) | `exact/raw/`, `exact/raw_addendum/` |
| Original public-program replay | [Native replay](native/README.md) | `native/results/` |
| Order and coverage analysis | [Summary](revision/order_coverage/SUMMARY.md) | `revision/order_coverage/` CSVs and certificate |
| Added datasets and model trio | [External validation](revision/external/README.md) | `revision/external/results/` |
| Stochastic estimator boundary | [Stochastic study](revision/stochastic/README.md), [proposition](revision/stochastic/PROPOSITION.md) | `revision/stochastic/raw/`, `oracle_centering/` |
| Independent numerical checks | [Validation instructions](validation/README.md) | `validation/`, `revision/validation/` |

The `revision/` summaries contain the integrated follow-up results. Earlier component summaries are retained as scientific records. Protocols are locally frozen plans, not an external preregistration.

## Reproduce

Python 3.9+ is used by the standard-library exact checks. The recorded analysis environment was Python 3.14.5, NumPy 2.5.4, and Matplotlib 3.11.2. NumPy is needed for replay and stochastic work; Matplotlib is needed for plots. No API keys, paid services, model weights, or GPU are required.

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
```

The helper below always creates a **new working copy outside this repository**. It preserves the published results and removes only the selected component's generated files from that new copy before running. Pick a component:

```sh
python tools/reproduce.py exact --output ../peg-exact-reproduction
python tools/reproduce.py native --output ../peg-native-reproduction
python tools/reproduce.py order --output ../peg-order-reproduction
python tools/reproduce.py external --output ../peg-external-reproduction
python tools/reproduce.py stochastic --output ../peg-stochastic-reproduction
```

`native`, `order`, and `external` first download hash-pinned public inputs. Their subsequent analysis runs offline. Exact and stochastic studies need no downloads. The stochastic study repeats 2.4 million sampled batches and can take longer than the other checks. Component READMEs describe individual commands, assumptions, and expected outputs.

To check the published files against the current package manifest:

```sh
python tools/verify_manifest.py
```

## Provenance and distribution

The PEG implementation and released probability files are pinned to [`toz015/neurips2025-repo`, commit `0ade29f05ffca0081bfc4653966c0496b24f2630`](https://github.com/toz015/neurips2025-repo/tree/0ade29f05ffca0081bfc4653966c0496b24f2630). Input manifests retain upstream paths, sizes, Git object hashes, and SHA-256 hashes. The downloaders verify the originals before use and extract named numerical definitions from specific notebook cells. They never run notebook top-level code.

Upstream probability CSVs, notebooks, papers, benchmark question text, and the official GPQA archive are **not mirrored here**. The original PEG repository has no license file. Derived row records contain identifiers/hashes and labels rather than question text. Dataset and upstream rights remain with their respective authors.

This public tree contains the latest v6 program and evidence. Internal editorial reviews, working logs, old drafts, report PDFs, local environments, and caches are omitted. A few documentary local-path references were made portable. Component hash files describe historical research snapshots and can mention files omitted from this public distribution; `MANIFEST.json` is the current public-file inventory and checksum record.

See [NOTICE.md](NOTICE.md) for authorship and third-party provenance.
