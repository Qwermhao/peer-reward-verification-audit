#!/usr/bin/env python3
"""Predeclared CPU-only binary DMI audit. Run from this file's directory."""
from __future__ import annotations
import csv, hashlib, itertools, json, math, random, sys, time
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PLAN = json.loads((ROOT/'PLAN.json').read_text())
A = F(4)
START = time.time()
CHECKS = []
RAW = ROOT/'raw'
RAW.mkdir(exist_ok=True)

def check(name, condition, **details):
    CHECKS.append({'name': name, 'passed': bool(condition), **details})

def csvwrite(name, rows):
    with (RAW/name).open('w', newline='') as fh:
        out = csv.DictWriter(fh, fieldnames=list(rows[0]))
        out.writeheader(); out.writerows(rows)

def det2(q):
    return q[0][0]*q[1][1]-q[0][1]*q[1][0]

def native_payment(reports):
    ds=[]
    for block in (reports[:2], reports[2:]):
        counts=[[0,0],[0,0]]
        for r,s in block: counts[r][s]+=1
        ds.append(counts[0][0]*counts[1][1]-counts[0][1]*counts[1][0])
    return ds[0]*ds[1]

REPORTS = list(itertools.product(range(2), repeat=2))
PAYMENT_PATHS = [(path, native_payment(path)) for path in itertools.product(REPORTS, repeat=4)]
NONZERO_PATHS = [(p,v) for p,v in PAYMENT_PATHS if v]

def p_report(channel, signal, report):
    p=channel[signal]
    return p if report else 1-p

def enumerated_expectation(U, left, right):
    # Explicit marginalization; deliberately does not call matrix multiplication,
    # determinant factorization, or the formula used as the comparison oracle.
    report_mass={}
    for r,s in REPORTS:
        report_mass[(r,s)]=sum((U[c][d]*p_report(left,c,r)*p_report(right,d,s)
                               for c,d in REPORTS),F(0))
    value=F(0)
    for path,payment in NONZERO_PATHS:
        prob=F(1)
        for outcome in path: prob*=report_mass[outcome]
        value+=payment*prob
    return value

def factorized(U,left,right):
    return A*(left[1]-left[0])**2*(right[1]-right[0])**2*det2(U)**2

def latent_enumeration(U,left,right,score=False):
    outcomes=[]
    for c,d,r,s in itertools.product(range(2),repeat=4):
        p=U[c][d]*p_report(left,c,r)*p_report(right,d,s)
        if not p: continue
        ga=(F(r)/left[0]-F(1-r)/(1-left[0])) if score and c==0 else F(0)
        gb=(F(r)/left[1]-F(1-r)/(1-left[1])) if score and c==1 else F(0)
        outcomes.append(((r,s),p,ga,gb,(c,d,r,s)))
    value=F(0); eg_a=F(0); eg_b=F(0); wrong=F(0); meanmove=F(0); witness=None
    orientation=1 if left[1]>left[0] else -1
    for path in itertools.product(outcomes,repeat=4):
        payment=native_payment([x[0] for x in path])
        if not payment: continue
        prob=math.prod(x[1] for x in path)
        value+=prob*payment
        if score:
            ga=payment*sum(x[2] for x in path)
            gb=payment*sum(x[3] for x in path)
            eg_a+=prob*ga; eg_b+=prob*gb
            if orientation*(gb-ga)<0:
                wrong+=prob
                if witness is None:
                    witness={'task_outcomes_c1_c2_r1_r2':[x[4] for x in path],
                             'payment':payment,'gradient_a':str(ga),'gradient_b':str(gb),'path_probability':str(prob)}
            if ga+gb!=0: meanmove+=prob
    return {'value':value,'paths':len(outcomes)**4,'expected_ga':eg_a,'expected_gb':eg_b,
            'wrong_separation_probability':wrong,'nonzero_logit_sum_probability':meanmove,'witness':witness}

def exact_suite():
    rows=[]; latent=[]
    vals=list(map(F,PLAN['static_grid']['row_probabilities']))
    laws={name:[[F(x) for x in row] for row in mat] for name,mat in PLAN['signal_laws'].items()}
    for name,U in laws.items():
        check('signal law sums to one: '+name,sum(map(sum,U))==1)
        for aa,bb,cc,dd in itertools.product(vals, repeat=4):
            observed=enumerated_expectation(U,(aa,bb),(cc,dd))
            analytic=factorized(U,(aa,bb),(cc,dd))
            rows.append(dict(signal_law=name,a1=str(aa),b1=str(bb),a2=str(cc),b2=str(dd),
                             d1=str(bb-aa),d2=str(dd-cc),enumerated=str(observed),factorized=str(analytic),equal=observed==analytic))
        for channels in PLAN['full_latent_crosscheck']['channels']:
            c1,c2=[tuple(map(F,c)) for c in channels]
            result=latent_enumeration(U,c1,c2)
            expected=factorized(U,c1,c2)
            latent.append(dict(signal_law=name,channels=str(channels),paths=result['paths'],
                               expected=str(expected),latent_enumerated=str(result['value']),equal=result['value']==expected))
    csvwrite('exact_expectations.csv',rows); csvwrite('latent_crosschecks.csv',latent)
    check('all 1875 exhaustive report-space expectations match exact factorization',len(rows)==1875 and all(r['equal'] for r in rows))
    check('all six full latent enumerations match',len(latent)==6 and all(r['equal'] for r in latent))
    curve=[]
    U=laws['perfect_shared_fair']
    for e in map(F,PLAN['curvature']['epsilon_values']):
        for mode in ['boundary_near_identity','full_support_near_identity']:
            a=F(0) if mode.startswith('boundary') else e
            bs=[1-k*e for k in ([0,1,2] if mode.startswith('boundary') else [1,2,3])]
            pay=[enumerated_expectation(U,(a,b),(F(0),F(1))) for b in bs]
            gap=(pay[0]+pay[2])/2-pay[1]
            curve.append(dict(path=mode,epsilon=str(e),a=str(a),b_left=str(bs[0]),b_mid=str(bs[1]),b_right=str(bs[2]),
                              u_left=str(pay[0]),u_mid=str(pay[1]),u_right=str(pay[2]),midpoint_convexity_gap=str(gap),predicted=str(e*e/4),equal=gap==e*e/4))
    csvwrite('curvature.csv',curve)
    check('strict convex midpoint gap at every predeclared scale',all(F(r['midpoint_convexity_gap'])>0 and r['equal'] for r in curve))
    splan=PLAN['score_function_audit']; U=laws[splan['signal_law']]
    c1,c2=[tuple(map(F,c)) for c in splan['channels']]
    result=latent_enumeration(U,c1,c2,score=True)
    gb=2*A*(c1[1]-c1[0])*(c2[1]-c2[0])**2*det2(U)**2
    check('finite-batch score gradient exactly unbiased',result['expected_ga']==-gb and result['expected_gb']==gb)
    sf={k:str(v) if isinstance(v,F) else v for k,v in result.items()}
    sf.update({'expected_gradient_a_formula':str(-gb),'expected_gradient_b_formula':str(gb),
               'scope':'One fixed score-function estimator, not the released PEG update and not a stochastic convergence experiment'})
    (RAW/'finite_batch_score_audit.json').write_text(json.dumps(sf,indent=2)+'\n')
    print(json.dumps({'phase':'exact','grid_cases':len(rows),'latent_paths':sum(r['paths'] for r in latent),
                      'all_exact_checks_pass':all(c['passed'] for c in CHECKS),'elapsed_sec':round(time.time()-START,2)}),flush=True)

GRAPHS={
 'pair':(2,[(0,1)]),'path3':(3,[(0,1),(1,2)]),'triangle3':(3,[(0,1),(1,2),(0,2)]),
 'edge_plus_isolate3':(3,[(0,1)]),'star4':(4,[(0,1),(0,2),(0,3)]),
 'two_disjoint_edges4':(4,[(0,1),(2,3)]),'empty3':(3,[])}

def neighbors(n,edges):
    out=[[] for _ in range(n)]
    for i,j in edges: out[i].append(j); out[j].append(i)
    return out

def graph_suite():
    profiles=[]; limits=[]
    vals=list(map(F,PLAN['static_nash']['determinants']))
    for name,(n,edges) in GRAPHS.items():
        adj=neighbors(n,edges)
        for ds in itertools.product(vals,repeat=n):
            coeff=[sum((ds[j]**2/F(16) for j in adj[i]),F(0))*A for i in range(n)]
            gaps=[coeff[i]*(1-ds[i]**2) for i in range(n)]
            stationary=all(ds[i]*coeff[i]==0 for i in range(n))
            profiles.append(dict(graph=name,d=str(tuple(map(str,ds))),stationary=stationary,nash=all(g==0 for g in gaps),
                                  max_unilateral_gain=str(max(gaps)),all_gaps=str(tuple(map(str,gaps)))))
        for bits in itertools.product([False,True],repeat=n):
            limit=[(F(1) if any(bits[j] for j in adj[i]) else F(1,2)) if bits[i] else F(0) for i in range(n)]
            gaps=[A*sum((limit[j]**2/F(16) for j in adj[i]),F(0))*(1-limit[i]**2) for i in range(n)]
            cross=any(bits[i]!=bits[j] for i,j in edges)
            computed=all(g==0 for g in gaps)
            limits.append(dict(graph=name,active_set=str([i for i in range(n) if bits[i]]),
                               predicted_limit=str(tuple(map(str,limit))),crossing_edge=cross,nash_from_best_response=computed,
                               classification_correct=computed==(not cross),max_unilateral_gain=str(max(gaps))))
    csvwrite('static_profiles.csv',profiles); csvwrite('graph_limit_classification.csv',limits)
    check('all active-set limit Nash classifications agree with independent best-response gaps',all(r['classification_correct'] for r in limits))
    witnesses=[r for r in profiles if r['graph']=='pair' and r['d']==str(('0','1/2'))]
    check('stationary non-Nash pair detected',len(witnesses)==1 and witnesses[0]['stationary'] and not witnesses[0]['nash'] and F(witnesses[0]['max_unilateral_gain'])==F(1,16))
    return profiles,limits

def sigmoid(x):
    if x>=0:return 1/(1+math.exp(-x))
    ex=math.exp(x);return ex/(1+ex)

def z_for(m,d):
    if d==0:return 0.0
    sign=1 if d>0 else -1; lo=0.;hi=50.
    for _ in range(80):
        z=(lo+hi)/2
        if sigmoid(m+z)-sigmoid(m-z)<abs(d):lo=z
        else:hi=z
    return sign*(lo+hi)/2

def step(x,y,adj,eta):
    ds=[sigmoid(yy)-sigmoid(xx) for xx,yy in zip(x,y)]
    delta=[.5*eta[i]*ds[i]*sum(ds[j]**2 for j in adj[i]) for i in range(len(ds))]
    return [xx-d for xx,d in zip(x,delta)],[yy+d for yy,d in zip(y,delta)]

def trajectory(case,graph,ds0,ms,steps=4000,eta=.5,sample_every=20):
    n,edges=GRAPHS[graph];adj=neighbors(n,edges)
    zs=[z_for(m,d) for m,d in zip(ms,ds0)]
    x=[m-z for m,z in zip(ms,zs)]; y=[m+z for m,z in zip(ms,zs)]
    initial_x=x[:];initial_y=y[:]; previous=ds0[:]
    growing=[d!=0 and any(ds0[j]!=0 for j in adj[i]) for i,d in enumerate(ds0)]
    err_sign=0;err_mon=0.;err_sum=0.;err_stationary=0.;err_bound=0.; records=[]
    for t in range(steps+1):
        ds=[sigmoid(yy)-sigmoid(xx) for xx,yy in zip(x,y)]
        for i in range(n):
            if ds0[i]==0:err_sign=max(err_sign,int(ds[i]!=0))
            else:err_sign=max(err_sign,int(ds[i]*ds0[i]<=0))
            err_mon=max(err_mon,abs(previous[i])-abs(ds[i]))
            err_sum=max(err_sum,abs(x[i]+y[i]-2*ms[i]))
            if not growing[i]:err_stationary=max(err_stationary,abs(x[i]-initial_x[i]),abs(y[i]-initial_y[i]))
            if growing[i]:
                # The bound uses the strongest single initial active neighbor,
                # as in the proof; the actual update sums all neighbors.
                c=.5*abs(ds0[i])*max(ds0[j]**2 for j in adj[i])
                err_bound=max(err_bound,abs(zs[i])+c*eta*t-abs((y[i]-x[i])/2))
            if t%sample_every==0 or t==steps:
                records.append(dict(case=case,graph=graph,step=t,agent=i,a=sigmoid(x[i]),b=sigmoid(y[i]),d=ds[i],
                                    logit_a=x[i],logit_b=y[i],m_initial=ms[i],d_initial=ds0[i],predicted_growing=growing[i]))
        previous=ds
        if t<steps:x,y=step(x,y,adj,[eta]*n)
    summary=dict(case=case,graph=graph,initial_d=ds0,final_d=ds,growing=growing,
                 maximum_corner_error=max([1-abs(ds[i]) for i in range(n) if growing[i]],default=0),
                 sign_violations=err_sign,max_abs_d_decrease=err_mon,max_logit_sum_drift=err_sum,
                 max_stationary_logit_change=err_stationary,max_rate_bound_violation=err_bound)
    return records,summary

def dynamics_suite():
    data=[]; summaries=[]
    grid=list(map(lambda s:float(F(s)),PLAN['dynamics']['orientation_grid']))
    for i,(d1,d2) in enumerate(itertools.product(grid,repeat=2)):
        rows,summ=trajectory(f'pair_grid_{i:02d}','pair',[d1,d2],[0.,0.]);data+=rows;summaries.append(summ)
    graphcases=[
     ('path_zero_bridge','path3',[.5,0.,-.5]),
     ('path_active_pair_inactive_endpoint','path3',[.5,-.5,0.]),
     ('triangle_mixed_orientation','triangle3',[.5,-.5,.5]),
     ('edge_plus_isolate','edge_plus_isolate3',[.5,-.5,.5]),
     ('star_zero_center','star4',[0.,.5,-.5,.5]),
     ('star_active_center','star4',[.5,0.,-.5,.5]),
     ('disjoint_mixed_orientation','two_disjoint_edges4',[.5,-.5,0.,.5]),
     ('empty','empty3',[.5,0.,-.5])]
    centers=list(map(float,PLAN['dynamics']['heterogeneous_centers']))
    for case,graph,ds in graphcases:
        rows,summ=trajectory(case,graph,ds,centers[:len(ds)]);data+=rows;summaries.append(summ)
    csvwrite('dynamics.csv',data)
    (RAW/'dynamics_summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
    for key,tol in [('sign_violations',0),('max_abs_d_decrease',1e-13),('max_logit_sum_drift',1e-10),
                    ('max_stationary_logit_change',1e-13),('max_rate_bound_violation',1e-10)]:
        value=max(s[key] for s in summaries)
        check('predeclared trajectories: '+key,value<=tol,maximum=value,tolerance=tol)
    check('all graph-predicted growing coordinates reach numerical corner tolerance',
          max(s['maximum_corner_error'] for s in summaries)<1e-8,
          maximum_error=max(s['maximum_corner_error'] for s in summaries),steps=4000)
    rng=random.Random(PLAN['seed']); bad=0; monotone=0.;sumerr=0.;updateerr=0.;stationaryerr=0.
    for case in range(256):
        n=[2,3,4,5][case%4]
        edges=[(i,j) for i in range(n) for j in range(i+1,n) if rng.random()<.5]
        adj=neighbors(n,edges)
        x=[rng.uniform(-3,3) for _ in range(n)];y=[rng.uniform(-3,3) for _ in range(n)]
        for i in range(n):
            if rng.random()<.25:y[i]=x[i]
        x0=x[:];y0=y[:];old=[sigmoid(yy)-sigmoid(xx) for xx,yy in zip(x,y)];d0=old[:]
        for t in range(100):
            eta=[rng.uniform(0,4) for _ in range(n)]
            xx,yy=step(x,y,adj,eta)
            if t==0:
                # Independently evaluate the normalized exponentiated row weights.
                for i in range(n):
                    g=.5*old[i]*sum(old[j]**2 for j in adj[i])
                    for p,gradient,newlogit in [(sigmoid(x[i]),-g,xx[i]),(sigmoid(y[i]),g,yy[i])]:
                        weight=p*math.exp(eta[i]*gradient)
                        independently=weight/(1-p+weight)
                        updateerr=max(updateerr,abs(independently-sigmoid(newlogit)))
            x,y=xx,yy;ds=[sigmoid(b)-sigmoid(a) for a,b in zip(x,y)]
            for i in range(n):
                bad+=int((d0[i]==0 and ds[i]!=0) or (d0[i]!=0 and ds[i]*d0[i]<=0))
                monotone=max(monotone,abs(old[i])-abs(ds[i]))
                sumerr=max(sumerr,abs(x[i]+y[i]-x0[i]-y0[i]))
                if d0[i]==0 or all(d0[j]==0 for j in adj[i]):
                    stationaryerr=max(stationaryerr,abs(x[i]-x0[i]),abs(y[i]-y0[i]))
            old=ds
    for name,value,tol in [('sign_violations',bad,0),('absolute_d_decrease',monotone,1e-13),('logit_sum_drift',sumerr,1e-10),
                           ('stationary_change',stationaryerr,1e-13),('independent_exponentiated_weight_agreement',updateerr,1e-13)]:
        check('256 seeded property cases: '+name,value<=tol,maximum=value,tolerance=tol)
    print(json.dumps({'phase':'dynamics','trajectories':len(summaries),'raw_rows':len(data),
                      'all_checks_pass':all(c['passed'] for c in CHECKS),'elapsed_sec':round(time.time()-START,2)}),flush=True)

def finish():
    info={'data_type':PLAN['data_type'],'plan_sha256':hashlib.sha256((ROOT/'PLAN.json').read_bytes()).hexdigest(),
          'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':sys.version,
          'seed':PLAN['seed'],'elapsed_seconds':time.time()-START,'checks':CHECKS,
          'all_passed':all(c['passed'] for c in CHECKS)}
    (RAW/'checks.json').write_text(json.dumps(info,indent=2)+'\n')
    manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(RAW.iterdir()) if p.is_file()}
    (ROOT/'RAW_SHA256.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'complete':True,'checks':len(CHECKS),'passed':sum(c['passed'] for c in CHECKS),'seconds':round(time.time()-START,2)}),flush=True)

if __name__=='__main__':
    exact_suite();graph_suite();dynamics_suite();finish()
