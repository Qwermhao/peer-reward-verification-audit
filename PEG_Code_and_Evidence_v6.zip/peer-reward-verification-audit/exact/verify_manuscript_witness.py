#!/usr/bin/env python3
import csv, hashlib, itertools, json
from fractions import Fraction as F
from pathlib import Path
import run_audit as audit
root=Path(__file__).resolve().parent
plan=json.loads((root/'ADDENDUM_PLAN.json').read_text())
out=root/'raw_addendum';out.mkdir(exist_ok=True)
U=[[F(x) for x in row] for row in plan['signal_law']]
rows=[]
for a,b,c,d in itertools.product(map(F,plan['row_probability_grid']),repeat=4):
    v=audit.enumerated_expectation(U,(a,b),(c,d))
    expected=audit.factorized(U,(a,b),(c,d))
    rows.append({'a1':str(a),'b1':str(b),'a2':str(c),'b2':str(d),'direct_expected_payment':str(v),
                 'factorized_payment':str(expected),'equal':v==expected})
with (out/'symmetric_noisy_expectations.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
latent=[]
for cs in plan['full_latent_cases']:
    left,right=[tuple(map(F,c)) for c in cs]
    value=audit.latent_enumeration(U,left,right)
    latent.append({'channels':cs,'paths':value['paths'],'expected':str(value['value']),
                   'equal':value['value']==audit.factorized(U,left,right)})
c1,c2=[tuple(map(F,c)) for c in plan['stationary_witness']['channels']]
before=audit.enumerated_expectation(U,c1,c2)
after=audit.enumerated_expectation(U,tuple(map(F,plan['stationary_witness']['deviation_agent1'])),c2)
result={'signal_law':plan['signal_law'],'plan_sha256':hashlib.sha256((root/'ADDENDUM_PLAN.json').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'grid_cases':len(rows),'grid_equalities':sum(r['equal'] for r in rows),
        'latent_cases':latent,'stationary_witness_before':str(before),'stationary_witness_after':str(after),
        'deviation_gain':str(after-before),'gain_equals_1_over_256':after-before==F(1,256)}
result['all_passed']=len(rows)==625 and all(r['equal'] for r in rows) and all(r['equal'] for r in latent) and result['gain_equals_1_over_256']
(out/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
