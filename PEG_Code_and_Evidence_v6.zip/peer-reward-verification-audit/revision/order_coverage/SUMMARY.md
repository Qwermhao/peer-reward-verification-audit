# Order and coverage reanalysis: ready for report integration

**Result.** The original-order equality remains exact for all 1,616 questions. Across every one of the 20 fixed regroupings, native versus zero-reward majority differs on 6/8,960 GPQA question-order pairs and 7/23,360 ARC-Challenge pairs; maxima are two questions per dataset/order. Zero-reward majority equals the fixed generator for every saved order and is now certified algebraically for all 1,616 questions. The native/zero equality itself is empirical and is not claimed for all orders.

**Coverage matters.** On GPQA, the native full-cohort correct fraction rises from 24.11% to 30.36%, but conditional accuracy falls from 35.53% to 30.36%. On the same 304 initially answered questions, correct answers fall from 108 to 88; 48 correct answers among the 144 initially abstained questions produce the overall gain of 28. On ARC, the increase of 196 correct answers splits into 98 on the initially answered set and 98 among initial abstentions. In the original order, both patterns are reproduced by the fixed generator and zero-reward condition.

**Audit.** Independently recomputed strict majorities using `collections.Counter` and verified row, gold and generator alignment for all 271,488 saved prediction records across two datasets, two input regimes, four update conditions and 21 orders. Zero mismatches. This is complete post-hoc reanalysis of preserved outputs, not new model inference or a new prespecified experiment. Original data and outputs are unmodified. The frozen plan is preserved byte-for-byte in `ANALYSIS_PLAN_FROZEN.md`; the later arithmetic-fidelity clarification is recorded in `ANALYSIS_PLAN.md`.

## Pasteable main metrics table

All values are percentages. Correct/all is a correct-answer fraction over the fixed cohort, not conditional accuracy. Abstentions are separately retained through coverage. Generator is the primary full-coverage comparison for native majority.

| Dataset | Method | Correct/all (%) | Coverage (%) | Correct/answered (%) |
| --- | --- | --- | --- | --- |
| GPQA | Initial strict vote | 24.11 | 67.86 | 35.53 |
| GPQA | Fixed generator | 30.36 | 100.00 | 30.36 |
| GPQA | Native = zero reward | 30.36 | 100.00 | 30.36 |
| ARC-Challenge | Initial strict vote | 72.17 | 89.55 | 80.59 |
| ARC-Challenge | Fixed generator | 88.96 | 100.00 | 88.96 |
| ARC-Challenge | Native = zero reward | 88.96 | 100.00 | 88.96 |

## Pasteable results prose

Under the released-input condition, native z-score and zero-reward updates produce identical majority decisions on all 448 GPQA and 1,168 ARC-Challenge questions in the original order. Full rowwise comparisons across the 20 fixed regroupings find six GPQA disagreements across 8,960 question-order pairs and seven ARC disagreements across 23,360 pairs; 15/20 and 14/20 regroupings respectively retain exact equality, and no regrouping differs on more than two questions. The zero-reward majority equals the fixed generator in every order, so native-versus-generator comparisons give the same counts. These repeated order evaluations measure sensitivity of the same 1,616 questions, rather than 32,320 independent test questions.

Coverage-aware analysis changes the interpretation of the GPQA gain. Initial strict voting answers 304/448 questions, with 108 correct (35.53% conditional accuracy). Native voting answers all 448, with 136 correct (30.36%). On the fixed set of 304 initially answered questions, native voting gets 88 correct (28.95%); its overall increase of 28 correct answers decomposes into 20 fewer correct answers on this set plus 48 correct answers among the 144 initial abstentions. ARC differs: 843/1,046 initially answered questions are correct (80.59%), versus 941/1,046 (89.96%) after the native update; 98 further correct answers arise among 122 initial abstentions. In both datasets, the original-order native outcomes are exactly reproduced by the full-coverage fixed generator and by the zero-reward condition.

The selected-pair normalization effect also admits a direct certificate for the released implementation. For the fixed generator option y, write its initial entries as p_y and q_y. A zero-reward update assigns r = clip(p_y/(p_y+q_y), 10^-6, 1−10^-6) to its correct entry, while other options retain their initial correct entries. If r exceeds every competing option in at least two discriminators, the zero-reward majority must equal the generator. All 1,616 questions satisfy this strict-margin condition; the smallest second-largest discriminator margin is 0.122632 on GPQA and 0.099939 on ARC. Formula-derived individual choices match all 101,808 saved zero-reward model-question-order outputs. This order-independent zero-reward certificate is distinct from the empirical native-versus-zero comparison.

## Fixed-support decomposition (released inputs, original order)

| Dataset | Initially answered: initial → native correct | Initially abstained: native correct / n | Total gain |
| --- | --- | --- | --- |
| GPQA | 108/304 → 88/304 | 48/144 | −20 + 48 = +28 |
| ARC-Challenge | 843/1,046 → 941/1,046 | 98/122 | +98 + 98 = +196 |

These are changes in correct-answer counts on fixed sets. An abstention is not classified as a wrong judgment. For normalized-input comparisons, `coverage_decomposition.csv` additionally reports the intersection of answered sets and losses of coverage.

## Every-order majority disagreement table

O is original order. Regrouping k uses seed 2026111599 + k. Released-input native versus zero and versus generator are the same comparison, so both share each displayed count. Normalized-input columns remain separate.

| Order | Released GPQA | Released ARC | Normalized GPQA vs zero | Normalized GPQA vs gen | Normalized ARC vs zero | Normalized ARC vs gen |
| --- | --- | --- | --- | --- | --- | --- |
| O | 0 | 0 | 148 | 264 | 218 | 357 |
| 1 | 1 | 0 | 75 | 300 | 187 | 342 |
| 2 | 0 | 0 | 137 | 250 | 177 | 347 |
| 3 | 0 | 1 | 127 | 274 | 163 | 351 |
| 4 | 0 | 1 | 107 | 289 | 180 | 342 |
| 5 | 0 | 0 | 131 | 281 | 186 | 335 |
| 6 | 0 | 0 | 100 | 289 | 155 | 319 |
| 7 | 0 | 0 | 150 | 278 | 155 | 331 |
| 8 | 0 | 1 | 118 | 290 | 208 | 364 |
| 9 | 2 | 0 | 124 | 278 | 199 | 351 |
| 10 | 1 | 0 | 106 | 278 | 167 | 342 |
| 11 | 1 | 0 | 128 | 280 | 214 | 338 |
| 12 | 0 | 1 | 126 | 281 | 188 | 357 |
| 13 | 0 | 0 | 116 | 291 | 232 | 372 |
| 14 | 1 | 2 | 146 | 267 | 199 | 342 |
| 15 | 0 | 0 | 119 | 291 | 222 | 353 |
| 16 | 0 | 0 | 132 | 284 | 202 | 366 |
| 17 | 0 | 0 | 106 | 289 | 187 | 346 |
| 18 | 0 | 1 | 122 | 292 | 199 | 332 |
| 19 | 0 | 0 | 139 | 286 | 176 | 332 |
| 20 | 0 | 0 | 131 | 287 | 213 | 338 |

## Original-order metrics and regrouping ranges

Within each cell, the original-order percentage is followed by the minimum–maximum percentage over all 20 fixed regroupings. Initial-model, initial-vote, mean-pool and generator baselines appear separately in `baseline_metrics.csv` for both regimes. Their fixed inputs do not vary with order.

### released_input

| Dataset | Condition | Correct/all (%) | Coverage (%) | Correct/answered (%) |
| --- | --- | --- | --- | --- |
| GPQA | Native z-score | 30.36 [30.13–30.58] | 100.00 [99.78–100.00] | 30.36 [30.13–30.58] |
| GPQA | Zero reward | 30.36 [30.36–30.36] | 100.00 [100.00–100.00] | 30.36 [30.36–30.36] |
| GPQA | Raw reward | 29.46 [26.34–30.58] | 93.30 [89.96–96.43] | 31.58 [28.10–32.70] |
| GPQA | Scale only | 30.58 [25.67–31.25] | 95.31 [90.40–95.98] | 32.08 [27.71–32.86] |
| ARC-Challenge | Native z-score | 88.96 [88.87–89.04] | 100.00 [99.83–100.00] | 88.96 [88.87–89.11] |
| ARC-Challenge | Zero reward | 88.96 [88.96–88.96] | 100.00 [100.00–100.00] | 88.96 [88.96–88.96] |
| ARC-Challenge | Raw reward | 81.42 [79.79–82.45] | 95.03 [93.58–95.80] | 85.68 [84.47–87.03] |
| ARC-Challenge | Scale only | 81.16 [80.39–82.88] | 94.95 [94.01–95.80] | 85.48 [84.70–86.79] |

### all_pairs_normalized

| Dataset | Condition | Correct/all (%) | Coverage (%) | Correct/answered (%) |
| --- | --- | --- | --- | --- |
| GPQA | Native z-score | 24.55 [20.31–25.89] | 69.20 [66.96–74.11] | 35.48 [29.26–36.83] |
| GPQA | Zero reward | 24.11 [24.11–24.11] | 67.63 [67.63–67.63] | 35.64 [35.64–35.64] |
| GPQA | Raw reward | 25.00 [20.54–25.00] | 68.75 [66.74–71.88] | 36.36 [29.68–36.07] |
| GPQA | Scale only | 25.22 [20.09–25.67] | 66.96 [65.40–72.32] | 37.67 [29.22–36.28] |
| ARC-Challenge | Native z-score | 66.78 [65.41–70.55] | 87.84 [85.45–89.13] | 76.02 [74.90–79.23] |
| ARC-Challenge | Zero reward | 72.17 [72.17–72.17] | 89.55 [89.55–89.55] | 80.59 [80.59–80.59] |
| ARC-Challenge | Raw reward | 72.26 [70.46–72.95] | 89.81 [88.18–90.24] | 80.46 [79.29–81.84] |
| ARC-Challenge | Scale only | 71.75 [70.55–73.46] | 89.38 [88.27–90.33] | 80.27 [79.92–81.62] |

## Figure captions

**Main figure (`figures/order_disagreement.pdf` or `.png`).** Complete rowwise native-versus-zero-reward majority comparisons for the original order (O, shaded) and each of the 20 fixed regroupings of released inputs. Every marker represents one full-cohort comparison. Counts are identical for native versus the fixed generator because zero-reward majority equals the generator in every saved order. Original-order equality is exact; equality under all possible regroupings is not asserted.

**Normalized-input diagnostic (`figures/normalized_order_disagreement.pdf` or `.png`).** Percentage of majority decisions differing between native z-score and zero reward (blue) or the fixed generator (orange), shown separately for the original order and every fixed regrouping after normalizing all binary pairs before updating. This input intervention removes the released-input selected-pair normalization asymmetry; the original equality does not transfer to this regime. Predictions, including abstentions, are compared rowwise.

**Optional operating-points figure (`figures/risk_coverage_points.pdf` or `.png`).** Error rate among answered questions versus answer coverage in the original released-input order. These are observed operating points, not a confidence-threshold risk–coverage curve. Native, zero reward and fixed generator occupy the same point. The table and fixed-support decomposition are preferable when space is tight.

## Reproduction

From this directory:

```sh
python3 normalized_initial.py
python3 analyze.py
python3 certificate.py
MPLCONFIGDIR=/tmp/peg_revision_mpl python3 plot.py
python3 make_summary.py
```

`AUDIT.json` records saved-input and analysis hashes. `ZERO_REWARD_CERTIFICATE.json` records certificate counts, strict margins and formula/output checks. `all_order_pairwise.csv` contains each model as well as majority, exact-equality flags, paired correctness counts, and one-sided abstentions. `all_order_metrics.csv` preserves counts and all three metrics. `coverage_decomposition.csv` preserves fixed-support and joint-answer comparisons. `regrouping_metric_ranges.csv` contains original-condition/model-independent range extraction for all 20 orders. The source-exact normalized initial vectors are independently Counter-checked and matched to existing normalized baseline summaries.
