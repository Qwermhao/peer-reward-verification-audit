import csv,hashlib,json,platform,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parent
rows=[];agreements=[];detail={}
for cohort in ['mmlu','arc_easy','arc_alternative']:
 s=json.loads((ROOT/'results'/f'{cohort}_summary.json').read_text());n=s['cohort_rows'];orig={r['condition']:r for r in s['runs'] if r['seed'] is None}
 methods={'initial_vote':s['baselines']['majority'],'generator':s['baselines']['generator'],
          'native_zscore':orig['native_zscore']['metrics']['majority'],'zero_reward':orig['zero_reward']['metrics']['majority']}
 for method,m in methods.items():rows.append(dict(cohort=cohort,method=method,**m))
 a=s['native_zero_agreement'][0]
 agreements.append({'cohort':cohort,'n':n,'native_zero_agree':a['counts']['majority'],'native_zero_fraction':a['majority_fraction'],
     'zero_generator_agree':orig['zero_reward']['generator_matches']['majority'],
     'native_generator_agree':orig['native_zscore']['generator_matches']['majority'],
     'certified_rows':s['certificate']['certified_rows'],'certified_fraction':s['certificate']['certified_fraction'],
     'permuted_agreement_min':s['regrouping_native_zero_agreement']['min'],
     'permuted_agreement_mean':s['regrouping_native_zero_agreement']['mean'],
     'permuted_agreement_max':s['regrouping_native_zero_agreement']['max']})
 a=np.load(ROOT/'results'/f'{cohort}_predictions.npz');native=a['native_zscore'][0,:,-1];zero=a['zero_reward'][0,:,-1];gold=a['gold']
 detail[cohort]={'native_vs_zero_wrong_to_right':int(((zero!=gold)&(native==gold)).sum()),
   'native_vs_zero_right_to_wrong':int(((zero==gold)&(native!=gold)).sum()),
   'native_zero_answer_changes':int((native!=zero).sum()),
   'first_order_zero_raw_batches_each_step':orig['native_zscore']['batch_zero_raw_rewards'],
   'total_batches':orig['native_zscore']['batches']}
for filename,data in [('majority_coverage_table.csv',rows),('agreement_certificate_table.csv',agreements)]:
 with (ROOT/filename).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
(ROOT/'RESIDUAL_EFFECTS.json').write_text(json.dumps(detail,indent=2)+'\n')
md=['# Public external-validation results','',
 'Three prespecified cohorts extend the replay by 16,232 new questions (MMLU and ARC-Easy) and an alternative-model reevaluation of 1,168 ARC-Challenge questions. All use the same pinned native postprocessor, zero-reward ablation, hyperparameters and twenty fixed regroupings. No model inference, weights or API calls were used.','',
 '| Cohort | n | Native=zero, original order | Native accuracy | Zero accuracy | Generator accuracy | Strict zero certificate |',
 '|---|---:|---:|---:|---:|---:|---:|']
for s,a in zip(['mmlu','arc_easy','arc_alternative'],agreements):
 def metric(method,key):return next(r[key] for r in rows if r['cohort']==s and r['method']==method)
 md.append(f"| {s} | {a['n']:,} | {a['native_zero_agree']:,} ({100*a['native_zero_fraction']:.3f}%) | {100*metric('native_zscore','all_row_accuracy'):.3f}% | {100*metric('zero_reward','all_row_accuracy'):.3f}% | {100*metric('generator','all_row_accuracy'):.3f}% | {a['certified_rows']:,} ({100*a['certified_fraction']:.3f}%) |")
md+=['','## Coverage and accuracy on answered questions','',
 '| Cohort | Method | Correct / all | Answered / all | Coverage | Correct / answered |',
 '|---|---|---:|---:|---:|---:|']
for r in rows:
 md.append(f"| {r['cohort']} | {r['method']} | {r['correct']:,} / {r['n']:,} | {r['answered']:,} / {r['n']:,} | {100*r['coverage']:.3f}% | {100*r['conditional_accuracy']:.3f}% |")
md+=['','## Interpretation','',
 'Native and zero-reward majorities remain highly similar beyond the first two datasets, but are not identical in the new cohorts. The exact original-order equality claim remains scoped to the original GPQA and ARC core-three results. On each new cohort, native all-row accuracy is slightly below zero-reward and generator-only accuracy. This is a descriptive frozen-cohort result, not a claim of population-level equivalence or a frontier-model evaluation.','',
 'The alternative triple is exactly the released files ai_Yi_9B, Mistral-7B-Instruct, gemma-7b-it, with the Yi file as fixed generator. The pinned initialization notebook maps these to 01-ai/Yi-1.5-9B-Chat, mistralai/Mistral-7B-Instruct-v0.2 and google/gemma-7b-it. No >=14B probability file appears in the pinned tree. Core-three DeepSeek identities remain source file aliases.','',
 'Across the twenty fixed regroupings, native-zero majority agreement ranges '+ '; '.join(f"{a['cohort']} {100*a['permuted_agreement_min']:.3f}–{100*a['permuted_agreement_max']:.3f}% (mean {100*a['permuted_agreement_mean']:.3f}%)" for a in agreements)+'. These are sensitivity runs on the same questions, not independent replicates.','',
 'The strict certificate concerns only zero-reward copying: at least two selected-pair margins are positive. There were zero observed certificate violations. Native-zscore agreement is measured separately. MMLU and alternative ARC have a small uncertified subset, retained in all denominators.','',
 'Full-cohort numerical equivalence against the original main batch function covered 52,200 model-question policies with zero absolute policy error and zero answer mismatches. The alternative triple was also checked against the added notebook’s generalized batch function with zero error and zero answer mismatches; all shared numerical definitions are AST-identical.','',
 'MMLU gold uses the source evaluation mapping answer 0→A through 3→D; an unused corr_answer string in the source generation code is not used. ARC numeric labels use source option positions. Cross-model question, option and label alignment was exact over all released rows; only the frozen maximal complete-batch prefix was used. The source-defined np.float32-wrapper parser was required for the alternative trio; its initial parser failure is retained, and completed earlier results were not overwritten.','',
 'Raw sources remain local. The portable bundle includes manifests, retrieval/analysis scripts, derived numeric outputs and tables, excluding raw CSVs and upstream notebooks. Source and protocol hashes, verification and run logs accompany the results.']
(ROOT/'SUMMARY.md').write_text('\n'.join(md)+'\n')
print(json.dumps(detail,indent=2))
