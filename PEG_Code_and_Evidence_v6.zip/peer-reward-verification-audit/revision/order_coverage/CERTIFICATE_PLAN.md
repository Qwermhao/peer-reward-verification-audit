# Native zero-reward certificate diagnostic

Frozen 16 November 2026, 11:10 UTC, after the full saved-output reanalysis and before computing margins. This is a derived deterministic diagnostic, not a new model experiment.

For each question and each released model, reconstruct the original separate across-choice softmax. Let y be the fixed generator choice, p_y/q_y the selected correct/incorrect entries, and r=clip(p_y/(p_y+q_y),1e-6,1-1e-6). Compute the strict margin r minus the maximum untouched correct entry. A positive margin certifies that model's unique zero-reward argmax equals y after the update. At least two positive margins certify majority equality to y, independently of batch ordering. Record every margin, positive/zero/negative counts, per-model minima, and minimum second-largest margin across each cohort. Compare to all saved zero-reward outputs across original plus twenty orders. Do not infer that the nonzero-reward update equals this certificate; that remains the separately measured comparison.

All 448 GPQA and 1,168 ARC rows and all three released model files are included. The formula is evaluated without tuning or threshold selection; zero means exact floating-point equality, and the minimum positive majority margin is reported for numerical safety assessment.
