"""Independently check the zero-reward certificate using original update definitions."""
from pathlib import Path
import copy
import importlib.util
import json
import hashlib

HERE=Path(__file__).resolve().parent
BASE=HERE.parent.parent
spec=importlib.util.spec_from_file_location('native_replay_for_certificate_audit',BASE/'native/replay.py')
replay=importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
results=[]
for ds in ['gpqa','arc']:
    data=replay.load_data(ds)
    certified=0
    min_second=float('inf')
    max_formula_error=0.
    max_ten_step_drift=0.
    answer_disagreements=0
    unchanged_competitors=True
    for i in range(data['n']):
        y=data['keys'][i][data['choice'][i]]
        margins=[]
        answers=[]
        for d in range(3):
            initial=copy.deepcopy(data['refined'][i][d])
            p=initial[y]['correct'];q=initial[y]['incorrect']
            assert p>0 and q>0
            r=min(1-1e-6,max(1e-6,p/(p+q)))
            margins.append(r-max(pair['correct'] for z,pair in initial.items() if z!=y))
            disc=replay.ORIGINAL['Discriminator'](copy.deepcopy(initial))
            for step in range(10):
                response=disc.respond(y,disc.get_max_correct_choice())
                disc.update_policy(y,response,0.,.1)
                if step==0:
                    first=copy.deepcopy(disc.policy)
                    max_formula_error=max(max_formula_error,abs(first[y]['correct']-r))
                    first_answer=disc.get_max_correct_choice()
            last_answer=disc.get_max_correct_choice()
            answer_disagreements+=first_answer!=last_answer
            answers.append(last_answer)
            max_ten_step_drift=max(max_ten_step_drift,abs(first[y]['correct']-disc.policy[y]['correct']))
            unchanged_competitors &= all(initial[z]==disc.policy[z] for z in initial if z!=y)
        second=sorted(margins,reverse=True)[1]
        certified+=second>0
        min_second=min(min_second,second)
        if second>0:
            assert sum(a==y for a in answers)>=2
    results.append(dict(dataset=ds,rows=int(data['n']),certified_rows=int(certified),
                        minimum_second_largest_margin=float(min_second),
                        formula_to_original_first_step_max_error=float(max_formula_error),
                        original_one_to_ten_steps_max_policy_drift=float(max_ten_step_drift),
                        original_one_to_ten_steps_answer_disagreements=int(answer_disagreements),
                        all_unselected_pairs_unchanged=bool(unchanged_competitors)))
out=dict(method='Call AST-extracted original Discriminator on every included model-question for ten zero-reward steps; independently use native preprocessing.',
         results=results,source_script_sha256=hashlib.sha256((BASE/'native/replay.py').read_bytes()).hexdigest(),
         certificate_proof='Exact-arithmetic identity; fixed generator; every question processed; positive scores; T>=1. Strict margins handle argmax without ties.')
(HERE/'NATIVE_CERTIFICATE_INDEPENDENT_AUDIT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
