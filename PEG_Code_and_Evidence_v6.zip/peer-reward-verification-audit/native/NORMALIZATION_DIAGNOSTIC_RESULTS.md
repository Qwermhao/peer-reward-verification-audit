# Sequential diagnostic: normalize every binary pair first

This follow-up was frozen after the initial finding and before its own outcomes. It changes one operation: normalize `(correct, incorrect)` to sum to one for every answer choice before any update. The generator, released probabilities, dataset rows, labels, batch size, steps, eta, clipping and all twenty regrouping seeds remain fixed. The normalized initial answer rankings are unchanged on all 4,848 model-question outputs. Original-function equivalence on both normalized cohorts again has maximum policy error 0 and zero answer disagreements.

| Strict majority, original order | GPQA / 448 | ARC / 1,168 |
|---|---:|---:|
| Normalized initial, no update | 108 (24.11%) | 843 (72.17%) |
| Zero-reward update | 108 (24.11%) | 843 (72.17%) |
| Native z-score rewards | 110 (24.55%) | 780 (66.78%) |
| Raw rewards | 112 (25.00%) | 844 (72.26%) |
| Scale-only rewards | 113 (25.22%) | 838 (71.75%) |
| Fixed generator only | 136 (30.36%) | 1,039 (88.96%) |

On ARC, native z-score causes 55 incorrect/abstaining-to-correct and 118 correct-to-incorrect/abstaining majority changes. On GPQA the corresponding counts are 30 and 28. After removing the asymmetric selected-pair normalization, the large original-order accuracy gains disappear; native z-score decreases ARC accuracy. This is a diagnostic modification, not an optimized alternative or an upstream-author endorsed correction.

Across the twenty frozen regroupings, normalized native ARC majority accuracy is 65.41–70.55% (mean 68.04%), below the initial 72.17% in every regrouping; raw rewards range 70.46–72.95% (mean 72.01%) and scale-only 70.55–73.46% (mean 72.20%). GPQA native ranges 20.31–25.89% (mean 23.37%) against initial 24.11%. The large native reward-zero copying result concerns the released normalization; it should not be transferred to this fully normalized diagnostic.

## Floating-point null audit

The all-zero update is a mathematical identity after full normalization. Literal upstream log/exp arithmetic changes probabilities by at most 3.33e-16 on GPQA and 1.11e-15 on ARC. Those tiny changes break exact initial ties on four GPQA and two ARC individual answers. GPQA DeepSeek-LLM correct count changes 133→132; ARC DeepSeek-Qwen changes 683→685. The GPQA majority changes three answers and loses coverage on one question, but its correct count remains 108; ARC majority changes zero answers. Thus the exact experimental null is the **no-update normalized baseline**, not a claim that literal floating-point zero updates preserve every argmax.

Files: `NORMALIZATION_DIAGNOSTIC_PROTOCOL.md`, `normalized_diagnostic.py`, `results/*_normalized_summary.json`, `results/*_normalized_predictions.csv`, and `results/normalized_manifest.json`. All predictions and failed validation logs are retained. This extension made no API calls.
