"""Independent answer-key audit against the official public GPQA release.

The ZIP is downloaded from the dataset authors' public repository and opened
using the password explicitly published in that repository's README. No
predictions or model accuracies determine the reconstruction rule.
"""
import ast
import collections
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import zipfile

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
archive = HERE / "gpqa_official_dataset.zip"
with zipfile.ZipFile(archive) as z:
    official_bytes = z.read("dataset/gpqa_main.csv", pwd=b"deserted-untie-orchid")
    official = list(csv.DictReader(io.StringIO(official_bytes.decode("utf-8-sig"))))
by_question = {row["Question"]: row for row in official}
assert len(by_question) == len(official)

gpqa = list(csv.DictReader((BASE / "native/raw/gpqa_policy_df_oqwen_7B.csv").open()))
matched, text_matches, label_matches, invalid = 0, 0, 0, 0
for row in gpqa:
    source = by_question.get(row["question"])
    if source is not None:
        matched += 1
        choices = ast.literal_eval(row["choices"])
        text_matches += choices[int(row["correct_index"]) - 1] == source["Correct Answer"]
    label_matches += row["correct_letter"] == chr(65 + int(row["correct_index"]))
    invalid += row["correct_letter"] not in "ABCD"

arc = list(csv.DictReader((BASE / "native/raw/arc_policy_df_oqwen_7B.csv").open()))
numeric_arc = []
for i, row in enumerate(arc):
    # Parse only the quoted label array, never evaluate the numpy-containing text.
    label_text = re.search(r"'label': array\(\[(.*?)\], dtype=object\)", row["choices_dic"], re.S)
    assert label_text, (i, row["id"])
    labels = ast.literal_eval("[" + label_text.group(1) + "]")
    key = row["answerKey"]
    assert key in labels, (i, row["id"], key, labels)
    if key not in "ABCD":
        numeric_arc.append({"row": i, "id": row["id"], "raw": key, "canonical": chr(65 + labels.index(key)), "labels": labels})

result = {
    "official_source": "https://github.com/idavidrein/gpqa/blob/56686c06f5e19865c153de0fdb11be3890014df7/dataset.zip",
    "official_repository_commit": "56686c06f5e19865c153de0fdb11be3890014df7",
    "official_archive_git_blob_sha": "80788cb325c4d63bbccad56c2e393b33389348fe",
    "official_archive_git_blob_verified": hashlib.sha1(b"blob " + str(len(archive.read_bytes())).encode() + b"\0" + archive.read_bytes()).hexdigest() == "80788cb325c4d63bbccad56c2e393b33389348fe",
    "official_archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "official_gpqa_main_sha256": hashlib.sha256(official_bytes).hexdigest(),
    "official_rows": len(official),
    "released_gpqa_rows": len(gpqa),
    "exact_question_matches": matched,
    "canonical_answer_text_matches": text_matches,
    "stored_off_by_one_mapping_matches": label_matches,
    "stored_labels_outside_ABCD": invalid,
    "gpqa_canonical_rule": "chr(64 + int(correct_index)); verified by exact official answer-text match",
    "arc_canonical_rule": "chr(65 + position(answerKey, choices_dic.label))",
    "arc_numeric_label_count": len(numeric_arc),
    "arc_numeric_label_examples": numeric_arc[:3],
    "all_gpqa_reconstructed_labels_verified": matched == text_matches == len(gpqa),
    "scope": "Independent source/answer-key audit; no model predictions used to choose mapping. Raw upstream files remain unchanged."
}
(HERE / "LABEL_AUDIT.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
