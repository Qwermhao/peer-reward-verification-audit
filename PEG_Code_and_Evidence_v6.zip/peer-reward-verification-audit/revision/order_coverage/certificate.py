from pathlib import Path
import ast,csv,collections,hashlib,json,math
HERE=Path(__file__).resolve().parent
BASE=HERE.parent.parent
NATIVE=BASE/'native'
MODELS=['oqwen_7B','deepseek_qwen_7B','deepseek_llm_7b']
def softmax(v):
 e=[math.exp(x-max(v)) for x in v];s=sum(e);return[x/s for x in e]
rowsout=[];summary=[]
for ds,n in [('gpqa',448),('arc',1168)]:
 raws=[list(csv.DictReader((NATIVE/'raw'/f'{ds}_policy_df_{m}.csv').open()))[:n] for m in MODELS]
 permodel={m:[] for m in MODELS};certified=0;minmajority=1.;formula_answers={}
 for i in range(n):
  gen=ast.literal_eval(raws[0][i]['gen_init_policy'])['correct'];y=max(gen,key=gen.get)
  margins=[]
  for d,m in enumerate(MODELS):
   policy=ast.literal_eval(raws[d][i]['disc_init_policy']);keys=list(policy);iy=keys.index(y)
   p=softmax([policy[k]['correct'] for k in keys]);q=softmax([policy[k]['incorrect'] for k in keys])
   r=min(1-1e-6,max(1e-6,p[iy]/(p[iy]+q[iy])))
   other=max(p[j] for j in range(len(keys)) if j!=iy);margin=r-other
   changed=p.copy();changed[iy]=r
   formula_answers[(i,m)]=keys[max(range(len(keys)),key=lambda j:changed[j])]
   margins.append(margin);permodel[m].append(margin)
   rowsout.append(dict(dataset=ds,row=i,model=m,generator=y,selected_p=p[iy],selected_q=q[iy],
                       selected_pair_sum=p[iy]+q[iy],normalized_selected=r,max_untouched=other,
                       margin=margin,strict_generator_certificate=margin>0))
  second=sorted(margins,reverse=True)[1]
  minmajority=min(minmajority,second);certified+=second>0
 total=0;formula_mismatch=0;majority_mismatch=0
 with (NATIVE/'results'/f'{ds}_predictions.csv').open() as f:
  for x in csv.DictReader(f):
   if x['condition']!='zero_reward':continue
   total+=1;i=int(x['row'])
   formula_mismatch+=sum(formula_answers[(i,m)]!=x[m] for m in MODELS)
   majority_mismatch+=x['majority']!=x['generator']
 summary.append(dict(dataset=ds,n=n,majority_certified=certified,minimum_second_largest_margin=minmajority,
   model_margin_summaries={m:dict(positive=sum(x>0 for x in v),zero=sum(x==0 for x in v),negative=sum(x<0 for x in v),
     minimum=min(v),maximum=max(v)) for m,v in permodel.items()},
   saved_zero_question_order_comparisons=total,saved_zero_model_comparisons=total*3,
   formula_vs_saved_zero_model_mismatches=formula_mismatch,saved_zero_majority_vs_generator_mismatches=majority_mismatch))
with (HERE/'zero_reward_certificate_margins.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rowsout[0]));w.writeheader();w.writerows(rowsout)
out={'formula':'r=clip(p_y/(p_y+q_y),1e-6,1-1e-6); margin=r-max_{z!=y}p_z',
 'claim':'At least two strictly positive model margins imply zero-reward majority equals fixed generator in exact arithmetic, for any batching and T>=1.',
 'native_nonzero_rewards':'Native versus zero reward is empirical, not implied by this certificate.',
 'datasets':summary,'rows':len(rowsout),'plan_sha256':hashlib.sha256((HERE/'CERTIFICATE_PLAN.md').read_bytes()).hexdigest()}
(HERE/'ZERO_REWARD_CERTIFICATE.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
