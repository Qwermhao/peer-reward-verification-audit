import ast,copy,json
import numpy as np
from external_replay import ROOT,CONFIGS,load
from replay_core import MiniFrame,ORIGINAL,run

main=json.loads((ROOT/'sources/PEG_mechanism.ipynb').read_text())
added=json.loads((ROOT/'sources/PEG_mechanism_added.ipynb').read_text())
checks={}
def definitions(nb,id):
    c=next(c for c in nb['cells'] if c.get('id')==id)
    return {n.name:n for n in ast.parse(''.join(c['source'])).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
for cid in ['70c92c5e','fc917f7c','41b3904a']:
    a=definitions(main,cid);b=definitions(added,cid)
    common=set(a)&set(b)
    checks[cid]={k:ast.dump(a[k],include_attributes=False)==ast.dump(b[k],include_attributes=False) for k in sorted(common)}
    assert all(checks[cid].values())
ns=ORIGINAL.copy();fn=definitions(added,'70c92c5e')['batch_update_discriminators']
exec(compile(ast.Module(body=[fn],type_ignores=[]),'added_batch','exec'),ns)
MiniFrame.copy=lambda self:MiniFrame(copy.deepcopy(self.data))
data=load(CONFIGS[2]);frames={m:MiniFrame({'disc_init_policy_refine':[copy.deepcopy(p[d]) for p in data['refined']],
     'gen_init_policy':copy.deepcopy(data['gens'])}) for d,m in enumerate(data['models'])}
out=ns['batch_update_discriminators'](frames,choice_df=frames[data['models'][0]],T_steps=10,batch_size=8,learning_rate=.1)
pure,pred,_=run(data['p'],data['choice'],'native_zscore');error=0.;mismatches=0
for i in range(data['n']):
    for d,m in enumerate(data['models']):
        policy=out[m]['updated_disc_policy'][i]
        for a,k in enumerate(data['labels'][i]):
            error=max(error,max(abs(pure[i,d,a,v]-policy[k][name]) for v,name in enumerate(['correct','incorrect'])))
        mismatches+=int(out[m]['updated_answer_letter'][i]!=data['labels'][i][pred[i,d]])
assert error<1e-10 and mismatches==0
result={'shared_definition_ast_equality':checks,'added_batch_name':'batch_update_discriminators',
        'main_batch_name':'batch_update_discriminators_flexible','alternative_rows':data['n'],
        'added_source_max_policy_error':error,'added_source_answer_mismatches':mismatches,
        'note':'Added source generalizes model count and changes partial-batch handling; all evaluated batches are complete8.'}
(ROOT/'SOURCE_DEFINITION_EQUIVALENCE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
