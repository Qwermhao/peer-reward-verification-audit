# Saved-result reanalysis plan

Frozen 16 November 2026, 11:06 UTC, before executing this reanalysis. The original experimental results are already known; this is a complete audit of saved predictions, not a new preregistered experiment.

Use all rows from the four saved prediction CSVs: GPQA and ARC, original-input and fully normalized-input regimes, four reward conditions, original order and all twenty recorded seeds. Do not filter orders or questions based on disagreement or correctness.

Reconstruct the strict initial majority and probability-pooling baselines independently from the released raw CSVs using standard-library parsing and softmax. Verify all saved majority outputs using collections.Counter, and all question/gold/generator identities across conditions and orders. Treat an empty majority as abstention.

Report for each condition, regime, dataset, seed, and output: total rows, answered rows, correct rows, all-row correct fraction, answer coverage, conditional accuracy on answered rows. Report full per-order native-versus-zero and native-versus-generator disagreement counts, with correctness transitions and abstention counts. Aggregate original order separately from the twenty regroupings, including exact-equality order counts, total paired disagreements, min/max, and the union of affected question IDs.

Decompose native improvement over initial majority into net correct-count change on the initially answered set and correct answers newly supplied on the initially abstained set. Also report native conditional accuracy on the jointly answered set, with both methods evaluated on the identical questions. Do not treat abstention as an incorrect substantive answer or manufacture a risk–coverage curve from unrelated methods; plot the observed operating points if useful.

Create raw CSVs, checks JSON, a compact English summary, a per-seed majority disagreement figure, and an optional risk–coverage operating-point figure. Use fixed plotting order and show all twenty seeds. All derived files stay in this directory; originals are preserved.
