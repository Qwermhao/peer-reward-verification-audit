#!/usr/bin/env python3
"""Independent finite-outcome checks; only Python's standard library is required.

Enumeration computes report probabilities by summing latent signal outcomes and
evaluates integer count determinants on every complete report sequence. It does
not use determinant-channel factorization to compute enumerated expectations.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent

def det(m):
    return m[0][0] * m[1][1] - m[0][1] * m[1][0]

def channel(a, b):
    return ((1-a, a), (1-b, b))

def outcome_distribution(u, a, b, c, d):
    s, t = channel(a,b), channel(c,d)
    return tuple(sum(u[x][y]*s[x][r]*t[y][v]
                     for x,y in product(range(2), repeat=2))
                 for r,v in product(range(2), repeat=2))

def count_det(seq):
    n = [0, 0, 0, 0]
    for k in seq:
        n[k] += 1
    return n[0]*n[3]-n[1]*n[2]

def enumerate_payoff(q, m1, m2):
    total, mass = F(0), F(0)
    for seq in product(range(4), repeat=m1+m2):
        p = F(1)
        for k in seq:
            p *= q[k]
        mass += p
        total += p*count_det(seq[:m1])*count_det(seq[m1:])
    assert mass == 1
    return total

def enumerate_single_det(q, m):
    total = F(0)
    for seq in product(range(4), repeat=m):
        p = F(1)
        for k in seq:
            p *= q[k]
        total += p*count_det(seq)
    return total

perfect = ((F(1,2),F(0)),(F(0),F(1,2)))
noisy = ((F(5,16),F(3,16)),(F(3,16),F(5,16)))
independent = ((F(1,4),F(1,4)),(F(1,4),F(1,4)))
asymmetric = ((F(1,5),F(1,10)),(F(3,10),F(2,5)))
cases = [
    ("perfect_identity", perfect, (F(0),F(1),F(0),F(1)),2,2),
    ("full_support_identity", noisy, (F(0),F(1),F(0),F(1)),2,2),
    ("full_support_one_flip", noisy, (F(1),F(0),F(0),F(1)),2,2),
    ("full_support_two_flips", noisy, (F(1),F(0),F(1),F(0)),2,2),
    ("uninformative_reporter", noisy, (F(1,2),F(1,2),F(1,4),F(3,4)),2,2),
    ("independent_private_signals", independent, (F(0),F(1),F(0),F(1)),2,2),
    ("asymmetric_fractional_2_3", asymmetric, (F(1,7),F(5,6),F(2,9),F(4,5)),2,3),
    ("asymmetric_fractional_3_3", asymmetric, (F(1,7),F(5,6),F(2,9),F(4,5)),3,3),
]
rows=[]
for name,u,channels,m1,m2 in cases:
    a,b,c,d = channels
    q=outcome_distribution(u,*channels)
    qmatrix=((q[0],q[1]),(q[2],q[3]))
    factor=m1*(m1-1)*m2*(m2-1)
    expected=F(factor)*(b-a)**2*(d-c)**2*det(u)**2
    observed=enumerate_payoff(q,m1,m2)
    single=enumerate_single_det(q,m1)
    assert observed == expected, name
    assert single == m1*(m1-1)*det(qmatrix), name
    assert det(qmatrix)==(b-a)*(d-c)*det(u), name
    rows.append(dict(name=name,private_joint=[[str(v) for v in r] for r in u],
                     channels=list(map(str,channels)),split=[m1,m2],A=factor,
                     report_distribution=list(map(str,q)),
                     complete_sequences=4**(m1+m2),enumerated_payoff=str(observed),
                     predicted_payoff=str(expected),single_block_det=str(single),passed=True))

# Direct exact finite differences of payoff, not a symbolic Hessian implementation.
eps=F(1,100)
c=F(1,64)
curvature_gap=(c*F(1)**2+c*(1-2*eps)**2)/2-c*(1-eps)**2
assert curvature_gap==c*eps**2 > 0

# A stationary, non-Nash profile: d1=0 and d2=1/2.
stationary_payoff=F(0)
best_response_payoff=c*F(1,2)**2
assert best_response_payoff == F(1,256) > stationary_payoff

result={"method":"exhaustive complete report sequences with exact rational arithmetic",
        "case_count":len(rows),"cases":rows,
        "full_support_curvature_gap":{"epsilon":str(eps),"gap":str(curvature_gap)},
        "stationary_non_nash_deviation_gain":str(best_response_payoff),
        "all_checks_passed":True}
path=HERE/"raw"/"exact_checks.json"
path.write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"all_checks_passed":True,"case_count":len(rows),"output":str(path)}))
