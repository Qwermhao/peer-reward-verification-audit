from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
FIG=HERE/'figures';FIG.mkdir(exist_ok=True)
rows=list(csv.DictReader((HERE/'all_order_pairwise.csv').open()))
orders=['original']+[str(x) for x in range(2026111600,2026111620)]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'savefig.dpi':300})
def values(ds,regime,ref):
 rs={r['order']:r for r in rows if r['dataset']==ds and r['regime']==regime and r['output']=='majority' and r['reference']==ref}
 return [int(rs[x]['disagreements']) for x in orders]
fig,ax=plt.subplots(figsize=(6.5,2.65),layout='constrained')
for ds,n,col,marker in [('gpqa',448,'#0072B2','o'),('arc',1168,'#D55E00','s')]:
 v=values(ds,'released_input','zero_reward');assert v==values(ds,'released_input','generator')
 ax.plot(range(21),v,marker=marker,color=col,lw=1.1,ms=4,
         markerfacecolor='white' if ds=='arc' else col,
         label=('GPQA' if ds=='gpqa' else 'ARC-Challenge')+f' (n = {n:,})')
ax.axvspan(-.4,.4,color='#DEE3E8',zorder=-2)
ax.set_xticks(range(21),['O']+[str(i) for i in range(1,21)],fontsize=8)
ax.set_yticks([0,1,2]);ax.set_ylim(-.13,2.65);ax.set_xlim(-.5,20.5)
ax.grid(axis='y',alpha=.18)
ax.set_xlabel('O: original order; 1–20: fixed regroupings',fontsize=9)
ax.set_ylabel('Differing majority decisions',fontsize=9)
ax.legend(loc='upper right',ncol=2,fontsize=8,frameon=False)
ax.set_title('Released inputs: native versus zero reward',fontweight='bold',fontsize=10)
for ext in ['png','pdf']:fig.savefig(FIG/f'order_disagreement.{ext}')
plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(6.5,4.5),layout='constrained')
for ax,ds,n in zip(axs,['gpqa','arc'],[448,1168]):
 for ref,col,marker,label in [('zero_reward','#0072B2','o','Native vs zero reward'),('generator','#D55E00','s','Native vs fixed generator')]:
  v=np.array(values(ds,'all_pairs_normalized',ref))*100/n
  ax.plot(range(21),v,marker=marker,lw=1.1,ms=3.4,label=label,color=col)
 ax.axvspan(-.4,.4,color='#DEE3E8',zorder=-2)
 ax.set_xticks(range(21),['O']+[str(i) for i in range(1,21)],fontsize=8)
 ax.grid(axis='y',alpha=.18);ax.set_xlim(-.5,20.5)
 ax.set_title(('GPQA' if ds=='gpqa' else 'ARC-Challenge')+f' (n = {n:,})',fontweight='bold')
 ax.set_xlabel('O: original order; 1–20: fixed regroupings');ax.set_ylim(bottom=0)
axs[0].set_ylabel('Majority disagreements (%)');axs[1].legend(loc='lower right',fontsize=8)
fig.suptitle('All-pair-normalized diagnostic: equality does not transfer',fontweight='bold',fontsize=10)
for ext in ['png','pdf']:fig.savefig(FIG/f'normalized_order_disagreement.{ext}')
plt.close(fig)

metrics=list(csv.DictReader((HERE/'all_order_metrics.csv').open()))
baseline=list(csv.DictReader((HERE/'baseline_metrics.csv').open()))
fig,axs=plt.subplots(1,2,figsize=(6.5,3.1),layout='constrained')
spec=[('Initial vote','initial_majority','#6E7784','s'),('Generator','initial_generator','#0072B2','o'),('Native = zero','native_zscore','#D55E00','D')]
for ax,ds in zip(axs,['gpqa','arc']):
 for label,key,col,marker in spec:
  r=next(r for r in (metrics if key=='native_zscore' else baseline) if r['dataset']==ds and (r['condition']==key) and (key!='native_zscore' or (r['order']=='original' and r['regime']=='released_input' and r['output']=='majority')))
  x=100*float(r['coverage']);y=100*(1-float(r['conditional_accuracy']))
  ax.scatter([x],[y],color=col,marker=marker,s=65,zorder=3,label=label)
  if key=='initial_majority':ax.annotate(label,(x,y),xytext=(5,5),textcoords='offset points',fontsize=8)
 ax.set_title('GPQA' if ds=='gpqa' else 'ARC-Challenge',fontweight='bold')
 ax.set_xlabel('Answer coverage (%)');ax.grid(alpha=.18);ax.set_xlim(60,102)
axs[0].set_ylabel('Error rate among answered questions (%)');axs[1].legend(fontsize=8,loc='lower left')
fig.suptitle('Observed risk–coverage operating points',fontweight='bold',fontsize=10)
for ext in ['png','pdf']:fig.savefig(FIG/f'risk_coverage_points.{ext}')
plt.close(fig)
print(FIG)
