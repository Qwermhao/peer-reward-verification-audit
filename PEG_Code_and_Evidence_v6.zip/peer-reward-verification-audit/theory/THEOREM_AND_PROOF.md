# Binary DMI learning: exact orientation basins

## 1. Model and expected payment

Let $C=(C_1,\ldots,C_n)\in\{0,1\}^n$ have a fixed joint distribution, independently replicated across tasks. Write $U_{ij}(x,y)=\Pr(C_i=x,C_j=y)$. Agent $i$ uses the same reporting channel on every task,

\[
S_i=\begin{pmatrix}1-a_i&a_i\\1-b_i&b_i\end{pmatrix},\qquad
d_i=b_i-a_i=\det S_i.
\]

Reporting randomization is independent across agents and tasks conditional on the private signals. A batch is divided into disjoint blocks of fixed sizes $m_1,m_2\ge2$. For each block, $M^\ell_{ij}$ is the **count** matrix of the two agents' report pairs. The expected native payment is

\[
u_i=\sum_{j\ne i}\mathbb E[\det M^1_{ij}\det M^2_{ij}].
\]

**Lemma 1 (exact expected utility).** Define

\[
A=m_1(m_1-1)m_2(m_2-1),\quad
w_{ij}=(\det U_{ij})^2,\quad w_{ii}=0,\quad
B_i(d)=\sum_jw_{ij}d_j^2.
\]

Then $u_i=A d_i^2B_i(d)$, with $w_{ij}=w_{ji}\ge0$.

**Proof.** The report joint distribution is $Q_{ij}=S_i^\top U_{ij}S_j$; hence its determinant is $d_id_j\det U_{ij}$. For a block of $m$ tasks, expand the count determinant as

\[
\det M=\sum_{k\ne l}\left[
\mathbf1\{R^k=(0,0),R^l=(1,1)\}
-\mathbf1\{R^k=(0,1),R^l=(1,0)\}\right].
\]

Terms with $k=l$ vanish. Each ordered pair contributes $Q_{00}Q_{11}-Q_{01}Q_{10}$ in expectation, so $\mathbb E\det M=m(m-1)\det Q$. Independence of the two blocks gives the result. Conditional independence of private signals given a latent truth is not required for this identity. $\square$

The formula concerns the product of two independent count determinants. Using empirical-frequency matrices instead rescales $A$ by $1/(m_1^2m_2^2)$. Using the square of one estimated determinant is a different objective.

## 2. Specified mirror geometry

Let $h(p)=p\log p+(1-p)\log(1-p)$, and let $D_h(p,q)$ be its Bregman divergence, namely Bernoulli KL divergence. At time $t$, all agents update simultaneously from the current joint profile. Agent $i$'s step is the maximizer over $[0,1]^2$ of

\[
\eta_{i,t}\left[g^a_{i,t}(a-a_{i,t})+g^b_{i,t}(b-b_{i,t})\right]
-D_h(a,a_{i,t})-D_h(b,b_{i,t}),
\tag{1}
\]

where $g^a_{i,t}=\partial_{a_i}u_i=-2A d_{i,t}B_i(d_t)$, $g^b_{i,t}=\partial_{b_i}u_i=2A d_{i,t}B_i(d_t)$, and $0\le\eta_{i,t}<\infty$. This specifies an **unweighted sum** of the two row divergences and one learning rate shared by the two rows. Neither a signal-frequency-weighted divergence nor a parameter-space update is silently substituted for (1).

For full-support initial rows $0<a_{i,0},b_{i,0}<1$, every finite iterate remains in the interior. Writing $L(p)=\log[p/(1-p)]$, first-order optimality in (1) gives exactly

\[
L(a_{i,t+1})=L(a_{i,t})-2A\eta_{i,t}d_{i,t}B_i(d_t),\qquad
L(b_{i,t+1})=L(b_{i,t})+2A\eta_{i,t}d_{i,t}B_i(d_t).
\tag{2}
\]

There is no additional factor of two from the two actions: the scalar derivative already equals the difference between the two simplex-coordinate gradients.

## 3. Complete interior classification

**Theorem 1 (orientation-preserving convergence).** Let the assumptions of Lemma 1 and update (1) hold. Form the undirected graph with an edge $ij$ exactly when $w_{ij}>0$, and let $S=\{i:d_{i,0}\ne0\}$. Suppose

\[
\sum_{t=0}^{\infty}\eta_{i,t}=\infty
\quad\text{for every }i\in S\text{ having a neighbor in }S.
\tag{3}
\]

Then:

1. Each $\operatorname{sign}(d_{i,t})$ is invariant, including zero, and each $\lvert d_{i,t}\rvert$ is nondecreasing.
2. Every agent outside $S$, and every agent in $S$ without a neighbor in $S$, keeps its entire initial channel forever.
3. Every agent in $S$ with a neighbor in $S$ converges to its initial-sign permutation: $(a_i,b_i)\to(0,1)$ if $d_{i,0}>0$, and $(a_i,b_i)\to(1,0)$ if $d_{i,0}<0$.

**Proof.** Set

\[
c_i=\tfrac12[L(a_{i,0})+L(b_{i,0})],\qquad
z_{i,t}=\tfrac12[L(b_{i,t})-L(a_{i,t})].
\]

Equation (2) preserves the mean logit $c_i$ and gives

\[
z_{i,t+1}=z_{i,t}+2A\eta_{i,t}B_i(d_t)d_{i,t},\qquad
d_{i,t}=f_i(z_{i,t}),
\tag{4}
\]

where $f_i(z)=\sigma(c_i+z)-\sigma(c_i-z)$ and $\sigma$ is the logistic function. The function $f_i$ is odd, strictly increasing, and zero exactly at zero. Since $B_i\ge0$, every nonzero increment in (4) has the sign of $z_{i,t}$. Thus signs are invariant and both $\lvert z_{i,t}\rvert$ and $\lvert d_{i,t}\rvert$ are nondecreasing. A zero determinant remains zero, with both row gradients equal to zero.

If $i\in S$ has no neighbor in $S$, all of its informative peers have determinant zero forever, so $B_i(d_t)=0$ and its channel is fixed. Otherwise select $j\in S$ with $w_{ij}>0$. Monotonicity yields

\[
\lvert z_{i,t+1}\rvert-\lvert z_{i,t}\rvert
\ge \kappa_{ij}\eta_{i,t},\qquad
\kappa_{ij}=2A\lvert d_{i,0}\rvert w_{ij}d_{j,0}^2>0.
\tag{5}
\]

Condition (3) therefore implies $\lvert z_{i,t}\rvert\to\infty$. The fixed finite mean logit and (4) give the two claimed corners. $\square$

The proof covers coupled simultaneous updates. It requires neither own-utility concavity nor a small-step restriction. The relevant graph condition is positive degree in the initially active induced graph, rather than connectivity of the full graph.

**Corollary 1 (basins, rate and equilibrium selection).** If the informative graph has no isolated vertices and (3) holds, the all-identity basin among interior initializations is exactly $d_{i,0}>0$ for every $i$. With every initial determinant nonzero, the $2^n$ sign regions converge to their corresponding permutation profiles. For an active pair $ij$, each row's distance from its limiting corner is at most

\[
\exp(\lvert c_i\rvert-\lvert z_{i,0}\rvert)
\exp\!\left[-\kappa_{ij}\sum_{s<t}\eta_{i,s}\right].
\]

Every $u_i(d_t)$ is nondecreasing. The limiting profile is a Nash equilibrium on the full channel square if and only if there is no edge between $S$ and $S^c$.

**Proof.** Sign preservation and Theorem 1 give the basin statement. The rate follows from (5) and $\sigma(-x)\le e^{-x}$. Utility monotonicity follows because every factor $d_i^2$ and $d_j^2$ is nondecreasing. For the Nash claim, a crossing edge gives an inactive agent a strictly positive coefficient $B_i$, so switching its determinant from zero to either permutation strictly improves utility. Without crossing edges, each active agent with active neighbors reaches $\lvert d_i\rvert=1$; all remaining agents have $B_i=0$. These are precisely best responses. $\square$

## 4. Full-support witness: rising payment and falling accuracy

Let each task have a latent bit $G\sim\operatorname{Bernoulli}(1/2)$, and let two agents independently flip $G$ with probability $1/4$ to form their private signals. The private signals are conditionally independent given $G$, and their joint law has full support:

\[
U_{12}=\begin{pmatrix}5/16&3/16\\3/16&5/16\end{pmatrix},\qquad
\det U_{12}=1/16.
\]

For two blocks of two tasks, $A=4$, hence

\[
u_1=u_2=\frac{d_1^2d_2^2}{64},\qquad
\Pr(R_i=G)=\frac12+\frac{d_i}{4}.
\tag{6}
\]

The accuracy identity follows by conditioning on $G,C_i$; it holds for every channel $(a_i,b_i)$ in this synthetic model. Under Theorem 1, an initially negative active determinant decreases toward $-1$, so factual accuracy decreases toward $1/4$, while expected payment increases. For example, starting both channels at $a_i=3/4,b_i=1/4$ gives accuracy $3/8$ and payment $1/1024$; the limit has accuracy $1/4$ and payment $1/64$. These are analytic values, not measurements from language models.

All four corner profiles $d_1,d_2\in\{-1,1\}$ are Nash equilibria with payment $1/64$. At identity the signals are reported faithfully and accuracy is $3/4$; inversion receives the same payment and accuracy is $1/4$. Every profile with $d_1=d_2=0$ is also a Nash equilibrium. The profile $d_1=0,d_2=1/2$ is stationary under (1) but is not Nash: agent 1 can gain $1/256$ by changing to either permutation.

**Proposition 2 (curvature obstruction).** Fix a peer with $d_2=1$ in (6). The own-channel utility is $u_1=(b_1-a_1)^2/64$, with Hessian

\[
\nabla^2u_1=\frac1{32}\begin{pmatrix}1&-1\\-1&1\end{pmatrix}.
\]

It is strictly convex along every direction that changes $b_1-a_1$. For $a_1=0$, the midpoint concavity gap at $b_1=1,1-\epsilon,1-2\epsilon$ is $\epsilon^2/64>0$. These points fit in arbitrarily small relative neighborhoods of identity. Taking $a_1>0$ fixed and $b_1<1$ gives the same obstruction wholly in the interior. Thus a small truth-centered neighborhood alone does not establish own concavity for this channel parameterization. This example fails the concavity premise; it does not contradict a conditional mirror-ascent regret theorem that assumes that premise.

## 5. Exact scope and prior attribution

The determinant identity and permutation-optimality principle specialize the existing DMI mechanism. The contribution stated here is the explicit trajectory classification for the specified coupled binary row-channel update and its connection to the local-curvature audit. Reporting a private signal faithfully is distinct from making that signal factually correct.

The theorem fixes the signal law, task split sizes and peer set, uses independently sampled task-consistent channels, and applies exact expected gradients with geometry (1). Estimated gradients, adaptive generators, normalized rewards, task-dependent channels, joint-task randomization, trust-region projection, unequal row metrics, and zero initial action probabilities require separate analyses. In particular, an unbiased stochastic gradient need not preserve signs on individual sample paths.

Primary references: [Kong, DMI mechanism](https://arxiv.org/abs/1911.00272); [Chen et al., PEG, NeurIPS 2025](https://proceedings.neurips.cc/paper_files/paper/2025/file/4b9eb7f2789a20be981f3fac91429b21-Paper-Conference.pdf). Published PEG's policy notation and implementation are mapped separately in `MATHEMATICAL_AUDIT.md`; this theorem does not identify arbitrary LLM parameter updates with (1).
