# Frozen external validation extension
Frozen 2026-11-16 11:08:17 UTC, before reading any new model probability files or outcomes.
Pinned repository toz015/neurips2025-repo commit 0ade29f05ffca0081bfc4653966c0496b24f2630.

## Fixed selection
1. All released MMLU rows in the existing core-three files: oqwen_7B, deepseek_qwen_7B, deepseek_llm_7b. Fixed generator oqwen_7B.
2. All released ARC-Easy rows in the same core-three file aliases. Fixed generator oqwen_7B.
3. Alternative ARC-Challenge triple, fixed order ai_Yi_9B, Mistral-7B-Instruct, gemma-7b-it; generator ai_Yi_9B. These are the highest-parameter-count alias and two additional model families with explicitly documented generation calls; no selection on accuracy. The tree releases no >=14B probability file. Do not describe this as frontier-model testing.
For each: require aligned question identities/options and labels, retain common aligned order from the first model; maximal prefix divisible by eight. If alignment needs an inner join, document the exact deterministic intersection and exclusions before scoring; do not exclude by correctness. Use all complete batches, no outcome-selected sample.

## Fixed mechanism and controls
Native released separate softmax preprocessing, generator argmax, deterministic discriminator argmax reports, batch8, ten updates, eta0.1, clip1e-6. Conditions native_zscore and zero_reward. Original order and 20 fixed regroupings seeds2026111600..2026111619, undo permutation to compare outputs. No normalization-all extension in this budget.
Extract only audited pure definitions. Compare vectorized native results to original batch function on every selected question using an unused trailing batch to bypass endpoint omission; require max policy error <1e-10 and exact answers.

## Outcomes
Per model and strict majority: correct/all, coverage, correct/answered (undefined if no answered), generator agreement, native-vs-zero agreement, changes from initial, wrong-to-right/right-to-wrong. Initial strict-majority and generator-only baselines. All comparisons separate original from regrouped orders.
Store all per-row predictions, raw source Git blob hashes+SHA256, frozen seeds, exact source aliases and literal/canonical label decisions. Native-zero rowwise agreement is label-independent.
Use source-grounded canonical labels: MMLU inspect official generator answer semantics before scoring; ARC numeric answer labels mapped by option position. No probability or question-level outcome inspection before this freeze.
Retain all initial failures and audit records. Public retrieval only, no weights or model API; no uploaded raw files, submissions or source writes.

