#!/usr/bin/env python3
"""All plotted observations come from the preserved predeclared run."""
import csv, json, math, os
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
os.environ['MPLCONFIGDIR']=str(Path(__file__).resolve().parent/'.matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':11,
                     'axes.titlesize':11,'legend.fontsize':9,'xtick.labelsize':9,'ytick.labelsize':9,
                     'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,
                     'savefig.dpi':360,'axes.linewidth':.8})

def save(fig,name):
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight',metadata={'Title':name,'Creator':'Predeclared exact DMI mechanism audit'})
    fig.savefig(OUT/(name+'.png'),bbox_inches='tight',dpi=480)
    plt.close(fig)

rows=list(csv.DictReader((ROOT/'raw/dynamics.csv').open()))
series=defaultdict(list)
for r in rows:
    series[(r['case'],int(r['agent']))].append((int(r['step']),float(r['d'])))

fig,ax=plt.subplots(figsize=(6.6,4.8),layout='constrained')
colors={(1,1):'#0072B2',(-1,1):'#009E73',(-1,-1):'#CC79A7',(1,-1):'#D55E00'}
ax.axhline(0,color='#b8bec6',lw=1,zorder=1);ax.axvline(0,color='#b8bec6',lw=1,zorder=1)
for case in sorted({k[0] for k in series if k[0].startswith('pair_grid')}):
    x=[v for _,v in series[(case,0)]];y=[v for _,v in series[(case,1)]]
    if x[0]*y[0]==0:
        ax.scatter(x[0],y[0],s=31,color='#444444',zorder=5)
        continue
    key=(1 if x[0]>0 else -1,1 if y[0]>0 else -1);color=colors[key]
    ax.plot(x,y,color=color,lw=1.4,alpha=.9)
    ax.scatter(x[0],y[0],s=25,facecolors='white',edgecolors=color,lw=1,zorder=6)
    total=math.hypot(x[-1]-x[0],y[-1]-y[0])
    idx=next((i for i in range(1,len(x)) if math.hypot(x[i]-x[0],y[i]-y[0])>=.35*total),1)
    # Arrows follow measured consecutive saved points rather than a drawn vector field.
    ax.annotate('',xy=(x[idx],y[idx]),xytext=(x[idx-1],y[idx-1]),
                arrowprops={'arrowstyle':'-|>','color':color,'lw':1.3,'mutation_scale':12})
for (sx,sy),color in colors.items():
    ax.scatter(sx,sy,s=60,marker='s',color=color,zorder=7)
ax.annotate('Stationary, non-Nash',xy=(0,.8),xytext=(.13,.39),fontsize=9,
            arrowprops={'arrowstyle':'->','lw':.9,'color':'#444444'},color='#333333',
            bbox={'facecolor':'white','alpha':.95,'edgecolor':'none','pad':2})
ax.annotate('Zero-information Nash',xy=(0,0),xytext=(-.96,-.19),fontsize=9,
            arrowprops={'arrowstyle':'->','lw':.9,'color':'#444444'},color='#333333')
ax.set(xlim=(-1.07,1.07),ylim=(-1.07,1.07),xlabel=r'Agent 1 channel determinant $d_1=b_1-a_1$',
       ylabel=r'Agent 2 channel determinant $d_2=b_2-a_2$')
ax.set_aspect('equal',adjustable='box')
ax.set_xticks([-1,-.5,0,.5,1]);ax.set_yticks([-1,-.5,0,.5,1]);ax.grid(alpha=.12,zorder=0)
handles=[Line2D([0],[0],marker='o',mfc='white',mec='#555555',ls='',label='Interior initialization'),
         Line2D([0],[0],marker='s',color='#555555',ls='',label='Permutation limit')]
ax.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,1.12),ncol=2,frameon=False)
save(fig,'orientation_phase_portrait')

fig,axes=plt.subplots(2,2,figsize=(6.6,4.8),layout='constrained',sharex=True,sharey=True)
cases=[('path_zero_bridge','A  Path: inactive bridge','Stationary; not Nash'),
       ('path_active_pair_inactive_endpoint','B  Path: active pair','Two limits; not Nash'),
       ('edge_plus_isolate','C  Edge and isolated node','Limit is Nash'),
       ('triangle_mixed_orientation','D  Triangle: mixed orientation','Limit is Nash')]
linecolors=['#0072B2','#D55E00','#009E73','#CC79A7']
for ax,(case,title,nash) in zip(axes.flat,cases):
    for agent in range(3):
        points=series[(case,agent)]
        ax.plot([t for t,v in points],[v for t,v in points],color=linecolors[agent],
                lw=1.65,ls=['-','--',':'][agent],label=f'Agent {agent+1}')
    ax.axhline(0,color='#aaaaaa',lw=.6,zorder=0);ax.set_title(title,loc='left',pad=6)
    ax.text(.04,.05,nash,transform=ax.transAxes,fontsize=9,color='#333333',
            bbox={'facecolor':'white','alpha':.9,'edgecolor':'none','pad':2})
    ax.set_xscale('symlog',linthresh=20);ax.set_xlim(0,4000);ax.set_ylim(-1.1,1.1)
    ax.set_xticks([0,20,100,1000,4000],['0','20','100','1k','4k']);ax.set_yticks([-1,0,1]);ax.grid(alpha=.13)
for ax in axes[-1]:ax.set_xlabel('Exact-gradient update step')
for ax in axes[:,0]:ax.set_ylabel('Channel determinant $d_i$')
axes[0,0].legend(loc='upper left',frameon=False,fontsize=8.5,ncol=3,handlelength=1.3,columnspacing=.6)
save(fig,'graph_stationarity_cases')

fig,axes=plt.subplots(1,2,figsize=(6.6,3),layout='constrained')
ex=list(csv.DictReader((ROOT/'raw/exact_expectations.csv').open()))
pts=[(float(Fraction(r['b1'])),float(Fraction(r['enumerated']))) for r in ex
     if r['signal_law']=='perfect_shared_fair' and r['a1']=='0' and r['a2']=='0' and r['b2']=='1']
xx=[i/100 for i in range(101)]
axes[0].plot(xx,[x*x/4 for x in xx],color='#0072B2',label=r'Analytic $u=b^2/4$')
axes[0].scatter(*zip(*pts),color='#D55E00',s=28,zorder=3,label='Exact enumeration')
axes[0].set(xlabel='Own channel probability $b$',ylabel='Expected DMI payment',title='A  Convex native utility')
axes[0].legend(frameon=False,fontsize=8);axes[0].grid(alpha=.13)
curv=list(csv.DictReader((ROOT/'raw/curvature.csv').open()))
for name,color,marker,label in [('boundary_near_identity','#0072B2','o','Boundary path'),
                               ('full_support_near_identity','#D55E00','x','Full-support path')]:
    pts=[(float(Fraction(r['epsilon'])),float(Fraction(r['midpoint_convexity_gap']))) for r in curv if r['path']==name]
    axes[1].loglog(*zip(*pts),marker=marker,ms=6,lw=1.2,color=color,label=label,mfc='white')
axes[1].set(xlabel=r'Neighborhood scale $\epsilon$',ylabel='Positive midpoint gap',title='B  No concave neighborhood')
axes[1].legend(frameon=False,fontsize=8);axes[1].grid(alpha=.13,which='both')
save(fig,'curvature_audit')

captions={
 'orientation_phase_portrait':'Exact row-wise entropy ascent for two agents, four tasks split 2+2, and perfect shared fair private signals (A=4, w=1/16). All 25 initial determinant pairs from {−0.8,−0.2,0,0.2,0.8}² are included, with m1=m2=0, learning rate 0.5 and 4,000 simultaneous steps. Lines and arrows connect recorded trajectory states. Every nonzero quadrant preserves its orientation; axis points remain stationary. Non-origin axis points admit profitable unilateral deviations, whereas the origin is Nash. Numerical corner endpoints reflect floating-point saturation; the asymptotic claim is proved separately. These are mechanism simulations, not LLM measurements.',
 'graph_stationarity_cases':'Four predeclared graph cases from the eight-case heterogeneous-center suite. Each scored edge uses the same perfect-shared-signal weight w=1/16 and A=4; missing edges are an explicit symmetric peer-scoring mask. All trajectories use row-logit centers (−0.7,0.4,1.1), initial nonzero determinants ±0.5, learning rate 0.5 and 4,000 steps. A connected path with an inactive bridge does not propagate informativeness. Active adjacent agents polarize, but an adjacent zero channel can make the stationary limit non-Nash. Step axis is symmetric-log with a linear segment through step20. These are mechanism simulations, not LLM measurements.',
 'curvature_audit':'Independent exact enumeration of the four-task DMI payment. Left: own a=0 and an identity peer under perfect shared fair signals, with five grid points and the analytic curve. Right: the average endpoint payment exceeds the midpoint payment by ε²/4 for both boundary and full-support channel paths at all five predeclared scales ε∈{1/4,1/16,1/64,1/256,1/1024}; overlapping markers have identical values. Positive midpoint gaps contradict concavity even near identity. These are exact mechanism calculations, not empirical model results.'}
(OUT/'CAPTIONS.json').write_text(json.dumps(captions,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'figures':list(captions),'directory':str(OUT)}))
