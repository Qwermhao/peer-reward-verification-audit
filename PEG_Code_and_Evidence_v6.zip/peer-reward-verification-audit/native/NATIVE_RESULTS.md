# Native replay: generator copying without peer rewards

**Main finding.** On the pinned public PEG probability files, the native original-order majority answer equals both (i) its fixed Qwen generator and (ii) the all-zero-reward control on every evaluated question: **448/448 GPQA and 1,168/1,168 ARC-Challenge**. Thus the observed majority improvement over the initial discriminator vote is reproduced with no peer-payment signal. This result concerns the released postprocessor and model outputs; it does not depend on answer labels or the idealized shared-channel theorem.

## Evidence and design

The protocol was frozen before outcomes. We used all 448 released GPQA questions and the maximal complete-batch prefix of 1,168 of 1,170 released ARC-Challenge questions. All three model files have identical question, choice and label order. The native settings are batch size 8, ten updates, learning rate 0.1, fixed Qwen generator, deterministic argmax responses, and clipping at 1e-6. We retained the native separate softmax preprocessing and compared z-score rewards, raw rewards, scale-only rewards and all-zero rewards. The latter control was added after source inspection, before scoring. Twenty fixed seeded permutations regrouped identical inputs without changing labels, generator choices or model probabilities.

The vectorized implementation exactly matches the AST-extracted upstream functions over **all 4,848 model-question policies**: maximum absolute policy error **0.0**, answer mismatches **0**. The original function was run with an unused trailing batch to avoid its endpoint omission; only pure definitions were executed, not the notebook. The literal original endpoint omits the final eight GPQA rows; the complete-batch fix includes them. On ARC, the original 1,170-row input already processes the same 1,168 rows.

## Accuracy and causal controls

Canonical labels were recovered mechanically and independently checked against official GPQA answer texts and ARC option-label mappings; literal released-label scores remain in the JSON. The independent audit matched all 448 GPQA answers. Accuracy uses all cohort rows; strict majority abstains when all three answers differ.

| Method | GPQA correct / 448 | GPQA accuracy | ARC correct / 1,168 | ARC accuracy |
|---|---:|---:|---:|---:|
| Initial strict discriminator majority | 108 | 24.11% | 843 | 72.17% |
| Mean pooling of refined correct scores | 140 | 31.25% | 908 | 77.74% |
| Fixed Qwen generator | 136 | 30.36% | 1,039 | 88.96% |
| Native z-score PEG majority | 136 | 30.36% | 1,039 | 88.96% |
| Zero-reward majority | 136 | 30.36% | 1,039 | 88.96% |
| Raw-reward majority | 132 | 29.46% | 951 | 81.42% |
| Scale-only majority | 137 | 30.58% | 948 | 81.16% |

The initial strict majority covers 67.86% of GPQA and 89.55% of ARC; native and zero-reward majorities cover 100%. Direct generator comparison therefore matters: an increase over an abstaining vote alone cannot establish incentive-based improvement. Native, zero-reward and generator outputs agree row by row, not merely in aggregate accuracy.

## Mechanism

Upstream `apply_softmax` normalizes correct scores across answer choices and incorrect scores separately across choices. A selected answer consequently has a pair `(c,i)` whose sum generally differs from one. The native update with reward zero still replaces it by `(c/(c+i), i/(c+i))`, leaving other answer choices unchanged. Therefore reward zero is not an identity operation.

Across the fixed cohorts the selected-pair sums range from 0.4614 to 0.5845 on GPQA and 0.4001 to 0.7314 on ARC. A single zero-reward step changes 224/316/325 GPQA answers and 134/492/446 ARC answers for the three files in order Qwen, DeepSeek-Qwen, DeepSeek-LLM. Both DeepSeek-file discriminators then select the fixed generator on every question, producing its strict majority. Ten zero-reward steps give exactly the same answers as one; maximum floating-point policy differences are below 1e-15.

In the original-order native run, **every batch has zero raw and normalized DMI reward from update 2 through update 10**. Reward is active only at the first update. Native and zero-reward individual answers can differ, but their majority is identical throughout these original-order cohorts. This distinguishes individual probability changes from added consensus accuracy.

## Fixed regrouping result

Across the twenty prespecified regroupings, native individual answers are sensitive to unrelated batch members. The mean disagreement with original order is 8.85%/16.98%/20.25% on GPQA and 6.88%/2.55%/2.72% on ARC for Qwen/DeepSeek-Qwen/DeepSeek-LLM. However the majority is much more stable: just **5 GPQA and 6 ARC rows** ever change across all twenty regroupings, with mean original-order disagreement of 0.067% and 0.030%. Native majority accuracy ranges 30.13–30.58% on GPQA and 88.87–89.04% on ARC. Thus the primary empirical contribution is **attribution to a generator-copying normalization operation**, not a claim that consensus is broadly unstable.

## Provenance and interpretation

Pinned repository: `toz015/neurips2025-repo`, commit `0ade29f05ffca0081bfc4653966c0496b24f2630`; main notebook blob `2141d3326d55c0ceb1f011c80b6a2a70c77112f5`, update cell `70c92c5e`, preprocessing cell `fc917f7c`. All downloaded originals are byte-for-byte verified against Git blob SHA-1 and have SHA-256 manifests. Source generation notebooks explicitly map `oqwen_7B` to `Qwen/Qwen2.5-7B-Instruct`; the two DeepSeek file aliases should not be expanded to precise checkpoint names without another source.

The mathematical common-channel analysis and this native per-question replay address different objects. The data establish which parts of this released implementation explain its observed outputs. They do not establish claims about all PEG implementations, additional unreleased inference runs, or deliberate model deception. Native reward ablations retain the same step size and are diagnostic controls, not tuned replacements.

Files: `FROZEN_PROTOCOL.md`, `PRE_OUTCOME_AMENDMENT.md`, `LABEL_VALIDATION_AMENDMENT.md`, `PROVENANCE.json`, `replay.py`, `verify_full_equivalence.py`, `summarize_mechanism.py`, and `results/*`. Raw files remain local because the pinned repository has no license file; share the source manifest and replay code rather than redistributing upstream data. API calls: **0**.
