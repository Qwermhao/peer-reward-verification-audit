# A batch-score estimator can remain directionally unreliable

This proposition concerns the explicitly evaluated, **uncentered whole-batch likelihood-ratio estimator**. It is distinct from arbitrary stochastic-gradient estimators and from PEG's released deterministic argmax update.

Let the two channels and signal law be fixed, with interior channel probabilities and independent tasks. Split K tasks into sizes m₁,m₂≥2, with both m₁/K and m₂/K bounded away from zero as K grows; let P_K be the product of the two report-count determinants. Put A_K=m₁(m₁−1)m₂(m₂−1) and μ=d₁²d₂²det(U)². Assume μ>0. The numerical grid uses the equal-split special case.

For task t, define H_t as the derivative of the own conditional report log-likelihood with respect to b, minus that with respect to a. Thus

H_t = 1{C_t=1}(R_t−b)/[b(1−b)] − 1{C_t=0}(R_t−a)/[a(1−a)].

The separation-gradient estimator is

ĝ_K = (P_K/A_K) Σ_{t=1}^K H_t.

It is unbiased for the coordinate-gradient difference of normalized expected utility (∂b−∂a):

E[ĝ_K] = 4 d₁ d₂² det(U)².

**Proposition.** Write π_c=P(C=c). Then

ĝ_K/√K converges in distribution to N(0, μ² V),

where V=π₀/[a(1−a)]+π₁/[b(1−b)]>0. Consequently P(d₁ ĝ_K<0) tends to 1/2. For any fixed α>0, the probability that one entropic update with raw-count step η_K=α/A_K reverses the own orientation also tends to 1/2.

**Proof.** Conditional score expectations are zero. Independence across tasks gives iid bounded H_t with mean zero and variance V; the cross product between the two row scores vanishes because the signal indicators are disjoint. The central limit theorem therefore gives K^(−1/2)ΣH_t ⇒ N(0,V). By the law of large numbers, both empirical report matrices converge to the same report-pair distribution Q. Since det(Q)=d₁d₂det(U) and m₁²m₂²/A_K→1, P_K/A_K→μ in probability. Slutsky's theorem gives the displayed distributional limit; independence between the reward estimate and the score sum is not required.

The limiting normal distribution is nondegenerate and has zero probability at zero, yielding the opposed-sign probability. Let Δ₀=logit(b)−logit(a), whose sign is d₁. After one normalized-scale step the logit gap is Δ₀+αĝ_K. Dividing by √K sends Δ₀/√K to zero and gives the same symmetric limiting sign, proving the one-step crossing claim. This compares independent one-step experiments at increasing K, not convergence over sequential learning steps.

**Interpretation.** The estimator is unbiased but multiplying an uncentered reward, which approaches a positive constant, by a sum of zero-mean scores leaves a leading √K noise term. Increasing the number of tasks alone therefore does not make this estimator's direction reliable. Variance-reducing baselines or alternative estimators change the analysis. This argument does not assert a new general principle about score-estimator variance; it supplies the explicit consequence for the count-DMI estimator evaluated here.

For zero own orientation μ=0, this proposition does not apply. A nonzero sampled update may activate a zero channel while its magnitude shrinks with batch size; activation probability alone should not be read as a growing error magnitude.
