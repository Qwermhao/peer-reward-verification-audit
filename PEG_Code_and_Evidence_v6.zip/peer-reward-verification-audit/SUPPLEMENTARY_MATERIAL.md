# Supplementary material

**What Peer Rewards Amplify: Theory and a Zero-Reward Audit of AI Verification**  
Jiahao Chen. Apart Research AI × Epistemics Research Sprint, November 2026.

The report PDF is submitted separately. This index links the code, numeric results, plans, and reproducibility evidence accompanying that report.

| Evidence | Files |
|---|---|
| Exact expected-payment and orientation results | [Proof](theory/THEOREM_AND_PROOF.md), [exact summary](exact/SUMMARY.md), [original checks](exact/raw/checks.json), [addendum checks](exact/raw_addendum/checks.json) |
| Original PEG replay and matched controls | [Native results](native/NATIVE_RESULTS.md), [prediction tables](native/results/), [equivalence check](native/results/full_equivalence.json) |
| Complete question/order comparison | [Order summary](revision/order_coverage/SUMMARY.md), [all-order pairwise counts](revision/order_coverage/all_order_pairwise.csv), [prediction audit](revision/order_coverage/AUDIT.json) |
| Executable zero-reward certificate | [Certificate](revision/order_coverage/ZERO_REWARD_CERTIFICATE.json), [independent native check](revision/validation/NATIVE_CERTIFICATE_INDEPENDENT_AUDIT.json) |
| Coverage accounting | [Coverage decomposition](revision/order_coverage/coverage_decomposition.csv), [main metrics](revision/order_coverage/main_metrics_table.csv) |
| Added datasets and alternative model trio | [External summary](revision/external/SUMMARY.md), [saved predictions](revision/external/results/), [agreement table](revision/external/agreement_certificate_table.csv) |
| Finite-batch stochastic study | [Summary](revision/stochastic/SUMMARY.md), [configuration results](revision/stochastic/raw/monte_carlo_cells.csv), [exact size-four checks](revision/stochastic/raw/exact_K4.json), [oracle-centering control](revision/stochastic/oracle_centering/results.csv) |
| Independent checks and label reconstruction | [Instructions](validation/README.md), [prediction audit](validation/PREDICTION_AUDIT.json), [label audit](validation/LABEL_AUDIT.json) |
| Reproduce and verify | [Repository instructions](README.md#reproduce), [public manifest](MANIFEST.json), [provenance notice](NOTICE.md) |

GitHub's **Code → Download ZIP** provides the complete public code-and-evidence bundle. Inputs excluded from redistribution can be retrieved by the included downloaders using the immutable source manifests. No API key or model inference is required.
