# Frozen study scope: exact dynamics and public PEG replay

Decision timestamp: 2026-11-16 09:20 UTC. User authorized selection of the strongest available concept and execution. This file fixes the report scope before receiving numerical experiment outcomes. Independent task-specific protocols were frozen earlier in exact/PLAN.json and native/FROZEN_PROTOCOL.md; preserve both and record any amendments separately.

## Research question

What does a determinant-based peer reward select under a specified learning rule, and which of those mathematical conditions are preserved in the publicly released PEG implementation?

## Contributions to evaluate

1. Derive the exact expected binary DMI utility and check the local-concavity premise used to motivate learning guarantees. Treat published OMD results as conditional statements, and distinguish a failed game premise from a false conditional theorem.
2. Prove and independently check a complete interior trajectory classification for fixed-channel, exact-gradient, row-wise negative-entropy ascent. The contribution is the discrete-time classification, graph condition, and non-Nash stationary behavior; determinant factorization and reporting-permutation equivalence are prior work.
3. Replay the pinned public implementation on the complete, preselected GPQA and ARC-Challenge cohorts, using released probabilities. Test controlled batch regrouping and reward normalization, with original-function numerical equivalence, answer coverage, accuracy, and per-row direction-of-change accounting. Include a separately frozen zero-reward control if preprocessing makes it necessary.

## Interpretation rules

- The analytic model's private signals and latent truth are synthetic mathematical variables. Identity reporting means reporting one's private signal, not universal factual correctness.
- Exact-gradient trajectories are mechanism simulations; public-probability replay is a real released-output analysis, not new model inference or a reproduction of every experiment in the PEG paper.
- Every regime has its own assumptions. Do not transfer the idealized theorem to per-question argmax updates, centering, clipping, finite batches, or jointly trained generators.
- Retain null results, all frozen conditions, original raw outputs, and correction logs. No prompt/model selection based on adverse outcomes.
- Accuracy is descriptive for the selected released cohorts. Order sensitivity is not by itself an accuracy failure. Reward changes are not by themselves truthfulness gains.
- A deterministic exact guard or an algebraic identity is an algorithm check, not evidence of model improvement.

## Report and artifact plan

Working title: What Peer Rewards Amplify: Exact Dynamics and a Public PEG Replay.
Author: Jiahao Chen, Independent researcher.
Target 6–8 body pages, a 150–250 word abstract, source-specific references, and the required Limitations and Dual-Use / Ethical Considerations appendix. Disclose AI assistance and distinguish earlier local numerical-rounding work from this new study. Use the official template's verified formatting and inspect every rendered page.

Archive a fresh, versioned report, editable manuscript, original analysis code, frozen protocols, compact derived results, source URLs/hashes, and reproduction instructions. No external submission or publication. Source data with unconfirmed redistribution rights remain local and are retrieved by scripts rather than included in the shareable bundle. Preserve earlier reports.

## Scientific completion gates

The report is ready when (a) theorem and constants pass independent review, (b) exact finite enumeration matches the factorization, (c) replay agrees with original functions before any substantive interpretation, (d) figures/tables regenerate from saved results, (e) every headline claim matches the evidence, and (f) final PDF meets length/template requirements and passes page-by-page inspection.
