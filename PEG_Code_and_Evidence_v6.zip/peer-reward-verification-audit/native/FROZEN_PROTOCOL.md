# Frozen native replay protocol
Frozen 2026-11-16 09:15 UTC, before reading any released CSV predictions or computing outcomes.

## Sources and cohort
Pinned toz015/neurips2025-repo commit 0ade29f05ffca0081bfc4653966c0496b24f2630.
Use all released rows of GPQA and ARC-Challenge for oqwen_7B, deepseek_qwen_7B, deepseek_llm_7b, in that fixed model order. These are the core three models in the released main notebook. Exclude other datasets/models before outcome inspection solely for execution budget.
Read csv schema, verify cross-model row identity and labels, use maximal prefix divisible by eight for all conditions. Do not filter on correctness or disagreements.

## Native fidelity
Audit and extract functions from cells fc917f7c, 41b3904a, 70c92c5e; never execute notebook top-level or saved results. Exact native preprocessing: separate softmax across choices for correct and incorrect values; generator fixed to released oqwen correct-probability argmax; deterministic discriminator response. Batch eight, ten updates, eta 0.1, clipping 1e-6. Replay pure implementation against extracted original functions on first two batches; require policy agreement within 1e-10.
Main analysis includes every complete batch (range endpoint repair only). Run literal original endpoint separately and report omitted rows explicitly. Do not score missing output as a valid answer. Original endpoint with an unused extra batch is available as an equivalence harness.

## Conditions fixed before outcomes
Native z-score reward normalization; raw rewards (no normalization); scale-only rewards divided by population standard deviation plus 1e-8. The scale-only control separates subtracting peer mean from standard-deviation rescaling. Same learning rate and update count, report scale effect; neither ablation is claimed an optimized competing method.
Native ordering plus twenty regroupings from Python random.Random seeds 2026111600 through 2026111619. Each permutation acts on aligned three-model rows and generator. Undo permutation before comparisons. Fixed generator/probabilities/labels in every condition.
No stochastic sampling ablation: released deterministic response is structurally different from idealized stochastic common-channel theorem. Sampling would require additional unvalidated assumptions about the separately normalized initial binary probabilities.

## Metrics
Per model and strict >=2 majority (three-way disagreement abstains): accuracy, output coverage, changed answers, wrong-to-right and right-to-wrong, relative to initial refined probabilities and native ordering. Also Qwen generator and initial strict majority baselines; mean of refined correct-probability choice vectors as pooling baseline.
Across twenty regroupings: original-order disagreement per model and majority; number of questions whose output is not invariant across orders; accuracy min/mean/max. Preserve per-row predictions and all aggregate results.
First-step raw/normalized rewards, centered sign changes, zero raw reward receiving nonzero centered reward, zero normalized rewards, and unselected-policy movements. Inspect paired examples by deterministic first affected row IDs, never by largest performance loss.
No hypothesis significance claim or selection of most adverse ordering. If initial-to-final changes or regrouping effects vanish, report null.

## Claim boundaries
This is replay of publicly released model probabilities, no new model inference, humans or private data. Native per-question updates and fixed generator differ from idealized common-channel theorem; neither proves the global PEG theorem false or that LLMs deceive.
No license file found in pinned tree; keep raw source/data local for verification, publish only source URLs, hashes and original analysis code unless permissions are clarified.

