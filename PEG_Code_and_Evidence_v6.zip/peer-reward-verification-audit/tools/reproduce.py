"""Run one study component in a new working copy, preserving published results."""
from pathlib import Path
import argparse
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("component", choices=["exact", "native", "order", "external", "stochastic"])
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    output = args.output.expanduser().resolve()
    if output == ROOT or ROOT in output.parents:
        parser.error("--output must be outside the published repository")
    if output.exists():
        parser.error("--output must not already exist")
    shutil.copytree(ROOT, output, ignore=shutil.ignore_patterns(
        ".git", ".venv", "venv", "__pycache__", "*.pyc", ".matplotlib", "*.zip", ".DS_Store"
    ))

    def remove(relative):
        path = output / relative
        if path.is_dir():
            shutil.rmtree(path)
        elif path.exists():
            path.unlink()

    def run(relative):
        print("Running " + relative, flush=True)
        subprocess.run([sys.executable, str(output / relative)], cwd=output, check=True)

    if args.component == "exact":
        for path in ("exact/raw", "exact/raw_addendum", "exact/figures"):
            remove(path)
        for script in ("run_audit.py", "verify_manuscript_witness.py", "make_figures.py"):
            run("exact/" + script)
    elif args.component == "native":
        for path in ("native/raw", "native/sources", "native/results", "native/figures"):
            remove(path)
        for script in ("fetch_public_inputs.py", "replay.py", "verify_full_equivalence.py",
                       "summarize_mechanism.py", "normalized_diagnostic.py", "plot_native.py", "plot_normalized.py"):
            run("native/" + script)
    elif args.component == "order":
        run("native/fetch_public_inputs.py")
        for script in ("normalized_initial.py", "analyze.py", "certificate.py", "plot.py"):
            run("revision/order_coverage/" + script)
    elif args.component == "external":
        for path in ("revision/external/raw", "revision/external/sources", "revision/external/results"):
            remove(path)
        for script in ("fetch_public_inputs.py", "external_replay.py", "verify_added_source.py", "build_tables.py"):
            run("revision/external/" + script)
    else:
        for path in ("revision/stochastic/raw", "revision/stochastic/figures",
                     "revision/stochastic/oracle_centering/results.csv",
                     "revision/stochastic/oracle_centering/checks.json"):
            remove(path)
        for script in ("run_stochastic.py", "derive_and_plot.py", "oracle_centering/run_control.py"):
            run("revision/stochastic/" + script)
    print("Reproduction completed in " + str(output), flush=True)


if __name__ == "__main__":
    main()
