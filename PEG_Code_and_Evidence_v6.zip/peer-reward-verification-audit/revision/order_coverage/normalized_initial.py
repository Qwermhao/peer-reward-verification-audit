"""Recover normalized-input initial predictions with source-exact arithmetic.
No update, model inference, network call, or batch execution is performed.
Majority is independently recomputed with Counter.
"""
from pathlib import Path
import collections,csv,json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent.parent/'native'))
from replay import load_data,MODELS
from normalized_diagnostic import normalize_every_pair
records=[]
for ds in ['gpqa','arc']:
 data=load_data(ds);p=normalize_every_pair(data['p']);pred=p[:,:,:,0].argmax(axis=2)
 for i in range(data['n']):
  labels=data['keys'][i];votes=[labels[a] for a in pred[i]];c=collections.Counter(votes)
  row=dict(dataset=ds,row=i,gold=labels[data['gold'][i]],generator=labels[data['choice'][i]],**dict(zip(MODELS,votes)))
  row['majority']=next((a for a,n in c.items() if n>=2),'')
  row['mean_pool']=labels[p[i,:,:,0].mean(axis=0).argmax()]
  records.append(row)
with (HERE/'normalized_initial_predictions.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
print('Saved normalized initial vectors:',len(records))
