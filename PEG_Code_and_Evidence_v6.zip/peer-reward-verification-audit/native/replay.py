"""Frozen replay of publicly released PEG probabilities; no model/network calls."""
import ast, collections, copy, csv, hashlib, json, math, random, time
from itertools import combinations
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
MODELS = ['oqwen_7B', 'deepseek_qwen_7B', 'deepseek_llm_7b']
CONDITIONS = ['native_zscore', 'raw', 'scale_only', 'zero_reward']
SEEDS = [None] + list(range(2026111600, 2026111620))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def audited_original():
    """Only AST-selected pure definitions plus literal mapping; no notebook execution."""
    ns = dict(np=np, copy=copy, combinations=combinations)
    for cell, names in [('fc917f7c', {'apply_softmax'}), ('41b3904a', {'get_most_probable_letter'}),
                        ('70c92c5e', {'Discriminator','normalize_rewards','generate_matrix','calculate_dmi_score',
                                      'compute_dmi_payments','batch_update_discriminators_flexible'})]:
        tree = ast.parse((ROOT/'sources'/('cell_'+cell+'.py')).read_text())
        chosen = [n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
        assert {n.name for n in chosen} == names
        exec(compile(ast.Module(body=chosen,type_ignores=[]),str(cell),'exec'),ns)
    ns['label_to_index'] = {'correct':0,'incorrect':1}
    return ns

ORIGINAL = audited_original()

class Series(list):
    def apply(self, fun): return Series(fun(x) for x in self)

class Indexer:
    def __init__(self, frame): self.frame=frame
    def __getitem__(self, key):
        row,col=key; return self.frame.data[col][row]
    def __setitem__(self, key, val):
        row,col=key; self.frame.data[col][row]=val

class MiniFrame:
    """Minimal indexing adapter, solely to execute untouched original batch function."""
    def __init__(self, data):
        self.data={k:Series(v) for k,v in data.items()}; self.shape=(len(next(iter(data.values()))),len(data))
        self.loc=Indexer(self); self.at=self.loc
    def __getitem__(self,key): return self.data[key]
    def __setitem__(self,key,val):
        self.data[key]=Series([val]*self.shape[0]) if val is None else Series(val)

def load_data(dataset):
    rows=[list(csv.DictReader((ROOT/'raw'/f'{dataset}_policy_df_{m}.csv').open())) for m in MODELS]
    released=len(rows[0]); n=released//8*8
    for d in range(1,3):
        assert len(rows[d])==released
        for i in range(released):
            for key in ['question','choices','correct_letter' if dataset=='gpqa' else 'answerKey']:
                assert rows[0][i][key]==rows[d][i][key],(dataset,i,key)
    keys=[]; refined=[]; generator=[]; gold=[]; literal_gold=[]
    for i in range(n):
        policies=[ast.literal_eval(rows[d][i]['disc_init_policy']) for d in range(3)]
        labels=list(policies[0]); assert all(list(p)==labels for p in policies)
        keys.append(labels)
        refined.append([ORIGINAL['apply_softmax'](p) for p in policies])
        gen=ast.literal_eval(rows[0][i]['gen_init_policy']); generator.append(gen)
        stored=rows[0][i]['correct_letter' if dataset=='gpqa' else 'answerKey']
        literal_gold.append(labels.index(stored) if stored in labels else -2)
        if dataset=='gpqa': canonical=int(rows[0][i]['correct_index'])-1
        elif stored.isdigit(): canonical=int(stored)-1
        else: canonical=labels.index(stored)
        assert 0<=canonical<len(labels)
        gold.append(canonical)
    width=max(map(len,keys)); p=np.zeros((n,3,width,2))
    choice=np.empty(n,dtype=int)
    for i in range(n):
        for d in range(3):
            for a,k in enumerate(keys[i]): p[i,d,a]=[refined[i][d][k]['correct'],refined[i][d][k]['incorrect']]
        c=max(generator[i]['correct'],key=generator[i]['correct'].get); choice[i]=keys[i].index(c)
    return dict(dataset=dataset,released=released,n=n,p=p,choice=choice,gold=np.asarray(gold),
                keys=keys,refined=refined,generator=generator,rows=rows,literal_gold=np.asarray(literal_gold))

def majority(pred):
    out=np.full(len(pred),-1,dtype=int)
    for i,j in [(0,1),(0,2),(1,2)]:
        hit=pred[:,i]==pred[:,j]; out[hit]=pred[hit,i]
    return out

def raw_payments(response):
    # response: B x 8 x 3 boolean, True means correct. Native matrices use correct=0.
    b=len(response); rewards=np.zeros((b,3))
    for i,j in combinations(range(3),2):
        determinants=[]
        for start in [0,4]:
            block=response[:,start:start+4]
            mat=np.zeros((b,2,2),dtype=int)
            for x,y in [(0,0),(0,1),(1,0),(1,1)]:
                mat[:,x,y]=np.sum((block[:,:,i]==(x==0))&(block[:,:,j]==(y==0)),axis=1)
            determinants.append(np.linalg.det(mat))
        reward=determinants[0]*determinants[1]
        rewards[:,i]+=reward; rewards[:,j]+=reward
    return rewards

def run(p,choice,condition,steps=10,trace=False):
    p=p.copy(); n=len(p); assert n%8==0
    ii=np.arange(n)[:,None]; dd=np.arange(3)[None,:]; cc=choice[:,None]
    traces=[]
    for step in range(steps):
        response=p[:,:,:,0].argmax(axis=2)==cc
        raw=raw_payments(response.reshape(-1,8,3)); std=raw.std(axis=1,keepdims=True)+1e-8
        if condition=='native_zscore': reward=(raw-raw.mean(axis=1,keepdims=True))/std
        elif condition=='raw': reward=raw
        elif condition=='scale_only': reward=raw/std
        elif condition=='zero_reward': reward=np.zeros_like(raw)
        else: raise ValueError(condition)
        if trace:
            traces.append({'step':step,'raw':raw.tolist(),'applied':reward.tolist()})
        rr=np.repeat(reward,8,axis=0)
        pair=p[ii,dd,cc,:]
        selected=pair[:,:,0]; rejected=pair[:,:,1]
        gc=np.where(response,1/selected,-1/rejected); gi=-gc
        lc=np.log(selected)+.1*rr*gc; li=np.log(rejected)+.1*rr*gi
        mx=np.maximum(lc,li); ec=np.exp(lc-mx); ei=np.exp(li-mx)
        updated=np.clip(ec/(ec+ei),1e-6,1-1e-6)
        p[ii,dd,cc,0]=updated; p[ii,dd,cc,1]=1-updated
    return p,p[:,:,:,0].argmax(axis=2),traces

def equivalence(data):
    frames=[]
    # Original endpoint omits its final full batch; append 8 unused fixed rows.
    for d in range(3):
        frames.append(MiniFrame({'disc_init_policy_refine':[copy.deepcopy(x[d]) for x in data['refined'][:24]],
                                 'gen_init_policy':copy.deepcopy(data['generator'][:24])}))
    ORIGINAL['batch_update_discriminators_flexible'](*frames,choice_df=frames[0],batch_size=8,T_steps=10,learning_rate=.1)
    pure,_,_=run(data['p'][:16],data['choice'][:16],'native_zscore')
    error=0.0
    for i in range(16):
        for d in range(3):
            for a,key in enumerate(data['keys'][i]):
                actual=frames[d]['updated_disc_policy'][i][key]
                error=max(error,max(abs(pure[i,d,a,v]-actual[k]) for v,k in enumerate(['correct','incorrect'])))
    assert error<1e-10,error
    assert all(v is None for v in frames[0]['updated_disc_policy'][16:])
    return {'rows':16,'max_absolute_policy_error':error,'tolerance':1e-10,'literal_tail_omission_verified':True}

def metric(pred,gold,initial):
    before=initial==gold; after=pred==gold
    return {'n':len(gold),'correct':int(after.sum()),'accuracy':float(after.mean()),
            'coverage':float((pred>=0).mean()),'changed':int((pred!=initial).sum()),
            'wrong_to_right':int((~before&after).sum()),'right_to_wrong':int((before&~after).sum())}

def evaluate(dataset):
    data=load_data(dataset); n=data['n']; gold=data['gold']; initial=data['p'][:,:,:,0].argmax(axis=2)
    initial_majority=majority(initial); baseline={}
    for d,m in enumerate(MODELS): baseline[m]=metric(initial[:,d],gold,initial[:,d])
    baseline['majority']=metric(initial_majority,gold,initial_majority)
    baseline['generator']=metric(data['choice'],gold,data['choice'])
    pooled=data['p'][:,:,:,0].mean(axis=1).argmax(axis=1)
    baseline['mean_pool']=metric(pooled,gold,pooled)
    result={'dataset':dataset,'released_rows':data['released'],'cohort_rows':n,'alignment_verified':True,
            'literal_processed_rows':len(range(0,data['released']-8,8))*8,
            'equivalence':equivalence(data),'baselines':baseline,'runs':[],
            'stored_gold_outside_options':int((data['literal_gold']==-2).sum()),
            'canonical_gold_differs_stored':int((data['literal_gold']!=gold).sum()),
            'literal_baseline_accuracy':{m:float((initial[:,d]==data['literal_gold']).mean()) for d,m in enumerate(MODELS)}}
    original_outputs={}; all_outputs=collections.defaultdict(list)
    outfile=ROOT/'results'/f'{dataset}_predictions.csv'
    with outfile.open('w') as f:
        writer=csv.writer(f);writer.writerow(['dataset','condition','seed','row','gold','generator']+MODELS+['majority'])
        for seed in SEEDS:
            perm=list(range(n))
            if seed is not None: random.Random(seed).shuffle(perm)
            perm=np.asarray(perm); inverse=np.argsort(perm)
            for cond in CONDITIONS:
                final,pred,trace=run(data['p'][perm],data['choice'][perm],cond,trace=seed is None)
                pred=pred[inverse]; maj=majority(pred); entry={'seed':seed,'condition':cond,'metrics':{}}
                for d,m in enumerate(MODELS): entry['metrics'][m]=metric(pred[:,d],gold,initial[:,d])
                entry['metrics']['majority']=metric(maj,gold,initial_majority)
                combined=np.column_stack([pred,maj]);all_outputs[cond].append(combined)
                entry['literal_accuracy']={m:float((combined[:,d]==data['literal_gold']).mean()) for d,m in enumerate(MODELS+['majority'])}
                if seed is None:
                    original_outputs[cond]=combined
                    (ROOT/'results'/f'{dataset}_{cond}_trace.json').write_text(json.dumps(trace))
                entry['disagree_original_order']={m:int((combined[:,d]!=original_outputs[cond][:,d]).sum()) for d,m in enumerate(MODELS+['majority'])}
                result['runs'].append(entry)
                for i in range(n):
                    def letter(a):return None if a<0 else data['keys'][i][a]
                    writer.writerow([dataset,cond,'original' if seed is None else seed,i,letter(gold[i]),letter(data['choice'][i])]+[letter(x) for x in combined[i]])
    result['regrouping']={}
    for cond,outputs in all_outputs.items():
        a=np.stack(outputs); result['regrouping'][cond]={}
        for d,m in enumerate(MODELS+['majority']):
            accuracies=(a[1:,:,d]==gold).mean(axis=1)
            disagreements=(a[1:,:,d]!=a[0,:,d]).mean(axis=1)
            result['regrouping'][cond][m]={'noninvariant_rows':int(np.any(a[1:,:,d]!=a[0,:,d],axis=0).sum()),
              'accuracy_min':float(accuracies.min()),'accuracy_mean':float(accuracies.mean()),'accuracy_max':float(accuracies.max()),
              'disagreement_min':float(disagreements.min()),'disagreement_mean':float(disagreements.mean()),'disagreement_max':float(disagreements.max())}
    # Deterministic first affected examples, all chosen after fixed full-cohort evaluation.
    nat=np.stack(all_outputs['native_zscore']); examples=[]
    for i in np.where(np.any(nat[1:]!=nat[0],axis=(0,2)))[0][:3]:
        first=next(k for k in range(1,len(SEEDS)) if np.any(nat[k,i]!=nat[0,i]))
        examples.append({'row':int(i),'question_sha256':hashlib.sha256(data['rows'][0][i]['question'].encode()).hexdigest(),
                         'gold':data['keys'][i][gold[i]],'generator':data['keys'][i][data['choice'][i]],
                         'original':[None if x<0 else data['keys'][i][x] for x in nat[0,i]],
                         'seed':SEEDS[first],'regrouped':[None if x<0 else data['keys'][i][x] for x in nat[first,i]]})
    result['examples']=examples
    zero=original_outputs['zero_reward'];native=original_outputs['native_zscore']
    result['native_vs_zero_disagreements']={m:int((native[:,d]!=zero[:,d]).sum()) for d,m in enumerate(MODELS+['majority'])}
    result['predictions_sha256']=digest(outfile)
    (ROOT/'results'/f'{dataset}_summary.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

def main():
    (ROOT/'results').mkdir(exist_ok=True)
    start=time.time(); summaries=[]
    for dataset in ['gpqa','arc']:
        r=evaluate(dataset);summaries.append(r)
        print(json.dumps({'dataset':dataset,'equivalence':r['equivalence'],'baseline_majority':r['baselines']['majority'],
            'original':[{'condition':x['condition'],'majority':x['metrics']['majority']} for x in r['runs'] if x['seed'] is None],
            'regrouping_native':r['regrouping']['native_zscore']}),flush=True)
    (ROOT/'results'/'run_manifest.json').write_text(json.dumps({'elapsed_seconds':time.time()-start,'numpy':np.__version__,
       'script_sha256':digest(Path(__file__)),'protocol_sha256':digest(ROOT/'FROZEN_PROTOCOL.md'),
       'amendment_sha256':digest(ROOT/'PRE_OUTCOME_AMENDMENT.md'),'api_calls':0,'seeds':SEEDS,
       'conditions':CONDITIONS,'source_provenance_sha256':digest(ROOT/'PROVENANCE.json')},indent=2)+'\n')

if __name__=='__main__': main()
