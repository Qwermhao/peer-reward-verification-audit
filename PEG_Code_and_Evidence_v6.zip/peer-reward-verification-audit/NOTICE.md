# Authorship and third-party provenance

Original research, analysis code, proofs, and derived evidence: Jiahao Chen, 2026.

This publication does not assign a new software license or grant rights to third-party material. The repository is publicly readable; no additional license is asserted by this notice.

The audited Peer Elicitation Games implementation and probability outputs originate from `toz015/neurips2025-repo`, pinned to commit `0ade29f05ffca0081bfc4653966c0496b24f2630`. The input manifests record exact source paths and hashes. These upstream CSVs and notebooks are fetched on demand rather than redistributed.

The optional GPQA label validation uses the authors' official dataset archive at `idavidrein/gpqa`, commit `56686c06f5e19865c153de0fdb11be3890014df7`. The archive is not included. Its published archive-access string in the validation script is the dataset authors' public string, not a user credential.

Third-party datasets, code, papers, and model outputs remain subject to their original authors' rights and applicable terms.
