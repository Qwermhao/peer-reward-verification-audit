# Public external-validation results

Three prespecified cohorts extend the replay by 16,232 new questions (MMLU and ARC-Easy) and an alternative-model reevaluation of 1,168 ARC-Challenge questions. All use the same pinned native postprocessor, zero-reward ablation, hyperparameters and twenty fixed regroupings. No model inference, weights or API calls were used.

| Cohort | n | Native=zero, original order | Native accuracy | Zero accuracy | Generator accuracy | Strict zero certificate |
|---|---:|---:|---:|---:|---:|---:|
| mmlu | 13,864 | 13,799 (99.531%) | 70.752% | 70.917% | 71.004% | 13,845 (99.863%) |
| arc_easy | 2,368 | 2,366 (99.916%) | 95.946% | 95.988% | 95.988% | 2,368 (100.000%) |
| arc_alternative | 1,168 | 1,159 (99.229%) | 88.442% | 88.613% | 88.699% | 1,162 (99.486%) |

## Coverage and accuracy on answered questions

| Cohort | Method | Correct / all | Answered / all | Coverage | Correct / answered |
|---|---|---:|---:|---:|---:|
| mmlu | initial_vote | 7,035 / 13,864 | 11,257 / 13,864 | 81.196% | 62.494% |
| mmlu | generator | 9,844 / 13,864 | 13,864 / 13,864 | 100.000% | 71.004% |
| mmlu | native_zscore | 9,809 / 13,864 | 13,836 / 13,864 | 99.798% | 70.895% |
| mmlu | zero_reward | 9,832 / 13,864 | 13,858 / 13,864 | 99.957% | 70.948% |
| arc_easy | initial_vote | 2,087 / 2,368 | 2,252 / 2,368 | 95.101% | 92.673% |
| arc_easy | generator | 2,273 / 2,368 | 2,368 / 2,368 | 100.000% | 95.988% |
| arc_easy | native_zscore | 2,272 / 2,368 | 2,367 / 2,368 | 99.958% | 95.986% |
| arc_easy | zero_reward | 2,273 / 2,368 | 2,368 / 2,368 | 100.000% | 95.988% |
| arc_alternative | initial_vote | 901 / 1,168 | 1,105 / 1,168 | 94.606% | 81.538% |
| arc_alternative | generator | 1,036 / 1,168 | 1,168 / 1,168 | 100.000% | 88.699% |
| arc_alternative | native_zscore | 1,033 / 1,168 | 1,161 / 1,168 | 99.401% | 88.975% |
| arc_alternative | zero_reward | 1,035 / 1,168 | 1,165 / 1,168 | 99.743% | 88.841% |

## Interpretation

Native and zero-reward majorities remain highly similar beyond the first two datasets, but are not identical in the new cohorts. The exact original-order equality claim remains scoped to the original GPQA and ARC core-three results. On each new cohort, native all-row accuracy is slightly below zero-reward and generator-only accuracy. This is a descriptive frozen-cohort result, not a claim of population-level equivalence or a frontier-model evaluation.

The alternative triple is exactly the released files ai_Yi_9B, Mistral-7B-Instruct, gemma-7b-it, with the Yi file as fixed generator. The pinned initialization notebook maps these to 01-ai/Yi-1.5-9B-Chat, mistralai/Mistral-7B-Instruct-v0.2 and google/gemma-7b-it. No >=14B probability file appears in the pinned tree. Core-three DeepSeek identities remain source file aliases.

Across the twenty fixed regroupings, native-zero majority agreement ranges mmlu 99.380–99.553% (mean 99.489%); arc_easy 99.916–100.000% (mean 99.975%); arc_alternative 98.545–99.658% (mean 99.251%). These are sensitivity runs on the same questions, not independent replicates.

The strict certificate concerns only zero-reward copying: at least two selected-pair margins are positive. There were zero observed certificate violations. Native-zscore agreement is measured separately. MMLU and alternative ARC have a small uncertified subset, retained in all denominators.

Full-cohort numerical equivalence against the original main batch function covered 52,200 model-question policies with zero absolute policy error and zero answer mismatches. The alternative triple was also checked against the added notebook’s generalized batch function with zero error and zero answer mismatches; all shared numerical definitions are AST-identical.

MMLU gold uses the source evaluation mapping answer 0→A through 3→D; an unused corr_answer string in the source generation code is not used. ARC numeric labels use source option positions. Cross-model question, option and label alignment was exact over all released rows; only the frozen maximal complete-batch prefix was used. The source-defined np.float32-wrapper parser was required for the alternative trio; its initial parser failure is retained, and completed earlier results were not overwritten.

Raw sources remain local. The portable bundle includes manifests, retrieval/analysis scripts, derived numeric outputs and tables, excluding raw CSVs and upstream notebooks. Source and protocol hashes, verification and run logs accompany the results.
