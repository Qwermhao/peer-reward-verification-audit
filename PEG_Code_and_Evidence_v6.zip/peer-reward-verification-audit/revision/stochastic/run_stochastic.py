#!/usr/bin/env python3
"""Frozen exact and Monte Carlo one-step DMI score-estimator audit."""
from pathlib import Path
from fractions import Fraction as F
import csv, hashlib, itertools, json, math, time
import numpy as np

ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'PLAN.json').read_text())
RAW=ROOT/'raw'
if RAW.exists(): raise SystemExit('Preserving existing run; use a new copy to reproduce')
RAW.mkdir()
T0=time.time()
STATES=np.array(list(itertools.product(range(2),repeat=4)),dtype=np.int8)
PATHS=np.array(list(itertools.product(range(16),repeat=4)),dtype=np.int16)

def pay(codes):
    k=codes.shape[1]; half=k//2
    r=STATES[codes,2]; s=STATES[codes,3]
    rr=2*r+s
    blocks=[]
    for start,end in [(0,half),(half,k)]:
        n=np.stack([(rr[:,start:end]==j).sum(axis=1) for j in range(4)],axis=1)
        blocks.append(n[:,0]*n[:,3]-n[:,1]*n[:,2])
    return blocks[0]*blocks[1]

def inputs(q,d,e):
    a=(1-d)/2; b=(1+d)/2; pa=(1-e)/2; pb=(1+e)/2
    diag=(q*q+(1-q)*(1-q))/2; off=q*(1-q)
    probs=[]; sa=[]; sb=[]
    for c,j,r,s in STATES:
        p=(a,b)[int(c)]; t=(pa,pb)[int(j)]
        probs.append((diag if c==j else off)*(p if r else 1-p)*(t if s else 1-t))
        score=(1/p if r else -1/(1-p))
        sa.append(score if c==0 else F(0));sb.append(score if c==1 else F(0))
    denominator=math.lcm(*(p.denominator for p in probs))
    pn=np.array([int(p*denominator) for p in probs],dtype=np.int64)
    sd=math.lcm(*(s.denominator for s in sa+sb))
    san=np.array([int(s*sd) for s in sa],dtype=np.int64)
    sbn=np.array([int(s*sd) for s in sb],dtype=np.int64)
    return a,b,diag,off,probs,denominator,pn,sd,san,sbn

def wilson(count,n):
    p=count/n;z=1.959963984540054; den=1+z*z/n
    center=(p+z*z/(2*n))/den
    radius=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return [max(0,center-radius),min(1,center+radius)]

def masks(payment,gan,gbn,sd,A,d,alpha):
    diff=gbn-gan; sums=gbn+gan
    out={'zero_payment':payment==0,'zero_vector_gradient':(gan==0)&(gbn==0),
         'nonzero_logit_sum_increment':sums!=0}
    if d:out['opposed_separation_increment']=int(np.sign(float(d)))*diff<0
    else:out['zero_channel_activation']=diff!=0
    margins=[]
    if d:
        olddiff=2*math.log((1+float(d))/(1-float(d)))
        for al in alpha:
            newdiff=olddiff+al*diff.astype(float)/(A*sd)
            out[f'crossing_alpha_{al:g}']=float(d)*newdiff<0
            active=np.abs(newdiff)>0
            if np.any(active):margins.append(float(np.min(np.abs(newdiff[active]))))
    else:
        for al in alpha:out[f'activation_alpha_{al:g}']=diff!=0
    return out,min(margins,default=None)

rows=[]; exact_rows=[]; allchecks=[]; exact_rates={}; mirrors=True
grid=list(itertools.product(PLAN['signal_accuracies'],PLAN['own_orientations'],PLAN['peer_orientation_magnitudes'],PLAN['batch_sizes']))
for idx,(qs,ds,es,k) in enumerate(grid):
    q,d,e=F(qs),F(ds),F(es);m=k//2;A=m*m*(m-1)*(m-1)
    a,b,diag,off,probs,den,pn,sd,san,sbn=inputs(q,d,e)
    det=diag*diag-off*off
    expected_b=2*d*e*e*det*det; expected_a=-expected_b
    expected_value=d*d*e*e*det*det
    ident=f'q={qs};d={ds};peer={es};K={k}'
    exact=None
    if k==4:
        p=pay(PATHS)
        weights=np.prod(pn[PATHS],axis=1)
        mass_den=den**4
        assert int(weights.sum())==mass_den
        ga=p*np.sum(san[PATHS],axis=1);gb=p*np.sum(sbn[PATHS],axis=1)
        # Python integers keep the weighted signed sums exact and overflow-free.
        ega=F(sum(int(x)*int(y) for x,y in zip(weights,ga)),mass_den*sd*A)
        egb=F(sum(int(x)*int(y) for x,y in zip(weights,gb)),mass_den*sd*A)
        eu=F(sum(int(x)*int(y) for x,y in zip(weights,p)),mass_den*A)
        assert ega==expected_a and egb==expected_b and eu==expected_value
        events,margin=masks(p,ga,gb,sd,A,d,PLAN['normalized_step_sizes'])
        exact={'case':ident,'q':qs,'d':ds,'peer':es,'K':k,'paths':len(PATHS),
               'probability_denominator':mass_den,'expected_ga_normalized':str(ega),
               'expected_gb_normalized':str(egb),'expected_payment_normalized':str(eu),
               'minimum_crossing_threshold_margin':margin,'events':{}}
        for name,mask in events.items():
            numerator=int(weights[mask].sum()); f=F(numerator,mass_den)
            exact['events'][name]={'probability':float(f),'fraction':str(f),'mass_numerator':numerator}
        exact_rates[ident]=exact
        exact_rows.append(exact)
        allchecks.append({'case':ident,'exact_unbiased_and_payment_identity':True})
    rng=np.random.default_rng(PLAN['seed']+idx)
    codes=rng.choice(16,size=(PLAN['batches_per_monte_carlo_cell'],k),p=np.array([float(x) for x in probs]))
    p=pay(codes);ga=p*np.sum(san[codes],axis=1);gb=p*np.sum(sbn[codes],axis=1)
    # r2 is the least significant bit of the state code. Complementing it
    # implements the paired negative-peer channel with identical own signals.
    mirrored=pay(codes^1)
    mirrors=mirrors and bool(np.array_equal(mirrored,p))
    events,margin=masks(p,ga,gb,sd,A,d,PLAN['normalized_step_sizes'])
    n=len(codes)
    row={'case':ident,'q':qs,'d':ds,'peer':es,'K':k,'A':A,'seed':PLAN['seed']+idx,'draws':n,
         'expected_ga_normalized':float(expected_a),'expected_gb_normalized':float(expected_b),
         'minimum_crossing_threshold_margin':margin}
    for coord,g,truth in [('a',ga,expected_a),('b',gb,expected_b)]:
        vals=g.astype(float)/(sd*A);mean=float(vals.mean());se=float(vals.std(ddof=1)/math.sqrt(n))
        row[f'mean_g{coord}']=mean;row[f'se_g{coord}']=se
        row[f'z_g{coord}']=(mean-float(truth))/se if se else None
    for name,mask in events.items():
        count=int(mask.sum());ci=wilson(count,n)
        row[name+'_count']=count;row[name+'_rate']=count/n
        row[name+'_lo95']=ci[0];row[name+'_hi95']=ci[1]
        if exact:row[name+'_exact']=exact['events'][name]['probability']
    rows.append(row)

keys=sorted(set().union(*(r.keys() for r in rows)))
with (RAW/'monte_carlo_cells.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
(RAW/'exact_K4.json').write_text(json.dumps(exact_rows,indent=2)+'\n')
zvals=[abs(r[key]) for r in rows for key in ['z_ga','z_gb'] if r[key] is not None]
checks={'case_count':len(rows),'exact_case_count':len(exact_rows),'total_monte_carlo_batches':sum(r['draws'] for r in rows),
        'exact_latent_paths':sum(r['paths'] for r in exact_rows),'all_exact_unbiasedness_checks_pass':all(x['exact_unbiased_and_payment_identity'] for x in allchecks),
        'peer_label_flip_pathwise_payment_invariance':mirrors,'max_absolute_mc_standardized_gradient_error':max(zvals),
        'mc_coordinate_estimates_outside_6SE':sum(x>6 for x in zvals),
        'min_crossing_threshold_margin':min(r['minimum_crossing_threshold_margin'] for r in rows if r['minimum_crossing_threshold_margin'] is not None),
        'elapsed_seconds':time.time()-T0,'numpy':np.__version__,
        'plan_sha256':hashlib.sha256((ROOT/'PLAN.json').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope':PLAN['scope']}
(RAW/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks))
