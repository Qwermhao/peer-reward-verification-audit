"""Full saved-prediction order/coverage reanalysis; no network or model calls."""
from pathlib import Path
import ast, collections, csv, hashlib, json, math

HERE=Path(__file__).resolve().parent
BASE=HERE.parent.parent
NATIVE=BASE/'native'
MODELS=['oqwen_7B','deepseek_qwen_7B','deepseek_llm_7b']
OUTPUTS=MODELS+['majority']
CONDS=['native_zscore','raw','scale_only','zero_reward']
ORDERS=['original']+[str(x) for x in range(2026111600,2026111620)]

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def vote(v):
    count=collections.Counter(v)
    return next((a for a,n in count.items() if n>=2),'')
def softmax(v):
    e=[math.exp(x-max(v)) for x in v];s=sum(e)
    return [x/s for x in e]
def metric(p,g):
    n=len(g); covered=sum(x!='' for x in p); correct=sum(x==y for x,y in zip(p,g))
    return dict(n=n,answered=covered,abstained=n-covered,correct=correct,
                correct_fraction=correct/n,coverage=covered/n,
                conditional_accuracy=correct/covered if covered else None)
def savecsv(name,rows):
    with (HERE/name).open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def initial(ds,n):
    raws=[list(csv.DictReader((NATIVE/'raw'/f'{ds}_policy_df_{m}.csv').open()))[:n] for m in MODELS]
    pred={m:[] for m in MODELS};pred['majority']=[];pred['mean_pool']=[];pred['generator']=[]
    for i in range(n):
        policies=[ast.literal_eval(rows[i]['disc_init_policy']) for rows in raws]
        keys=list(policies[0]);assert all(list(p)==keys for p in policies)
        refined=[softmax([p[k]['correct'] for k in keys]) for p in policies]
        vals=[]
        for d,m in enumerate(MODELS):
            a=max(keys,key=lambda k:policies[d][k]['correct'])
            assert a==keys[max(range(len(keys)),key=lambda a:refined[d][a])]
            pred[m].append(a);vals.append(a)
        pred['majority'].append(vote(vals))
        pred['mean_pool'].append(keys[max(range(len(keys)),key=lambda k:sum(r[k] for r in refined))])
        gen=ast.literal_eval(raws[0][i]['gen_init_policy'])['correct']
        pred['generator'].append(max(gen,key=gen.get))
    return pred

metrics=[];pairs=[];decompositions=[];baselines=[];range_rows=[];checkrows=[];unionrows=[];hashes={};allgroups={}
for ds in ['gpqa','arc']:
    common=None;init=None
    for regime,suffix in [('released_input',''),('all_pairs_normalized','_normalized')]:
        path=NATIVE/'results'/f'{ds}{suffix}_predictions.csv'
        hashes[str(path.relative_to(BASE))]=sha(path)
        groups=collections.defaultdict(dict)
        with path.open() as f:
            for row in csv.DictReader(f):
                rid=int(row['row']);key=(row['seed'],row['condition'])
                assert rid not in groups[key]
                assert vote([row[m] for m in MODELS])==row['majority'],(ds,regime,key,rid)
                groups[key][rid]=row
        n=len(groups[('original','native_zscore')]); assert n==({'gpqa':448,'arc':1168}[ds])
        assert len(groups)==84
        gold=[groups[('original','native_zscore')][i]['gold'] for i in range(n)]
        generator=[groups[('original','native_zscore')][i]['generator'] for i in range(n)]
        if common is None:
            common=(gold,generator)
        else:assert common==(gold,generator)
        if regime=='released_input':
            init=initial(ds,n)
        else:
            initial_rows=[r for r in csv.DictReader((HERE/'normalized_initial_predictions.csv').open()) if r['dataset']==ds]
            assert [int(r['row']) for r in initial_rows]==list(range(n))
            assert [r['gold'] for r in initial_rows]==gold
            init={out:[r[out] for r in initial_rows] for out in MODELS+['majority','mean_pool','generator']}
            for i in range(n):assert vote([init[m][i] for m in MODELS])==init['majority'][i]
        assert init['generator']==generator
        old=json.loads((NATIVE/'results'/f'{ds}{suffix}_summary.json').read_text())['baselines']
        for out,p in init.items():
            mm=metric(p,gold)
            if out in old:
                assert mm['correct']==old[out]['correct'],(ds,regime,out,mm,old[out])
                assert abs(mm['coverage']-old[out]['coverage'])<1e-14
            baselines.append(dict(dataset=ds,regime=regime,condition='initial_'+out,**mm))
        for key,rows in groups.items():
            assert sorted(rows)==list(range(n))
            assert [rows[i]['gold'] for i in range(n)]==gold
            assert [rows[i]['generator'] for i in range(n)]==generator
            seed,cond=key
            for out in OUTPUTS:
                p=[rows[i][out] for i in range(n)]
                metrics.append(dict(dataset=ds,regime=regime,order=seed,condition=cond,output=out,**metric(p,gold)))
        for seed in ORDERS:
            nat=groups[(seed,'native_zscore')];zero=groups[(seed,'zero_reward')]
            for ref in ['zero_reward','generator']:
                for out in OUTPUTS:
                    a=[nat[i][out] for i in range(n)]
                    b=[zero[i][out] if ref=='zero_reward' else generator[i] for i in range(n)]
                    neq=[i for i in range(n) if a[i]!=b[i]]
                    pairs.append(dict(dataset=ds,regime=regime,order=seed,output=out,reference=ref,n=n,
                        disagreements=len(neq),agreement_fraction=1-len(neq)/n,exact_equality=len(neq)==0,
                        both_correct=sum(x==y==g for x,y,g in zip(a,b,gold)),
                        native_only_correct=sum(x==g and y!=g for x,y,g in zip(a,b,gold)),
                        reference_only_correct=sum(x!=g and y==g for x,y,g in zip(a,b,gold)),
                        both_not_correct=sum(x!=g and y!=g for x,y,g in zip(a,b,gold)),
                        native_abstains_reference_answers=sum(x=='' and y!='' for x,y in zip(a,b)),
                        reference_abstains_native_answers=sum(x!='' and y=='' for x,y in zip(a,b))))
            a=[nat[i]['majority'] for i in range(n)];b=init['majority']
            answered=[i for i,x in enumerate(b) if x!=''];abstained=[i for i,x in enumerate(b) if x=='']
            joint=[i for i in answered if a[i]!='']
            bc=sum(b[i]==gold[i] for i in answered);ac=sum(a[i]==gold[i] for i in answered)
            newcorrect=sum(a[i]==gold[i] for i in abstained)
            totgain=sum(x==g for x,g in zip(a,gold))-bc
            assert totgain==ac-bc+newcorrect
            decompositions.append(dict(dataset=ds,regime=regime,order=seed,n=n,
                initial_answered=len(answered),initial_abstained=len(abstained),
                initial_correct_on_initial_answered=bc,native_correct_on_initial_answered=ac,
                net_correct_change_on_initial_answered=ac-bc,
                native_answered_on_initial_abstained=sum(a[i]!='' for i in abstained),
                native_correct_on_initial_abstained=newcorrect,total_correct_count_change=totgain,
                common_answered=len(joint),initial_correct_on_common_answered=sum(b[i]==gold[i] for i in joint),
                native_correct_on_common_answered=sum(a[i]==gold[i] for i in joint),
                initial_conditional_accuracy_common=sum(b[i]==gold[i] for i in joint)/len(joint),
                native_conditional_accuracy_common=sum(a[i]==gold[i] for i in joint)/len(joint),
                native_abstentions_on_initial_answered=sum(a[i]=='' for i in answered)))
        for out in OUTPUTS:
            for ref in ['zero_reward','generator']:
                ids=set()
                for seed in ORDERS[1:]:
                    ids.update(i for i in range(n) if groups[(seed,'native_zscore')][i][out] !=
                               (groups[(seed,'zero_reward')][i][out] if ref=='zero_reward' else generator[i]))
                for i in sorted(ids):unionrows.append(dict(dataset=ds,regime=regime,output=out,reference=ref,row=i))
        for cond in CONDS:
            for out in OUTPUTS:
                selected=[r for r in metrics if r['dataset']==ds and r['regime']==regime and r['condition']==cond and r['output']==out and r['order']!='original']
                for m in ['correct_fraction','coverage','conditional_accuracy']:
                    vs=[r[m] for r in selected]
                    range_rows.append(dict(dataset=ds,regime=regime,condition=cond,output=out,metric=m,
                        min=min(vs),mean=sum(vs)/len(vs),max=max(vs),orders=len(vs)))
        checkrows.append(dict(dataset=ds,regime=regime,rows=n,groups=len(groups),records=n*len(groups),
                              independent_majority_mismatches=0,alignment_mismatches=0))
        allgroups[(ds,regime)]=groups

savecsv('all_order_metrics.csv',metrics)
savecsv('all_order_pairwise.csv',pairs)
savecsv('coverage_decomposition.csv',decompositions)
savecsv('baseline_metrics.csv',baselines)
savecsv('regrouping_metric_ranges.csv',range_rows)
savecsv('regrouping_disagreement_union_rows.csv',unionrows)
pairsummary=[]
for ds in ['gpqa','arc']:
    for regime in ['released_input','all_pairs_normalized']:
        for out in OUTPUTS:
            for ref in ['zero_reward','generator']:
                rs=[r for r in pairs if r['dataset']==ds and r['regime']==regime and r['output']==out and r['reference']==ref]
                orig=next(r for r in rs if r['order']=='original');perm=[r for r in rs if r['order']!='original']
                pairsummary.append(dict(dataset=ds,regime=regime,output=out,reference=ref,
                    original_disagreements=orig['disagreements'],regroupings=20,
                    exactly_equal_regroupings=sum(r['exact_equality'] for r in perm),
                    regrouping_disagreement_min=min(r['disagreements'] for r in perm),
                    regrouping_disagreement_max=max(r['disagreements'] for r in perm),
                    regrouping_disagreement_total=sum(r['disagreements'] for r in perm),
                    regrouping_comparisons=sum(r['n'] for r in perm),
                    regrouping_agreement_fraction=1-sum(r['disagreements'] for r in perm)/sum(r['n'] for r in perm),
                    unique_affected_rows=sum(r['dataset']==ds and r['regime']==regime and r['output']==out and r['reference']==ref for r in unionrows)))
savecsv('pairwise_summary.csv',pairsummary)
result={'checks':checkrows,'total_prediction_records':sum(r['records'] for r in checkrows),
        'source_hashes':hashes,'analysis_plan_sha256':sha(HERE/'ANALYSIS_PLAN.md'),'frozen_analysis_plan_sha256':sha(HERE/'ANALYSIS_PLAN_FROZEN.md'),
        'script_sha256':sha(Path(__file__)),'api_calls':0,'new_model_inference':False,
        'normalized_initial_source_sha256':sha(HERE/'normalized_initial_predictions.csv'),'normalized_initial_extractor_sha256':sha(HERE/'normalized_initial.py'),
        'scope':'Post hoc complete reanalysis of frozen saved outputs; no seed or outcome filtering.'}
(HERE/'AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':result,'majority_pairs':[r for r in pairsummary if r['output']=='majority'],
                  'original_decomposition':[r for r in decompositions if r['order']=='original'],
                  'baselines':baselines},indent=2))
