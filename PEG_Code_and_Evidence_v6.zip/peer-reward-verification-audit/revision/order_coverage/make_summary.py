from pathlib import Path
import csv,json,hashlib
P=Path(__file__).resolve().parent
def read(n):return list(csv.DictReader((P/n).open()))
M=read('all_order_metrics.csv');B=read('baseline_metrics.csv');R=read('regrouping_metric_ranges.csv');W=read('all_order_pairwise.csv')
name={'gpqa':'GPQA','arc':'ARC-Challenge'}
conds={'native_zscore':'Native z-score','zero_reward':'Zero reward','raw':'Raw reward','scale_only':'Scale only'}
def pct(x):return f'{100*float(x):.2f}'
def table(headers,rows):return '| '+' | '.join(headers)+' |\n| '+' | '.join(['---']*len(headers))+' |\n'+''.join('| '+' | '.join(map(str,r))+' |\n' for r in rows)
s='''# Order and coverage reanalysis: ready for report integration

**Result.** The original-order equality remains exact for all 1,616 questions. Across every one of the 20 fixed regroupings, native versus zero-reward majority differs on 6/8,960 GPQA question-order pairs and 7/23,360 ARC-Challenge pairs; maxima are two questions per dataset/order. Zero-reward majority equals the fixed generator for every saved order and is now certified algebraically for all 1,616 questions. The native/zero equality itself is empirical and is not claimed for all orders.

**Coverage matters.** On GPQA, the native full-cohort correct fraction rises from 24.11% to 30.36%, but conditional accuracy falls from 35.53% to 30.36%. On the same 304 initially answered questions, correct answers fall from 108 to 88; 48 correct answers among the 144 initially abstained questions produce the overall gain of 28. On ARC, the increase of 196 correct answers splits into 98 on the initially answered set and 98 among initial abstentions. In the original order, both patterns are reproduced by the fixed generator and zero-reward condition.

**Audit.** Independently recomputed strict majorities using `collections.Counter` and verified row, gold and generator alignment for all 271,488 saved prediction records across two datasets, two input regimes, four update conditions and 21 orders. Zero mismatches. This is complete post-hoc reanalysis of preserved outputs, not new model inference or a new prespecified experiment. Original data and outputs are unmodified. The frozen plan is preserved byte-for-byte in `ANALYSIS_PLAN_FROZEN.md`; the later arithmetic-fidelity clarification is recorded in `ANALYSIS_PLAN.md`.

## Pasteable main metrics table

All values are percentages. Correct/all is a correct-answer fraction over the fixed cohort, not conditional accuracy. Abstentions are separately retained through coverage. Generator is the primary full-coverage comparison for native majority.

'''
rows=[];compact=[]
for ds in ['gpqa','arc']:
 for label,key in [('Initial strict vote','initial_majority'),('Fixed generator','initial_generator'),('Native = zero reward','native_zscore')]:
  r=next(r for r in (M if key=='native_zscore' else B) if r['dataset']==ds and r['regime']=='released_input' and r['condition']==key and (key!='native_zscore' or r['order']=='original' and r['output']=='majority'))
  rows.append([name[ds],label,pct(r['correct_fraction']),pct(r['coverage']),pct(r['conditional_accuracy'])])
  compact.append(dict(dataset=ds,method=label,correct=r['correct'],answered=r['answered'],n=r['n'],correct_all_percent=pct(r['correct_fraction']),coverage_percent=pct(r['coverage']),conditional_accuracy_percent=pct(r['conditional_accuracy'])))
s+=table(['Dataset','Method','Correct/all (%)','Coverage (%)','Correct/answered (%)'],rows)
s+='''
## Pasteable results prose

Under the released-input condition, native z-score and zero-reward updates produce identical majority decisions on all 448 GPQA and 1,168 ARC-Challenge questions in the original order. Full rowwise comparisons across the 20 fixed regroupings find six GPQA disagreements across 8,960 question-order pairs and seven ARC disagreements across 23,360 pairs; 15/20 and 14/20 regroupings respectively retain exact equality, and no regrouping differs on more than two questions. The zero-reward majority equals the fixed generator in every order, so native-versus-generator comparisons give the same counts. These repeated order evaluations measure sensitivity of the same 1,616 questions, rather than 32,320 independent test questions.

Coverage-aware analysis changes the interpretation of the GPQA gain. Initial strict voting answers 304/448 questions, with 108 correct (35.53% conditional accuracy). Native voting answers all 448, with 136 correct (30.36%). On the fixed set of 304 initially answered questions, native voting gets 88 correct (28.95%); its overall increase of 28 correct answers decomposes into 20 fewer correct answers on this set plus 48 correct answers among the 144 initial abstentions. ARC differs: 843/1,046 initially answered questions are correct (80.59%), versus 941/1,046 (89.96%) after the native update; 98 further correct answers arise among 122 initial abstentions. In both datasets, the original-order native outcomes are exactly reproduced by the full-coverage fixed generator and by the zero-reward condition.

The selected-pair normalization effect also admits a direct certificate for the released implementation. For the fixed generator option y, write its initial entries as p_y and q_y. A zero-reward update assigns r = clip(p_y/(p_y+q_y), 10^-6, 1−10^-6) to its correct entry, while other options retain their initial correct entries. If r exceeds every competing option in at least two discriminators, the zero-reward majority must equal the generator. All 1,616 questions satisfy this strict-margin condition; the smallest second-largest discriminator margin is 0.122632 on GPQA and 0.099939 on ARC. Formula-derived individual choices match all 101,808 saved zero-reward model-question-order outputs. This order-independent zero-reward certificate is distinct from the empirical native-versus-zero comparison.

## Fixed-support decomposition (released inputs, original order)

'''
s+=table(['Dataset','Initially answered: initial → native correct','Initially abstained: native correct / n','Total gain'],[['GPQA','108/304 → 88/304','48/144','−20 + 48 = +28'],['ARC-Challenge','843/1,046 → 941/1,046','98/122','+98 + 98 = +196']])
s+='''
These are changes in correct-answer counts on fixed sets. An abstention is not classified as a wrong judgment. For normalized-input comparisons, `coverage_decomposition.csv` additionally reports the intersection of answered sets and losses of coverage.

## Every-order majority disagreement table

O is original order. Regrouping k uses seed 2026111599 + k. Released-input native versus zero and versus generator are the same comparison, so both share each displayed count. Normalized-input columns remain separate.

'''
orderrows=[]
for order in ['original']+[str(i) for i in range(2026111600,2026111620)]:
 row=['O' if order=='original' else int(order)-2026111599]
 for ds,reg,ref in [('gpqa','released_input','zero_reward'),('arc','released_input','zero_reward'),('gpqa','all_pairs_normalized','zero_reward'),('gpqa','all_pairs_normalized','generator'),('arc','all_pairs_normalized','zero_reward'),('arc','all_pairs_normalized','generator')]:
  r=next(r for r in W if r['dataset']==ds and r['regime']==reg and r['order']==order and r['output']=='majority' and r['reference']==ref);row.append(r['disagreements'])
 orderrows.append(row)
s+=table(['Order','Released GPQA','Released ARC','Normalized GPQA vs zero','Normalized GPQA vs gen','Normalized ARC vs zero','Normalized ARC vs gen'],orderrows)
s+='\n## Original-order metrics and regrouping ranges\n\nWithin each cell, the original-order percentage is followed by the minimum–maximum percentage over all 20 fixed regroupings. Initial-model, initial-vote, mean-pool and generator baselines appear separately in `baseline_metrics.csv` for both regimes. Their fixed inputs do not vary with order.\n\n'
for reg in ['released_input','all_pairs_normalized']:
 s+='### '+reg+'\n\n';rows=[]
 for ds in ['gpqa','arc']:
  for c in ['native_zscore','zero_reward','raw','scale_only']:
   r=next(r for r in M if r['dataset']==ds and r['regime']==reg and r['order']=='original' and r['output']=='majority' and r['condition']==c)
   row=[name[ds],conds[c]]
   for metric in ['correct_fraction','coverage','conditional_accuracy']:
    z=next(z for z in R if z['dataset']==ds and z['regime']==reg and z['output']=='majority' and z['condition']==c and z['metric']==metric)
    row.append(f"{pct(r[metric])} [{pct(z['min'])}–{pct(z['max'])}]")
   rows.append(row)
 s+=table(['Dataset','Condition','Correct/all (%)','Coverage (%)','Correct/answered (%)'],rows)+'\n'
s+='''## Figure captions

**Main figure (`figures/order_disagreement.pdf` or `.png`).** Complete rowwise native-versus-zero-reward majority comparisons for the original order (O, shaded) and each of the 20 fixed regroupings of released inputs. Every marker represents one full-cohort comparison. Counts are identical for native versus the fixed generator because zero-reward majority equals the generator in every saved order. Original-order equality is exact; equality under all possible regroupings is not asserted.

**Normalized-input diagnostic (`figures/normalized_order_disagreement.pdf` or `.png`).** Percentage of majority decisions differing between native z-score and zero reward (blue) or the fixed generator (orange), shown separately for the original order and every fixed regrouping after normalizing all binary pairs before updating. This input intervention removes the released-input selected-pair normalization asymmetry; the original equality does not transfer to this regime. Predictions, including abstentions, are compared rowwise.

**Optional operating-points figure (`figures/risk_coverage_points.pdf` or `.png`).** Error rate among answered questions versus answer coverage in the original released-input order. These are observed operating points, not a confidence-threshold risk–coverage curve. Native, zero reward and fixed generator occupy the same point. The table and fixed-support decomposition are preferable when space is tight.

## Reproduction

From this directory:

```sh
python3 normalized_initial.py
python3 analyze.py
python3 certificate.py
MPLCONFIGDIR=/tmp/peg_revision_mpl python3 plot.py
python3 make_summary.py
```

`AUDIT.json` records saved-input and analysis hashes. `ZERO_REWARD_CERTIFICATE.json` records certificate counts, strict margins and formula/output checks. `all_order_pairwise.csv` contains each model as well as majority, exact-equality flags, paired correctness counts, and one-sided abstentions. `all_order_metrics.csv` preserves counts and all three metrics. `coverage_decomposition.csv` preserves fixed-support and joint-answer comparisons. `regrouping_metric_ranges.csv` contains original-condition/model-independent range extraction for all 20 orders. The source-exact normalized initial vectors are independently Counter-checked and matched to existing normalized baseline summaries.
'''
(P/'SUMMARY.md').write_text(s)
with (P/'main_metrics_table.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(compact[0]));w.writeheader();w.writerows(compact)
with (P/'every_order_majority_disagreements.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['order','released_gpqa','released_arc','normalized_gpqa_vs_zero','normalized_gpqa_vs_generator','normalized_arc_vs_zero','normalized_arc_vs_generator']);w.writerows(orderrows)
print('Saved SUMMARY.md, main_metrics_table.csv, every_order_majority_disagreements.csv')
