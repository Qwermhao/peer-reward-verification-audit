# Native PEG replay

This directory contains an independently implemented replay and controls for the public PEG postprocessor. Start with `NATIVE_RESULTS.md` and `NORMALIZATION_DIAGNOSTIC_RESULTS.md`. Inputs are fixed released probability CSVs; this project performs no new model inference and requires no API key or model weights.

## Portable evidence package

Include our Python scripts, Markdown records, JSON manifests, `results/`, and `figures/`. **Exclude `raw/`, `sources/`, `__pycache__/`, and environment directories.** The upstream repository has no license file; `fetch_public_inputs.py` retrieves the pinned public originals on demand. The package contains source paths, Git object hashes, SHA-256 hashes and byte counts, so inputs remain independently recoverable and auditable.

Inputs are pinned to `toz015/neurips2025-repo` commit `0ade29f05ffca0081bfc4653966c0496b24f2630`. `PROVENANCE.json` covers six datasets, the main notebook and README; `EXTRA_SOURCE_MANIFEST.json` covers two initialization notebooks. The downloader checks SHA-256 and Git blob SHA-1 before writing and rejects conflicting existing files. It extracts only cells `fc917f7c`, `41b3904a`, `70c92c5e`. `replay.py` uses AST selection to execute named pure definitions from those cells, never notebook top-level code or saved notebook results.

## Environment used

- Python 3.14.5 (Clang 21.0.0, macOS).
- NumPy 2.5.4.
- Matplotlib 3.11.2 for figures only.
- Standard-library CSV/JSON parsing. No pandas, model framework or SciPy is required.

`requirements.txt` pins the two observed package versions. Only ordinary analysis dependencies are installed when reproducing; no weights are downloaded.

## Reproduction without replacing recorded results

Run in a clean child directory so the shipped original results remain intact:

```sh
mkdir reproduction
cp *.py *PROTOCOL.md *AMENDMENT.md PROVENANCE.json EXTRA_SOURCE_MANIFEST.json requirements.txt reproduction/
cd reproduction
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements.txt
python fetch_public_inputs.py
python replay.py
python verify_full_equivalence.py
python summarize_mechanism.py
python normalized_diagnostic.py
python plot_native.py
python plot_normalized.py
```

`fetch_public_inputs.py` is the only network step. It uses pinned public GitHub raw URLs, needs no credential and retrieves no private content. All subsequent steps are offline. Script paths are relative to the scripts' own directory. The complete analysis ran in seconds on the existing local Python environment; no API cost was incurred.

## Files to inspect

- `FROZEN_PROTOCOL.md`: original fixed cohort, model order, native settings, metrics and twenty permutation seeds.
- `PRE_OUTCOME_AMENDMENT.md`: source-motivated zero-reward control, before scoring.
- `LABEL_VALIDATION_AMENDMENT.md`: source-motivated label reconstruction, before scoring; the separate independent audit checked all GPQA gold answer texts.
- `AUDIT_CHRONOLOGY.json`: actual filesystem timestamps and hashes supplement minute estimates in early protocol prose. These are local frozen plans, not an external preregistration.
- `NORMALIZATION_DIAGNOSTIC_PROTOCOL.md`: sequential follow-up frozen after the primary finding and before its outcomes.
- `results/*_predictions.csv`: every row, condition and order, with labels and generator.
- `results/*_summary.json`: canonical and literal original scores, baselines, directional changes and regrouping sensitivity.
- `results/full_equivalence.json`: all-row agreement against the original numerical code.
- `results/mechanism_attribution.json`: zero-reward, generator identity and per-update reward diagnostics.
- `results/*_normalized_summary.json`: fully normalized diagnostic, including floating-point tie behavior and exact original-function equivalence.
- `figures/` and `FIGURE_CAPTIONS.md`: publication figures in PDF, SVG and PNG with precise captions.
- `ARTIFACT_SHA256.json`: saved artifact hashes. Historical failed validation logs are not included in this public code distribution.

The two input-normalization regimes are separate experiments. Treat neither the twenty permutations nor the three model files as independent benchmark samples. The released per-question update is also distinct from the paper's idealized shared-channel mechanism. These distinctions are part of the experiment definition.
