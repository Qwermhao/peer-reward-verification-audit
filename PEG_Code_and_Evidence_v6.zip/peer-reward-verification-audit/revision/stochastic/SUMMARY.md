# Systematic finite-batch boundary check

## Main-text insert (under 160 words)

We froze 120 binary-channel configurations varying signal accuracy, signed initial orientation, peer informativeness, and batch size K∈{4,8,16,32}. All 30 K=4 configurations were enumerated exactly; each configuration also received 20,000 fixed-seed Monte Carlo batches. The uncentered likelihood-ratio estimator is unbiased, but sampled updates need not preserve the expected-gradient invariants. Crucially, an opposed increment is not an orientation reversal: across the 96 nonzero-orientation configurations, normalized step α=0.1 produced no crossings; the maximum crossing probability was 0.965% at α=1 (exact) and 12.21% at α=10 (Monte Carlo; 95% CI 11.76–12.67%). Oracle reward centering reduced estimated separation-gradient variance in 64 of these 96 configurations, left the 24 zero-orientation configurations unchanged, and modestly increased variance in the remaining 32. Thus these experiments identify an estimator- and step-dependent boundary of the deterministic theorem; they do not establish stochastic convergence or describe the released PEG update.

## Appendix insert (approximately 400 words)

**Protocol.** The frozen grid crosses signal accuracy q∈{0.60,0.75,0.90}, own orientation d₁∈{−0.8,−0.2,0,0.2,0.8}, peer orientation d₂∈{0.2,0.8}, and K∈{4,8,16,32}. Both channels start centered: a=(1−d)/2, b=(1+d)/2. A fair latent bit generates conditionally independent private signals of accuracy q. Each batch is split equally; P is the product of the two report-count determinants. We evaluate (P/A) times the **sum** of conditional report scores, where A=m₁(m₁−1)m₂(m₂−1). Thus raw-count step η=α/A compares the same expected-objective scale across K. Peer report complementation preserves both payment and own estimator pathwise, covering negative peer orientations without independent draws.

All 16⁴ signal/report paths are enumerated with integer probability weights for each K=4 configuration. Exact coordinate expectations equal their analytic derivatives in all 30 cases. Independently seeded Monte Carlo uses 20,000 batches per cell, including K=4, totaling 2.4 million batches. Events receive per-cell Wilson 95% intervals; coordinate means have sample standard errors. No mean discrepancy exceeds six standard errors; the maximum is 3.694. Exact K=4 probabilities take precedence over their noisy replication estimates.

**Results.** For q=0.75,d₁=0.2,d₂=0.8, opposed-increment probabilities at K=4,8,16,32 are 3.025%,21.50%,38.305%,42.255%, whereas actual crossings at α=1 are 0.952%,0.080%,0.025%,0%. At α=0.1 there are no crossings in any of the 96 nonzero-orientation cells: 24 are exact zeros, and each zero Monte Carlo estimate has upper 95% bound 0.0192%. At α=10, the grid maximum is 12.21% [11.76%,12.67%]. These event rates have different meanings. In the zero-orientation example q=0.75,d₂=0.8, activation increases from 3.95% to 75.09% while RMS separation-gradient magnitude decreases from 0.2523 to 0.04785. Activation alone does not measure error severity.

**Control.** A separately frozen amendment reconstructs every original draw and substitutes the oracle-centered estimator (P/A−μ)Σscore, with known μ=d₁²d₂²det(U)². This preserves the expected gradient. Variance decreases in 64 nonzero-orientation cells, increases by at most 1.12% in the remaining 32, and is unchanged in the 24 zero-orientation cells. At q=0.9,d₁=d₂=0.8,K=32, the variance ratio is 0.489 and α=10 crossings fall from 2.205% [2.010%,2.418%] to 0.400% [0.322%,0.498%]. Opposed-increment frequency can nevertheless increase after centering, because formerly zero increments become small signed increments. This known-mean control diagnoses uncentered reward variance; it is not a learned-model improvement.

## Short proposition and proof (appendix alternative)

For fixed interior channels with μ=d₁²d₂²det(U)²>0 and split fractions bounded away from zero, let Hₜ be the difference of the b- and a-coordinate report scores. Then E[Hₜ]=0 and Var(Hₜ)=V=π₀/[a(1−a)]+π₁/[b(1−b)]. The uncentered estimator ĝ=(P/A)ΣHₜ is unbiased for (∂b−∂a)μ=4d₁d₂²det(U)², but ĝ/√K⇒N(0,μ²V): the score-sum CLT, P/A→μ, and Slutsky prove the claim without independence of these factors. Consequently opposed-increment probability tends to one half. For fixed α>0, dividing the updated logit gap L+αĝ by √K yields the same limit, so one-step crossing probability also tends to one half. This concerns this uncentered estimator, not sequential convergence or released PEG dynamics.

The complete proof and qualifications are in `PROPOSITION.md`. A score average is a different estimator; the displayed limit uses a score sum. The zero-orientation configurations have μ=0 and are outside this proposition.

## Full maximum-rate audit

| Quantity | Configuration (q,d₁,d₂,K) | Probability or estimate | Per-cell Wilson 95% interval |
|---|---|---:|---:|
| Largest opposed increment, Monte Carlo | (.6,.2,.8,32) | 8,920/20,000 = 44.600% | 43.912–45.290% |
| Largest α=.1 crossing, best available | all 96 nonzero-orientation cells | 0 | Exact zero for K4; MC upper 0.0192% per cell |
| Largest α=1 crossing, best available | (.6,−.2,.2,4) | **Exact 0.9649788800%** | Not applicable |
| Largest α=1 crossing, raw Monte Carlo replication | (.9,−.2,.2,4) | 235/20,000 = 1.175% | 1.0348–1.3340% |
| Same cell's exact α=1 crossing | (.9,−.2,.2,4) | **Exact 0.9595946222%** | Not applicable |
| Largest α=10 crossing, best available | (.6,.2,.2,8) | 2,442/20,000 = 12.210% | 11.7635–12.6710% |
| Largest exact K4 α=10 crossing | (.6,−.2,.2,4) | Exact 3.1248406400% | Not applicable |

Intervals are per-cell simulation uncertainty, not simultaneous grid bounds. A selected Monte Carlo maximum is not a proven maximum of unknown probabilities. The exact K4 results are authoritative where available; a Monte Carlo replication outside a nominal interval is retained rather than rerun or substituted.

## Verification and interpretation

- Original frozen plan and script SHA256 hashes match `raw/checks.json`; every exact K4 expectation identity passed. All integer products remained within int64 bounds; the minimum floating one-step crossing margin was 0.0007017282.
- `derive_and_plot.py` reconstructs all 120 fixed-seed draws and asserts every original event count. It adds magnitude summaries, not new experiments.
- Oracle centering uses the same own-coordinate scores and exact analytic μ. Its script asserts both original coordinate means reproduce within 1e−14 in every cell. The independently recomputed maximum centered mean discrepancy is 3.693865 standard errors, with none above six; all 24 zero-orientation variance ratios are exactly 1.
- Expectation preservation of centering follows because E[Σscore]=0. Centering can increase finite-K variance; its oracle value need not be available to a deployed learner. The ratio range is 0.4891717–1.0111639.
- Both final plots were visually checked at report width by a separate PDF-layout agent. The full parameter grid, including both own signs, is in CSV; the six-panel figure displays positive own orientations for legibility.
- The historical frozen plan uses the word “native” for the raw **count-DMI payment**. It does not mean the released PEG program. Subsequent prose uses “raw-count” to avoid that ambiguity; the original plan is preserved unchanged.

This analysis supplies the requested systematic finite-batch boundary check. The actual PEG implementation's argmax, question-specific policies, normalization, and clipping remain a separate empirical audit.
