# Reproducing the exact mechanism audit

All three scripts locate their inputs and outputs relative to their own `__file__`. They have no hardcoded machine paths, API keys, downloads or network dependencies. A writable fresh directory containing the three scripts plus `PLAN.json` and `ADDENDUM_PLAN.json` is sufficient. Copy these five source files into a fresh directory to regenerate results without changing the archived outputs.

## Three commands

Run with a Python interpreter that has Matplotlib installed:

```sh
python run_audit.py
python verify_manuscript_witness.py
python make_figures.py
```

Alternatively, pass each script's absolute path; the invocation's current working directory can be elsewhere. The first script creates `raw/` and its manifest. The second creates `raw_addendum/`. The third reads the first script's raw results and creates `figures/` and a local `.matplotlib/` font cache. The second script imports its sibling `run_audit.py`; keep the source files together. No original notebook or project-relative external file is needed.

## Tested dependencies

The exact arithmetic and dynamics scripts use only Python's standard library. Plotting uses Matplotlib and its installed dependencies. The tested environment was:

| Component | Version |
|---|---|
| Python | 3.14.5 |
| Matplotlib | 3.11.2 |
| NumPy | 2.5.4 |
| contourpy | 1.4.0 |
| cycler | 0.12.1 |
| fonttools | 4.68.0 |
| kiwisolver | 1.5.1 |
| packaging | 26.3 |
| pillow | 13.0.0 |
| pyparsing | 3.3.3 |
| python-dateutil | 4.0.0 |

NumPy is a Matplotlib dependency; the exact audit does not call NumPy or SciPy. No dependency installation is performed by these scripts. The standard-library code is written for Python 3.9 or newer; only the listed interpreter/dependency combination was tested here.

## Expected verification

- `raw/checks.json`: all 20 checks pass; 1,875 original exact grid comparisons and six full-latent comparisons are included.
- `raw_addendum/checks.json`: all 625 additional comparisons, two full-latent comparisons and the exact `1/256` deviation-gain witness pass.
- Combined exact grids contain 2,500 cases. Eight full-latent comparisons cover 401,408 paths. The separate finite-batch score-estimator check is not included in those eight comparisons.
- `figures/`: three PDF/PNG pairs plus `CAPTIONS.json`.

The original results remain archived. An archived reproduction record covers a fresh-directory smoke run of all three commands from an unrelated working directory, with byte comparisons of deterministic raw outputs and a recheck of the original raw-file hashes. Runtime, interpreter-description metadata and generated PDF timestamps can differ across reruns; these do not alter the exact rational results. Floating-point trajectory bytes and figure rendering may differ across platforms or dependency versions, so the semantic checks and their explicit tolerances remain the portable criterion.

`SUMMARY.md` records the original machine's interpreter path for provenance; that path is documentary and is not used by any script. `ARTIFACT_SHA256.json` is the original artifact snapshot, predating this reproduction note. Its listed files are retained without modification. The current public manifest records the files included here.
