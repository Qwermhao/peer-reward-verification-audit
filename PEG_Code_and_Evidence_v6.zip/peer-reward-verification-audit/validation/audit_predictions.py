"""Independently summarize saved predictions with standard-library arithmetic."""
import collections
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MODELS = ["oqwen_7B", "deepseek_qwen_7B", "deepseek_llm_7b"]
summary = {}
for dataset in ["gpqa", "arc"]:
    path = ROOT.parent / "native/results" / (dataset + "_predictions.csv")
    with path.open() as f:
        rows = list(csv.DictReader(f))
    original = collections.defaultdict(dict)
    invalid_majority = 0
    for row in rows:
        counts = collections.Counter(row[m] for m in MODELS)
        answers = [a for a, count in counts.items() if count >= 2]
        derived_majority = answers[0] if answers else ""
        invalid_majority += derived_majority != row["majority"]
        if row["seed"] == "original":
            original[row["condition"]][int(row["row"])] = row
    native, zero = original["native_zscore"], original["zero_reward"]
    assert native.keys() == zero.keys()
    disagreements = sum(native[i]["majority"] != zero[i]["majority"] for i in native)
    gen_disagreements = sum(native[i]["majority"] != native[i]["generator"] for i in native)
    n = len(native)
    result = {
        "rows": n,
        "all_condition_seed_rows_checked": len(rows),
        "majority_field_disagreements_with_independent_counter": invalid_majority,
        "original_native_vs_zero_majority_disagreements": disagreements,
        "original_native_vs_generator_majority_disagreements": gen_disagreements,
        "original_native_correct": sum(x["majority"] == x["gold"] for x in native.values()),
        "original_native_covered": sum(bool(x["majority"]) for x in native.values()),
    }
    assert invalid_majority == disagreements == gen_disagreements == 0
    summary[dataset] = result
(ROOT / "PREDICTION_AUDIT.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
