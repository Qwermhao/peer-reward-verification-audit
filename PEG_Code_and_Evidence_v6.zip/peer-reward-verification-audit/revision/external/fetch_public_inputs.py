import concurrent.futures,hashlib,json,ssl,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'INPUT_MANIFEST.json').read_text())
source_manifest=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
context=ssl.create_default_context(cafile='/etc/ssl/cert.pem') if Path('/etc/ssl/cert.pem').exists() else ssl.create_default_context()
def one(item):
    q=ROOT/item['path'];url=f"https://raw.githubusercontent.com/{m['repo']}/{m['commit']}/{item['upstream_path']}"
    if q.exists(): b=q.read_bytes()
    else:
        with urllib.request.urlopen(url,context=context,timeout=40) as r:b=r.read()
    g=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert g==item['git_blob_sha1'],item['path']
    assert len(b)==item['bytes'],item['path']
    if not q.exists():q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
    return dict(item,sha256=hashlib.sha256(b).hexdigest())
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    results=list(pool.map(one,m['files']+source_manifest))
(ROOT/'VERIFIED_ALL_INPUTS.json').write_text(json.dumps(dict(m,files=results),indent=2)+'\n')
for r in results:print(r['path'],r['bytes'],r['sha256'])
nb=json.loads((ROOT/'sources'/'PEG_mechanism.ipynb').read_text())
for cell_id in ['fc917f7c','41b3904a','70c92c5e']:
    source=''.join(next(c for c in nb['cells'] if c.get('id')==cell_id)['source'])
    target=ROOT/'sources'/f'cell_{cell_id}.py'
    if target.exists():assert target.read_text().rstrip('\n')==source.rstrip('\n'),str(target)
    else:target.write_text(source)
