# Sequential normalization diagnostic
Frozen 2026-11-16 09:24:49 UTC, after initial results; explicitly exploratory follow-up, not part of the original frozen comparison.
Normalize BOTH entries of EVERY answer choice once: (c,i) -> (c/(c+i),i/(c+i)). Preserve all released inputs, generator, labels, row orders, model files, eta 0.1, batch 8, ten steps and clipping. Then run the four existing conditions (native z-score, raw, scale-only, zero) on both full complete-batch cohorts and all 20 previously frozen regroupings. Compare to the fully normalized initial-policy baseline and fixed generator; retain original initial ordering baseline comparison as metadata.
Test zero-reward identity (floating tolerance 1e-12 and exact answers); test native equivalence to original function given the same fully normalized input policies. No learning-rate tuning or model selection.
Purpose: separate asymmetric selected-pair renormalization from DMI payment effects. Any remaining native changes are attributed only to this repaired-input diagnostic, not to an upstream-author endorsed implementation.

