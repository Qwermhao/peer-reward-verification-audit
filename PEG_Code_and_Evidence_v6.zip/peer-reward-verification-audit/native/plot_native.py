import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'pdf.fonttype':42,'ps.fonttype':42,'axes.labelcolor':'#233042','text.color':'#233042'})
out=ROOT/'figures';out.mkdir(exist_ok=True)
fig,axes=plt.subplots(1,2,figsize=(10,3.7),sharey=True)
labels=['Initial\nvote','Mean\npool','Generator\nonly','Native\nz-score','Zero\nreward','Raw\nreward','Scale\nonly']
colors=['#9BA4B0','#7E8B9D','#2477AB','#D47B2D','#278875','#B9B3AB','#AAA2BA']
for ax,ds,title in zip(axes,['gpqa','arc'],['GPQA','ARC-Challenge']):
 s=json.loads((ROOT/'results'/f'{ds}_summary.json').read_text());runs={r['condition']:r for r in s['runs'] if r['seed'] is None}
 vals=[s['baselines']['majority']['accuracy'],s['baselines']['mean_pool']['accuracy'],s['baselines']['generator']['accuracy']]+[runs[c]['metrics']['majority']['accuracy'] for c in ['native_zscore','zero_reward','raw','scale_only']]
 bars=ax.bar(np.arange(7),np.asarray(vals)*100,color=colors,width=.72)
 for bar,val in zip(bars,vals):ax.text(bar.get_x()+bar.get_width()/2,bar.get_height()+1.4,f'{val*100:.1f}',ha='center',fontsize=9)
 ax.set_xticks(np.arange(7),labels,fontsize=9);ax.set_ylim(0,102);ax.set_title(f'{title} (n = {s["cohort_rows"]:,})',fontweight='bold',pad=12)
 ax.yaxis.grid(True,color='#E7EBEF',linewidth=.7);ax.set_axisbelow(True)
fig.suptitle('Original order: native z-score majority = zero reward = generator (1,616 / 1,616)',fontsize=10,y=.99)
axes[0].set_ylabel('Accuracy (%)')
fig.subplots_adjust(left=.065,right=.99,top=.85,bottom=.18,wspace=.10)
for ext in ['png','pdf','svg']:fig.savefig(out/f'native_ablation.{ext}',dpi=220)
plt.close(fig)

fig,axes=plt.subplots(1,2,figsize=(9,3.5))
for ax,ds,title in zip(axes,['gpqa','arc'],['GPQA','ARC-Challenge']):
 s=json.loads((ROOT/'results'/f'{ds}_summary.json').read_text());rs={r['condition']:r['metrics']['majority'] for r in s['runs'] if r['seed'] is None}
 names=['Native z-score','Zero reward','Raw reward','Scale only'];cond=['native_zscore','zero_reward','raw','scale_only'];x=np.arange(4)
 b1=ax.bar(x-.19,[rs[c]['wrong_to_right'] for c in cond],.36,color='#278875',label='Wrong / abstain → correct')
 b2=ax.bar(x+.19,[rs[c]['right_to_wrong'] for c in cond],.36,color='#C16B62',label='Correct → wrong / abstain')
 ax.bar_label(b1,padding=2,fontsize=9);ax.bar_label(b2,padding=2,fontsize=9)
 ax.set_xticks(x,names,fontsize=9);ax.set_title(title,fontweight='bold');ax.set_ylim(0,max(rs[c]['wrong_to_right'] for c in cond)*1.2)
 ax.set_axisbelow(True);ax.yaxis.grid(True,color='#E7EBEF',linewidth=.7)
axes[0].set_ylabel('Questions changed from initial majority')
handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=2,frameon=False,bbox_to_anchor=(.5,-.01),fontsize=9)
fig.subplots_adjust(left=.08,right=.99,top=.85,bottom=.22,wspace=.2)
for ext in ['png','pdf','svg']:fig.savefig(out/f'native_directional_changes.{ext}',dpi=220)
plt.close(fig)
